CREATE TABLE PEOPLE (
ID                     BIGSERIAL UNIQUE PRIMARY KEY,    
FIRSTNAME              VARCHAR(50),
LASTNAME               VARCHAR(50)
);
