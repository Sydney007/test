'use strict';

//'ngResource', 'ngAnimate' ,'ngRoute', 'swaggerUi', 'http-auth-interceptor',  'angular-spinkit'

var hmsApp = angular
        .module('hmsApp', ['ngMaterial', 'ngMessages', 'lfNgMdFileInput', 'ngMask','rw.moneymask',
            'ngAnimate', 'ui.calendar', 'ui.bootstrap', 'datatables', 'ngTagsInput', 'gm.datepickerMultiSelect', 'ngSanitize', 'ui.select','ckeditor']);

//hmsApp.config(['$compileProvider', '$mdThemingProvider', function ($compileProvider, $mdThemingProvider) {
//  $compileProvider.debugInfoEnabled(false);
// $mdThemingProvider.theme('default')
//}]);

hmsApp.directive('pdf', function ($window) {
    return {
        restrict: 'E',
        link: function (scope, element, attrs) {
            var height = $window.innerHeight - 250;
            var url = scope.$eval(attrs.src);
            element.replaceWith('<object width="100%" height="' + height + 'px" type="application/pdf" data="' + url + '"></object>');
        }
    };
});

angular.module('ui.bootstrap').config(function ($provide) {
    $provide.decorator('$uibModal', function ($delegate) {
        var open = $delegate.open;

        $delegate.open = function (options) {
            options = angular.extend(options || {}, {
                backdrop: 'static',
                keyboard: false
            });

            return open(options);
        };
        return $delegate;
    })
});

hmsApp.filter('propsFilter', function () {
    return function (items, props) {
        var out = [];

        if (angular.isArray(items)) {
            var keys = Object.keys(props);

            items.forEach(function (item) {
                var itemMatches = false;

                for (var i = 0; i < keys.length; i++) {
                    var prop = keys[i];
                    var text = props[prop].toLowerCase();
                    if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                        itemMatches = true;
                        break;
                    }
                }

                if (itemMatches) {
                    out.push(item);
                }
            });
        } else {
            // Let the output be the input untouched
            out = items;
        }

        return out;
    };
});



