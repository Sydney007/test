package za.co.timbaron.hms;

import java.sql.Date;
import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import za.co.timbaron.hms.entity.Address;
import za.co.timbaron.hms.entity.EmergencyContact;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserRawPassword;
import za.co.timbaron.hms.enums.AccountTypeEnum;
import za.co.timbaron.hms.enums.EntityTypeEnum;
import za.co.timbaron.hms.enums.PackageTypeEnum;
import za.co.timbaron.hms.enums.ProvinceEnum;
import za.co.timbaron.hms.enums.RelationshipEnum;
import za.co.timbaron.hms.enums.TitleEnum;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.repository.HMSEntityRepo;
import za.co.timbaron.hms.repository.PatientRepo;
import za.co.timbaron.hms.repository.UserRepo;
import za.co.timbaron.hms.util.NumbersGenerator;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserRepoTest {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private UserRepoTestHelper userRepoTestHelper;

    @Autowired
    private NumbersGenerator numbersGenerator;

    @Autowired
    private PatientRepo patientRepo;

    @Autowired
    private HMSEntityRepo entityRepo;

    @Autowired
    private EmployeeRepo employeeRepo;

    @Test
    public void createPatientUser() {

        try {
            User user = new User();
            user.setUsername("nkateko.chauke");
            user.setPassword("$2a$10$r3ciiRhOuH0THkWGOB20G.Xj6zdeTWAzSo4Kmb00EJHoko67eYJiq");
            user.setIdentityNumber("2001065865087");//2001065865087
            user.setAccountActive(Boolean.TRUE);
            user.setAccountType(AccountTypeEnum.PREMIUM);
            user.setEntityIsHuman(Boolean.TRUE);
            user.setUserType(UserTypeEnum.PATIENT);
            user.setPackageType(PackageTypeEnum.PATIENT);
            user.setEntityType(EntityTypeEnum.PERSON);

            UserRawPassword userRawPassword = new UserRawPassword();
            userRawPassword.setPassword("nkateko.chauke");
            userRawPassword.setUser(user);

            user.setUserPassword(userRawPassword);

            Address address = new Address();
            address.setUser(user);
            address.setAddressLine1("84 Bishop Square");
            address.setAddressLine2("Leogem Place and 6th Rd, Noordwyk");
            address.setCity("Midrand");
            address.setPostalCode("1687");
            address.setProvince(ProvinceEnum.GAUTENG);

            user.setAddress(address);

            EmergencyContact contact = new EmergencyContact();
            contact.setUser(user);
            contact.setTitle(TitleEnum.MR);
            contact.setFirstName("Matimba");
            contact.setLastName("Chauke");
            contact.setContactNo("0728565946");
            contact.setRelationship(RelationshipEnum.FATHER);

            user.setEmergencyContact(contact);

            userRepo.save(user);

            userRepoTestHelper.createPatientUserDetails(user, patientRepo, numbersGenerator);

        } catch (Exception e) {
            log.error("Error creating user : ", e);
        }

        /*
        Nyeleti Id number
        1811160811088
         */
    }

    @Test
    public void createEntityClinicUser() {

        try {
            User user = new User();
            user.setUsername("xigaloclinic");
            user.setPassword("$2a$10$p4IzQJDmB53kYNwsnwTwBeDmn7/yhAmsxdeIDnY2tCle0RXAzZqhC");
            user.setIdentityNumber("1988/0232145/07");//2001065865087
            user.setAccountActive(Boolean.TRUE);
            user.setAccountType(AccountTypeEnum.PREMIUM);
            user.setEntityIsHuman(Boolean.FALSE);
            user.setUserType(UserTypeEnum.ENTITY);
            user.setPackageType(PackageTypeEnum.BASIC);
            user.setEntityType(EntityTypeEnum.CLINIC);

            UserRawPassword userRawPassword = new UserRawPassword();
            userRawPassword.setPassword("xigaloclinic");
            userRawPassword.setUser(user);

            user.setUserPassword(userRawPassword);

            Address address = new Address();
            address.setUser(user);
            address.setAddressLine1("58 Punda Maria Road");
            address.setAddressLine2("Xigalo");
            address.setCity("Malamulele");
            address.setPostalCode("0981");
            address.setProvince(ProvinceEnum.LIMPOPO);

            user.setAddress(address);

            userRepo.save(user);

            userRepoTestHelper.createEntityDetails(user, entityRepo);

        } catch (Exception e) {
            log.error("Error creating user : ", e);
        }
    }

    @Test
    public void createDoctorUser() {
        try {
            User user = new User();
            user.setUsername("ronald.chauke");
            user.setPassword("$2a$10$rnKUaYTE30gOri6rTadFN.fE3F2w5UF1g5l.Uap2Zu0h7mekEpNsa");
            user.setIdentityNumber("8004275820108");
            user.setAccountActive(Boolean.TRUE);
            user.setAccountType(AccountTypeEnum.PREMIUM);
            user.setEntityIsHuman(Boolean.FALSE);
            user.setUserType(UserTypeEnum.DOCTOR);
            user.setPackageType(PackageTypeEnum.BASIC);
            user.setEntityType(EntityTypeEnum.PERSON);

            UserRawPassword userRawPassword = new UserRawPassword();
            userRawPassword.setPassword("ronald.chauke");
            userRawPassword.setUser(user);

            user.setUserPassword(userRawPassword);

            Address address = new Address();
            address.setUser(user);
            address.setAddressLine1("44 Liebenberg Street");
            address.setAddressLine2("Olievenhoutbch");
            address.setCity("Centurion");
            address.setPostalCode("2001");
            address.setProvince(ProvinceEnum.GAUTENG);

            user.setAddress(address);

            userRepo.save(user);

            userRepoTestHelper.createDoctorDetails(user, employeeRepo, entityRepo);

        } catch (Exception e) {
            log.error("Error creating user : ", e);
        }
    }

    @Test
    public void createReceptionistUser() {
        try {
            User user = new User();
            user.setUsername("tim.chauke");
            user.setPassword("$2a$10$8nOBCepI5wPVIiOKQkjHgedU9xjMer2UYZQiOXeUijTYfnTewUJsO");
            user.setIdentityNumber("8805285920088");
            user.setAccountActive(Boolean.TRUE);
            user.setAccountType(AccountTypeEnum.PREMIUM);
            user.setEntityIsHuman(Boolean.FALSE);
            user.setUserType(UserTypeEnum.RECEPTIONIST);
            user.setPackageType(PackageTypeEnum.BASIC);
            user.setEntityType(EntityTypeEnum.PERSON);

            UserRawPassword userRawPassword = new UserRawPassword();
            userRawPassword.setPassword("tim.chauke");
            userRawPassword.setUser(user);

            user.setUserPassword(userRawPassword);

            Address address = new Address();
            address.setUser(user);
            address.setAddressLine1("77 Urban ridge south");
            address.setAddressLine2("Smuts and 3rd road");
            address.setCity("Halfway Gardens");
            address.setPostalCode("1686");
            address.setProvince(ProvinceEnum.GAUTENG);

            user.setAddress(address);

            userRepo.save(user);

            userRepoTestHelper.createReceptionistDetails(user, employeeRepo, entityRepo);

        } catch (Exception e) {
            log.error("Error creating user : ", e);
        }
    }

    public static Date addDays(Date date, int days) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, days);
        return new Date(c.getTimeInMillis());
    }

    public static Date subtractDays(Date date, int days) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, -days);
        return new Date(c.getTimeInMillis());
    }

}
