/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import org.springframework.stereotype.Component;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.enums.AvailabilityStatusEnum;
import za.co.timbaron.hms.enums.CountryEnum;
import za.co.timbaron.hms.enums.GenderEnum;
import za.co.timbaron.hms.enums.LanguageEnum;
import za.co.timbaron.hms.enums.MaritalStatusEnum;
import za.co.timbaron.hms.enums.RaceEnum;
import za.co.timbaron.hms.enums.TitleEnum;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.repository.HMSEntityRepo;
import za.co.timbaron.hms.repository.PatientRepo;
import za.co.timbaron.hms.util.NumbersGenerator;

@Component
public class UserRepoTestHelper {

    public void createPatientUserDetails(User user, PatientRepo patientRepo, NumbersGenerator numbersGenerator) {
        Patient patient = new Patient();
        patient.setAccountNumber(numbersGenerator.generateAccountNo(0));
        patient.setFullName("Nkateko");
        patient.setLastName("Chauke");
        patient.setInitials("N");
        patient.setIdentityNumber(user.getIdentityNumber());
        patient.setDob("2020/01/06");
        patient.setKnownAs("Nkateko");
        patient.setPhoto("http://localhost:8085/TimbaronHMS/Images/2001065865087/profilepic.jpg");
        patient.setDateCreated(new Timestamp(new java.util.Date().getTime()));
        patient.setDateModified(new Timestamp(new java.util.Date().getTime()));
        patient.setSmoker(false);
        patient.setCellNo("0728565946");
        patient.setTelephone("0728565946");
        patient.setAlternateTelephone("0728565946");
        patient.setEmail("nkateko.chauke@gmail.com");
        patient.setDeceased(false);
        patient.setTitle(TitleEnum.MR);
        patient.setRace(RaceEnum.AFRICAN_AMERICAN);
        patient.setGender(GenderEnum.MALE);
        patient.setCountry(CountryEnum.ZA);
        patient.setLanguage(LanguageEnum.XITSONGA);
        patient.setMaritalStatus(MaritalStatusEnum.SINGLE);
        patient.setUserId(user.getId());

        patientRepo.save(patient);
    }

    public void createEntityDetails(User user, HMSEntityRepo entityRepo) {

        HMSEntity entity = new HMSEntity();
        entity.setEntityName("Xigalo Clinic");
        entity.setTelephone("015 856 2314");
        entity.setFaxNumber("015 856 2315");
        entity.setConsultationFee(BigDecimal.valueOf(100.00));
        entity.setEmail("info@xigaloclinic.co.za");
        entity.setProfilePic("http://localhost:8085/TimbaronHMS/Images/Xigalo_Clinic/profilepic.jpg");
        entity.setLogo("Xigalo_Clinic/logo1.PNG");
        entity.setRegistrationNumber(user.getIdentityNumber());
        entity.setEntitySubNameGroup("");
        entity.setDateCreated(new Date(new java.util.Date().getTime()));
        entity.setEntityDispenseMedicine(true);
        entity.setPracticeNo(user.getIdentityNumber());
        entity.setPackageType(user.getPackageType());
        entity.setEntityType(user.getEntityType());
        entity.setAccountType(user.getAccountType());

        entityRepo.save(entity);

    }

    public void createDoctorDetails(User user, EmployeeRepo employeeRepo, HMSEntityRepo entityRepo) {

        Employee employee = new Employee();
        employee.setEmployeeNo("4818920");
        employee.setFullName("Ronald");
        employee.setLastName("Chauke");
        employee.setInitials("R");
        employee.setIdentityNumber(user.getIdentityNumber());
        employee.setDob("1980-04-27");
        employee.setKnownAs("Ronald");
        employee.setPhoto("http://localhost:8085/TimbaronHMS/Images/8004275820108/profilepic.jpg");
        employee.setDateCreated(new Timestamp(new java.util.Date().getTime()));
        employee.setDateModified(new Timestamp(new java.util.Date().getTime()));
        employee.setSmoker(false);
        employee.setCellNo("0828565946");
        employee.setTelephone("0828565946");
        employee.setAlternateTelephone("0735110443");
        employee.setEmail("ronald.chauke@timbaron.co.za");
        employee.setDeceased(false);
        employee.setTitle(TitleEnum.MR);
        employee.setRace(RaceEnum.AFRICAN_AMERICAN);
        employee.setGender(GenderEnum.MALE);
        employee.setCountry(CountryEnum.ZA);
        employee.setLanguage(LanguageEnum.ENGLISH);
        employee.setMaritalStatus(MaritalStatusEnum.SINGLE);
        employee.setUserId(user.getId());
        employee.setAvailabilityStatus(AvailabilityStatusEnum.OFFLINE);
        employee.setEntity(entityRepo.getOne(1l));

        employeeRepo.save(employee);

    }

    public void createReceptionistDetails(User user, EmployeeRepo employeeRepo, HMSEntityRepo entityRepo) {

        Employee employee = new Employee();
        employee.setEmployeeNo("3878920");
        employee.setFullName("Tintswalo Cynthia");
        employee.setLastName("Chauke");
        employee.setInitials("TC");
        employee.setIdentityNumber(user.getIdentityNumber());
        employee.setDob("1988-05-28");
        employee.setKnownAs("Tintswalo");
        employee.setPhoto("http://localhost:8085/TimbaronHMS/Images/8805285920088/profilepic.jpg");
        employee.setDateCreated(new Timestamp(new java.util.Date().getTime()));
        employee.setDateModified(new Timestamp(new java.util.Date().getTime()));
        employee.setSmoker(false);
        employee.setCellNo("0718565946");
        employee.setTelephone("0718565946");
        employee.setAlternateTelephone("0735110443");
        employee.setEmail("tintswalo.chauke@timbaron.co.za");
        employee.setDeceased(false);
        employee.setTitle(TitleEnum.MRS);
        employee.setRace(RaceEnum.AFRICAN_AMERICAN);
        employee.setGender(GenderEnum.FEMALE);
        employee.setCountry(CountryEnum.ZA);
        employee.setLanguage(LanguageEnum.ENGLISH);
        employee.setMaritalStatus(MaritalStatusEnum.MARRIED);
        employee.setUserId(user.getId());
        employee.setAvailabilityStatus(AvailabilityStatusEnum.OFFLINE);
        employee.setEntity(entityRepo.getOne(1l));

        employeeRepo.save(employee);
    }

}
