package za.co.timbaron.hms;

import java.sql.Date;
import java.util.Calendar;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import za.co.timbaron.hms.repository.AppointmentRepo;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.repository.HMSEntityRepo;
import za.co.timbaron.hms.repository.PatientRepo;
import za.co.timbaron.hms.repository.VisitRepo;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AppointmentRepoTest {

    @Autowired
    private AppointmentRepo appointmentRepo;

    @Autowired
    private PatientRepo patientRepo;

    @Autowired
    private VisitRepo visitRepo;

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private HMSEntityRepo hmsEntityRepo;

    @Test
    public void createAppointment() {

        java.sql.Date todaysDate = new java.sql.Date(new java.util.Date().getTime());

        int futureDay = 1;
        int pastDay = 2;

        java.sql.Date futureDate = addDays(todaysDate, futureDay);
        java.sql.Date pastDate = subtractDays(todaysDate, pastDay);

        System.out.println("futureDate =>>> " + futureDate);
        System.out.println("pastDate =>>> " + pastDate);
        
        //visitRepo.findById(1l).get();

        /*Appointment app = new Appointment();
        app.setTitle("Nkateko's Birthday");
        app.setAllDay(true);
        app.setStartDate(futureDate.toString());
        app.setStartTime("08:00");
        app.setEndDate(futureDate.toString());
        app.setEndTime("23:59");

        app.setVisitDate(futureDate);
        app.setDescription("Nkateko's Birthday");
        app.setFrequently(AppointmentFrequentlyEnum.ONCEOFF);

        app.setUserType(UserTypeEnum.ADMINISTRATOR);
        app.setStatus(AppointmentStatusEnum.ACCEPTED);
        //Visit visit = visitRepo.findById(1l).get();
        
        System.out.println("visitRepo "+visitRepo);
        System.out.println("visit "+visit.toString());
        app.setVisit(visit);
        app.setPatient(patientRepo.findById(1l).get());

        app.setEntity(hmsEntityRepo.findById(1l).get());
        app.setDoctor(employeeRepo.findById(1l).get());
        app.setCreatedById(1);

        AppointmentDateRange ranges = new AppointmentDateRange();
        ranges.setEnd("2021-02-20");
        ranges.setStart("2021-02-12");
        ranges.setAppointment(app);

        Set<AppointmentDateRange> appointmentDateRanges = new HashSet();
        appointmentDateRanges.add(ranges);

        app.setAppointmentDateRanges(appointmentDateRanges);

        appointmentRepo.save(app);*/
    }

    @Test
    public void findAllByPatient() {

        //Patient p = patientRepo.findById(1l).get();
        //List<Appointment> app = appointmentRepo.findAllByPatient(p);
        //System.out.println("Appointments = "+app.size());
    }

    @Test
    public void findAllByEntityIdAndDateRange() {

        /*Date start = Date.valueOf("2019-07-01");
        Date end = Date.valueOf("2019-08-31");

        List<Appointment> app = appointmentRepo.findAllByEntityIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(1, "2019-07-01", "2019-08-31");

        app.forEach((a) -> {
            System.out.println(a.getPatient());
            System.out.println("ID " + a.getPatient().getId());
            System.out.println("Name " + a.getPatient().getFullName() + " " + a.getPatient().getLastName());
        });*/
    }

    public static Date addDays(Date date, int days) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, days);
        return new Date(c.getTimeInMillis());
    }

    public static Date subtractDays(Date date, int days) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, -days);
        return new Date(c.getTimeInMillis());
    }

}
