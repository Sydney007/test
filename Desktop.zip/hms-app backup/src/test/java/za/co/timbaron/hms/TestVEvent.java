/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Recur;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.parameter.Cn;
import net.fortuna.ical4j.model.parameter.Role;
import net.fortuna.ical4j.model.property.Attendee;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.Method;
import net.fortuna.ical4j.model.property.Organizer;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.RRule;
import net.fortuna.ical4j.model.property.Uid;
import net.fortuna.ical4j.model.property.Version;

/**
 *
 * @author ABMC684
 */
public class TestVEvent {

    public static void main(String[] args) throws Exception {
        allDayEvent();
    }

    public static void allDayEvent() throws FileNotFoundException, IOException, URISyntaxException, ParseException {
        //Creating an event

        String start = "2018-07-06 09:00";
        String end = "2018-07-06 09:30";

        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date startDate = f.parse(start);
        Date endDate = f.parse(end);

        System.out.println(startDate);
        System.out.println(endDate);

        net.fortuna.ical4j.model.DateTime dtStart = new DateTime(startDate.getTime());
        //dtStart.setUtc(true);

        net.fortuna.ical4j.model.DateTime dtEnd = new DateTime(endDate.getTime());
        //dtEnd.setUtc(true);

        // initialise as an all-day event..
        VEvent event = new VEvent(dtStart, dtEnd, "Next Pregnancy");
        event.getProperties().add(new Organizer("mailto:matimba.chauke@absa.co.za"));
        System.out.println(event.getEndDate());

        //Send invitation to
        Attendee patient = new Attendee(URI.create("mailto:matimba.chauke@absa.co.za"));
        patient.getParameters().add(Role.OPT_PARTICIPANT);
        patient.getParameters().add(new Cn("Patient"));
        event.getProperties().add(patient);

        String recurule = "FREQ=WEEKLY;INTERVAL=1;BYDAY=MO;UNTIL="+dtEnd;
        Recur recur = new Recur(recurule);
        
        //String 

        String rrule = "FREQ=WEEKLY;BYDAY=MO";
        /*
                Recurrence (RRULE) Examples
                Below are some examples of how to represent recurring events using the RRULE format:

                A rule occurring on the third Sunday of April would be as follows:
                RRULE:FREQ=YEARLY;BYMONTH=4;BYDAY=SU;BYSETPOS=3

                An event occurring on the first and second Monday of October would be specified by the rule:
                RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=MO;BYSETPOS=1,2

                Event that repeats monthly: every 29th of every other month!
                RRULE:FREQ=MONTHLY;INTERVAL=2;BYMONTHDAY=29
                NOTE: As February does not have 29 days in non-leap years, this rule would potentially have a gap between December of the previous year and April of the current year. 
                For this reason it makes more sense to use negative SETPOS values when you need to specify the end of a month.

                Event that repeats monthly: every last Sunday of every 3 months
                RRULE:FREQ=MONTHLY;INTERVAL=3;BYDAY=SU;BYSETPOS=-1

                Event that repeats monthly: every fourth Sunday of every 3 months
                RRULE:FREQ=MONTHLY;INTERVAL=3;BYDAY=SU;BYSETPOS=4

                Event that repeats yearly: every 5th of February:
                RRULE:FREQ=YEARLY;BYMONTH=2;BYDAY=5

                When I was using iCal4j to compose the ics, I enter RRULE with
                RRULE:FREQ=WEEKLY;UNTIL=20141129T235959Z;INTERVAL=1;BYDAY=WE

                However, in the resultant, it becomes
                RRULE:FREQ=WEEKLY;UNTIL=20141129T155959Z;INTERVAL=1;BYDAY=WE
         */

        RRule rule = new RRule(recur);
        event.getProperties().add(rule);

        // Generate a UID for the event..
        event.getProperties().add(new Uid("CAL-ID-" + new java.util.Date().getTime()));

        net.fortuna.ical4j.model.Calendar cal = new net.fortuna.ical4j.model.Calendar();
        cal.getComponents().add(event);

        net.fortuna.ical4j.model.Calendar icsCalendar = new net.fortuna.ical4j.model.Calendar();
        icsCalendar.getProperties().add(new ProdId("-//Events Calendar//iCal4j 1.0//EN"));
        icsCalendar.getProperties().add(CalScale.GREGORIAN);
        icsCalendar.getProperties().add(Version.VERSION_2_0);
        icsCalendar.getProperties().add(Method.REQUEST);

        // Add the event and print
        icsCalendar.getComponents().add(event);
        //System.out.println(icsCalendar);

        FileOutputStream fout = new FileOutputStream("mycalendar.ics");

        CalendarOutputter outputter = new CalendarOutputter();
        outputter.output(icsCalendar, fout);
        fout.close();

    }

}
