/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 *
 * @author Matimba
 */
public class BcryptPasswordGenerator {

    public static void main(String[] args) {
        BCryptPasswordEncoder d = new BCryptPasswordEncoder();
        System.out.println(d.encode("nkateko.chaukee"));
    }

}
