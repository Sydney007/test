package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_MENU")
public class Menu implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "MENU", nullable = false)
    private String menuName;

    @Column(name = "CSSCLASS", nullable = false)
    private String cssClass;

    @Column(name = "URL", nullable = false)
    private String url;

    @Column(name = "ACTIVE", nullable = false)
    private boolean active;

    @Column(name = "ACCESSROLES", nullable = false)
    private String accessRoles;

    @OneToMany(mappedBy = "menu", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Submenu> submenus = new ArrayList();
}
