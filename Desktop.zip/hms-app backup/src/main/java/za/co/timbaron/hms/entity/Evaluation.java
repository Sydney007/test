/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 *
 * @author Matimba
 */
@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_PATIENT_EVALUATIONS")
public class Evaluation implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "EVALUATION", nullable = false)
    private String evaluation;

    @Column(name = "RESULTS", nullable = false)
    private String results;

    @Column(name = "EMPLOYEEIDNO", nullable = false)
    private String employeeId;

    @Column(name = "VISITID", nullable = false)
    private long visitId;

    @Column(name = "ENTITYID", nullable = false)
    private long entityId;

    @Column(name = "RISKLEVELID", nullable = false)
    private long riskLevelId;

    @Column(name = "PATIENTIDNO", nullable = false)
    private String patientIdNo;

    @Column(name = "VISITDATE", nullable = false)
    private Date visitDate;
}
