/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

/**
 *
 * @author ABMC684
 */
import java.io.FileOutputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import javax.activation.DataHandler;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import lombok.extern.slf4j.Slf4j;
import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.parameter.Cn;
import net.fortuna.ical4j.model.parameter.Role;
import net.fortuna.ical4j.model.property.Attendee;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.DtEnd;
import net.fortuna.ical4j.model.property.DtStart;
import net.fortuna.ical4j.model.property.Location;
import net.fortuna.ical4j.model.property.Method;
import net.fortuna.ical4j.model.property.Organizer;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.RRule;
import net.fortuna.ical4j.model.property.Status;
import net.fortuna.ical4j.model.property.Summary;
import net.fortuna.ical4j.model.property.Transp;
import net.fortuna.ical4j.model.property.Uid;
import net.fortuna.ical4j.model.property.Version;
import org.springframework.beans.factory.annotation.Value;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.enums.AppointmentFrequentlyEnum;

/*
         WEEKLY
        Which day(MO, Tue,Wen,Thu, Fri,Sat,Sun)
        RRULE:FREQ=WEEKLY;UNTIL=20141129T235959Z;INTERVAL=1;BYDAY=WE

        MONTHLY
        every 2, 3,4,6 months

        Event that repeats monthly: every first Sunday of every month
        RRULE:FREQ=MONTHLY;UNTIL=20180706T093000;INTERVAL=1;BYDAY=SU;BYSETPOS=1

        YEARLY
        Which day
        An event occurring on the first and second Monday of October would be specified by the rule:
        RRULE:FREQ=YEARLY;UNTIL=20180706T093000;BYMONTH=10;BYDAY=MO;BYSETPOS=1,2


        FREQ=WEEKLY;WKST=MO;UNTIL=20180706T093000;INTERVAL=1
 */
@Slf4j
public class EmailUtil {

    @Value("${mail.username}")
    private String username;

    @Value("${mail.password}")
    private String password;

    @Value("${mail.from}")
    private String from;

    private MimeMessage message;

    public void send(Appointment appointment) throws Exception {

        try {

            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props,
                    new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });

            // Define message
            message = new MimeMessage(session);
            message.addHeaderLine("method=REQUEST");
            message.addHeaderLine("charset=UTF-8");
            message.addHeaderLine("component=VEVENT");

            message.setFrom(new InternetAddress(from));

            /* to set multiple recipients, e.g
              message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("abc@abc.com,abc@def.com,ghi@abc.com"));
             */
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(appointment.getPatient().getEmail()));
            message.addRecipient(Message.RecipientType.CC, new InternetAddress(appointment.getDoctor().getEmail()));
            message.setSubject(appointment.getTitle());

            // Start calendar VEvent 
            // Creating an event
            //System.out.println("AppointmentFrequentlyEnum = " + );
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date startDate = dateFormatter.parse(appointment.getStartDate() + " " + appointment.getStartTime());
            Date endDate = dateFormatter.parse(appointment.getEndDate() + " " + appointment.getEndTime());

            net.fortuna.ical4j.model.DateTime dtStart = new DateTime(startDate.getTime());
            net.fortuna.ical4j.model.DateTime dtEnd = new DateTime(endDate.getTime());

            HMSEntity entity = appointment.getDoctor().getEntity();

            String location = "";//entity.getAddressLine1() + "," + entity.getAddressLine2() + "," + entity.getSuburb().getName();

            // Initialise as an all-day event..
            //VEvent(dtStart, dtEnd, appointment.getTitle())
            VEvent event = new VEvent();
            event.getProperties().add(new Organizer("mailto:" + entity.getEmail()));
            event.getProperties().add(new Description(appointment.getTitle()));
            event.getProperties().add(new DtStart(dtStart));
            event.getProperties().add(new DtEnd(dtEnd));
            event.getProperties().add(new Summary(appointment.getTitle()));
            event.getProperties().add(new Location(location));
            // Generate a UID for the event..
            event.getProperties().add(new Uid(appointment.getDoctor().getEntity().getEntityName() + ":events:" + new java.util.Date().getTime()));
            event.getProperties().add(new Status("CONFIRMED"));
            event.getProperties().add(new Transp("TRANSPARENT"));
            //This property defines the calendar scale used for the calendar information specified in the iCalendar

            AppointmentFrequentlyEnum appointmentFrequently = appointment.getFrequently();

            if (appointmentFrequently != AppointmentFrequentlyEnum.ONCEOFF) {

                StringBuilder rrule = new StringBuilder();
                String eventEndDay[] = event.getEndDate().toString().split(":");

                if (appointmentFrequently == AppointmentFrequentlyEnum.MONTHLY) {
                    rrule.append("FREQ=MONTHLY;UNTIL=").append(dtEnd)
                            .append(";INTERVAL=").append(appointment.getInterval())
                            .append(";BYMONTHDAY=").append(appointment.getByMonthDay())
                            .append(";BYSETPOS=1");
                } else if (appointmentFrequently == AppointmentFrequentlyEnum.WEEKLY) {
                    StringBuilder days = new StringBuilder();

                    for (Day day : appointment.getWeeklyDays()) {
                        days.append(day.getDay()).append(",");
                    }

                    String weeklyDays = days.substring(0, days.length() - 1);

                    rrule.append("FREQ=WEEKLY;UNTIL=").append(dtEnd)
                            .append(";INTERVAL=1;BYDAY=")
                            .append(weeklyDays);
                }

                System.out.println(rrule.toString());

                RRule rule = new RRule(rrule.toString());

                event.getProperties().add(rule);
            }

            // Send invitation to
            Attendee patient = new Attendee(URI.create("mailto:" + appointment.getPatient().getEmail()));
            patient.getParameters().add(Role.OPT_PARTICIPANT);
            patient.getParameters().add(new Cn("Patient"));
            event.getProperties().add(patient);

            Attendee doctor = new Attendee(URI.create("mailto:" + appointment.getDoctor().getEmail()));
            doctor.getParameters().add(Role.OPT_PARTICIPANT);
            doctor.getParameters().add(new Cn("Doctor"));
            event.getProperties().add(doctor);

            String receptionistUserEmail = "";

            if (appointment.getCreatedBy() == null) {
                receptionistUserEmail = entity.getEmail();
            } else {
                receptionistUserEmail = appointment.getCreatedBy().getEmail();
            }

            Attendee createdBy = new Attendee(URI.create("mailto:" + receptionistUserEmail));
            createdBy.getParameters().add(Role.OPT_PARTICIPANT);
            createdBy.getParameters().add(new Cn("Receptionist"));
            event.getProperties().add(createdBy);

            net.fortuna.ical4j.model.Calendar cal = new net.fortuna.ical4j.model.Calendar();
            cal.getComponents().add(event);

            // Event Calendar
            Calendar icsCalendar = new Calendar();
            icsCalendar.getProperties().add(new ProdId("-//Events Calendar//iCal4j 1.0//EN"));
            icsCalendar.getProperties().add(CalScale.GREGORIAN);
            icsCalendar.getProperties().add(Version.VERSION_2_0);
            icsCalendar.getProperties().add(Method.REQUEST);

            // Add the event and print
            icsCalendar.getComponents().add(event);
            //logger.debug("EmailUtil.class -> send method: [Calendar details - " + icsCalendar + " ]");

            // Write calendar to a file
            FileOutputStream fout = new FileOutputStream("appointment.ics");

            CalendarOutputter outputter = new CalendarOutputter();
            outputter.output(icsCalendar, fout);
            fout.close();

            // End calendar VEvent 
            // Create the message part
            BodyPart messageBodyPart = new MimeBodyPart();

            // Fill the message
            messageBodyPart.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
            messageBodyPart.setHeader("Content-ID", "calendar_message");
            messageBodyPart.setDataHandler(new DataHandler(
                    new ByteArrayDataSource(icsCalendar.toString(), "text/calendar")));// very important

            // Create a Multipart
            Multipart multipart = new MimeMultipart();

            // Add part one
            multipart.addBodyPart(messageBodyPart);

            // Put parts in message
            message.setContent(multipart);

            // send message
            Thread thread = new Thread() {
                public void run() {
                    try {
                        Transport.send(message);
                    } catch (MessagingException ex) {
                        java.util.logging.Logger.getLogger(EmailUtil.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            };
            thread.start();

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
    }
}
