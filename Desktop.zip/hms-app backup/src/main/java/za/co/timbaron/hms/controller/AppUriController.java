package za.co.timbaron.hms.controller;

import com.google.gson.Gson;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Notification;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.RedirectBean;
import za.co.timbaron.hms.service.EmployeeService;
import za.co.timbaron.hms.service.HMSEntityService;
import za.co.timbaron.hms.util.EntityHelperBean;
import za.co.timbaron.hms.util.SearchBean;
import za.co.timbaron.hms.util.UserPrincipalHelper;

@Controller
public class AppUriController {

    private static final Logger logger = LoggerFactory.getLogger(AppUriController.class);

    @Autowired
    private Gson gson;

    @Autowired
    private RedirectBean redirectBean;

    @Autowired
    private HMSEntityService entityService;

    @Autowired
    private EntityHelperBean entityHelperBean;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private UserPrincipalHelper userprincipalHelper;

    @RequestMapping(value = "/Home", method = RequestMethod.GET)
    public String homePage(ModelMap model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Home";
        }
    }

    @RequestMapping(value = "/Billing", method = RequestMethod.GET)
    public String billingPage(ModelMap model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            model.addAttribute("billingSubmenu", redirectBean.getBillingSubmenu());
            getPrincipal(model);
            return "Billing";
        }
    }

    @RequestMapping(value = "/Referrals", method = RequestMethod.GET)
    public String referralPage(ModelMap model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Referral";
        }
    }

    @RequestMapping(value = "/Administration", method = RequestMethod.GET)
    public String administrationPage(ModelMap model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            model.addAttribute("adminSubmenu", redirectBean.getAdminSubmenu());
            getPrincipal(model);
            return "Administration";
        }
    }

    @RequestMapping(value = "/EntityManagement", method = RequestMethod.GET)
    public String entityManagementPage(ModelMap model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            model.addAttribute("entityManagementSubmenu", redirectBean.getEntityManagementSubmenu());
            getPrincipal(model);
            return "EntityManagement";
        }
    }

    @RequestMapping(value = "/MySpace", method = RequestMethod.GET)
    public String mySpacePage(ModelMap model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            model.addAttribute("mySpaceSubmenu", redirectBean.getMySpaceSubmenu());
            getPrincipal(model);
            return "MySpace";
        }
    }

    @RequestMapping(value = "/Profile", method = RequestMethod.GET)
    public String profilePage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Profile";
        }
    }

    @RequestMapping(value = "/Consultation", method = RequestMethod.GET)
    public String consultationPage(ModelMap model) throws IOException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Consultation";
        }
    }

    @PostMapping("/Consultation")
    public String consultationPage(SearchBean searchBean, ModelMap model) throws IOException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            logger.debug("AppUriController.class -> consultPage method: [Doctor Accepting Notification]");
            logger.debug("AppUriController.class -> SearchBean details: [" + gson.toJson(searchBean) + "]");

            Notification notification = employeeService.findNotificationById(searchBean.getId());
            notification.setViewed(true);
            notification.setDoctor(null);
            notification.setVisit(null);
            employeeService.persistObject(notification);

            model.addAttribute("visitId", searchBean.getVisitId());
            getPrincipal(model);
            return "Consultation";
        }
    }

    @RequestMapping(value = "/Patients", method = RequestMethod.GET)
    public String patientsPage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Patients";
        }
    }

    @RequestMapping(value = "/InPatients", method = RequestMethod.GET)
    public String inPatientsPage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "InPatients";
        }
    }

    @RequestMapping(value = "/OutPatients", method = RequestMethod.GET)
    public String outPatientsPage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "OutPatients";
        }
    }

    @RequestMapping(value = "/Items", method = RequestMethod.GET)
    public String ItemsPage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Items";
        }
    }

    @RequestMapping(value = "/Employees", method = RequestMethod.GET)
    public String usersPage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Employees";
        }
    }

    @RequestMapping(value = "/Autopsy", method = RequestMethod.GET)
    public String autopsyPage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Autopsy";
        }
    }

    @RequestMapping(value = "/Laboratory", method = RequestMethod.GET)
    public String laboratoryPage(ModelMap model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return "/";
        } else {
            getPrincipal(model);
            return "Laboratory";
        }
    }

    @RequestMapping(value = {"/", "/login"}, method = RequestMethod.GET)
    public String loginPage() {
        return "/login";
    }

    private ModelAndView getPrincipal(ModelMap model) {
        String userName = null;
        String entityType = null;
        Date dateRegistered = null;
        String logo = "";

        Object principalDetails = userprincipalHelper.getUserPrincipal();

        if (userprincipalHelper.getUserPrincipal() == null) {
            return new ModelAndView(new RedirectView("logout"));
        }

        StringBuilder address = new StringBuilder();

        entityType = userprincipalHelper.getLoggedUser().getEntityType().getName();

        String userId = "";

        long entityId = 0;

        BigDecimal practiceConsultationFee = new BigDecimal(0.00);
        boolean entityDispenseMedicine = false;

        // if (principal instanceof UserDetails) {
        // Object entityDetails = ((MyUserDetailsModel) principal).getUserDetails();
        if (principalDetails instanceof HMSEntity) {

            HMSEntity entity = ((HMSEntity) principalDetails);
            userName = entity.getEntityName();
            dateRegistered = entity.getDateCreated();
            logo = entity.getProfilePic();
            userId = "" + entity.getId();
            entityId = entity.getId();

            practiceConsultationFee = entityHelperBean.getPracticeConsultationFee();
            address = entityHelperBean.getAddressString();
            entityDispenseMedicine = entityHelperBean.isEntityDispenseMedicine();

        } else if (principalDetails instanceof Employee) {

            Employee employee = ((Employee) principalDetails);
            userName = employee.getFullName() + " " + employee.getLastName();
            dateRegistered = employee.getDateCreated();
            logo = employee.getPhoto();

            userId = employee.getIdentityNumber();
            entityId = employee.getEntity().getId();

            practiceConsultationFee = entityHelperBean.getPracticeConsultationFee();
            address = entityHelperBean.getAddressString();
            entityDispenseMedicine = entityHelperBean.isEntityDispenseMedicine();

        } else if (principalDetails instanceof Patient) {

            Patient patient = ((Patient) principalDetails);
            userName = patient.getFullName() + " " + patient.getLastName();
            dateRegistered = patient.getDateCreated();
            logo = patient.getPhoto();

            userId = patient.getIdentityNumber();
        }

        // } else {
        //  userName = principal.toString();
        //  userId = principal.toString();
        // }
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");

        model.addAttribute("logo", logo);
        model.addAttribute("today", formatter.format(new Date()));
        model.addAttribute("loggedUser", userName);
        model.addAttribute("entityType", entityType);
        model.addAttribute("dateRegistered", dateRegistered);
        model.addAttribute("userMenu", redirectBean.getMenuList());
        model.addAttribute("loggedUserPhoto", logo);
        model.addAttribute("practiceAddress", address.toString());
        model.addAttribute("practiceConsultationFee", practiceConsultationFee);
        model.addAttribute("entityDispenseMedicine", entityDispenseMedicine);
        model.addAttribute("entityDoesntDispenseMedicine", entityDispenseMedicine ? false : true);
        model.addAttribute("userId", userId);
        model.addAttribute("entityId", entityId);
        
        System.out.println("Came here!!!!!");

        return null;
    }

    @RequestMapping(value = "/keepAlive", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public void keepAlive() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session = attr.getRequest().getSession(true);
        session.setMaxInactiveInterval(30);
        HMSEntity entity = entityService.findById(1);
    }

}
