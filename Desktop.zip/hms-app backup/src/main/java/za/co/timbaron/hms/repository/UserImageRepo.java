package za.co.timbaron.hms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.enums.UploadTypeEnum;

@Repository
@Transactional
public interface UserImageRepo extends JpaRepository<UserImage, Long> {
    
    UserImage findByUserAndUploadType(User user, UploadTypeEnum uploadType);
    
    List<UserImage> findAllByUserIdNo(String userIdNo);
    
}
