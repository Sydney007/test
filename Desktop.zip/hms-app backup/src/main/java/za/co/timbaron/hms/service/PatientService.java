/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.service;

import java.sql.Date;
import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.Employer;
import za.co.timbaron.hms.entity.EntityPatient;
import za.co.timbaron.hms.entity.Evaluation;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.MedicalAid;
import za.co.timbaron.hms.entity.PatientMedicalProblem;
import za.co.timbaron.hms.entity.PatientMedication;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.PaymentTransaction;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.VisitReferral;
import za.co.timbaron.hms.enums.UploadTypeEnum;


@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface PatientService {

    Patient findById(long id);

    Patient findByIdentityNumber(String identityNumber);

    List<Patient> findAllByEntityId(long entityId);

    List<Visit> findAllPatientVisits(Patient patient);

    List<Visit> findPatientVisitsByDateRange(Patient patient, Date startDate, Date endDate);

    List<Visit> findPatientVisitsByEntity(Patient patient, HMSEntity entity);

    List<Visit> findPatientVisitsByEntityAndDateRange(Patient patient, HMSEntity entity, Date startDate, Date endDate);

    List<Appointment> findAllPatientAppointments(Patient patient);

    List<Long> findAllEntityVisitsByPatient(Patient patient);

    List<Long> findAllPatientVisitsEntitiesByPatientAndDateRange(Patient patient, Date startDate, Date endDate);

    void save(Patient patient);

    void delete(Patient patient);

    EntityPatient findEntityPatientByIdNo(String identityNumber);

   // Employer findEmployerByPatientId(long patientId);

    MedicalAid findPatientMedicalAidByIdNo(String identityNumber);
    
    List<PaymentTransaction> findPatientWalletTransactionsByIdNo(String identityNumber);

    List<Visit> findPatientReferralVisitsByIdNo(Patient patient);

    UserImage findImageByIdNoAndUploadTypeId(UploadTypeEnum uploadType, User user);

    List<Invoice> findPatientInvoicesByIdNo(String identityNumber);

    VisitReferral findVisitReferralByVisitId(Long visitId);

    List<PatientMedicalProblem> findPatientMedicalProblemsByPatient(long patientId);

    List<PatientMedication> findPatientMedicationById(long patientId);

    List<UserImage> findPatientScansByIdNo(String identityNumber);

    List<Evaluation> findPatientPatientEvaluationsByIdNo(String identityNumber);
    
    void persistObject(Object entity);

}
