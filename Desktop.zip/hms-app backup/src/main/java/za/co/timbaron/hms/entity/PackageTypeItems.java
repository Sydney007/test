package za.co.timbaron.hms.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "HMS_PACKAGE_TYPE_ITEMS")
public class PackageTypeItems implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "MENUID", unique = true)
    private long menuId;

    @Column(name = "SYSTEMACTION", unique = true)
    private String systemAction;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MENUID", referencedColumnName = "ID", insertable = false, updatable = false)
    private Menu menu = new Menu();

    @JsonManagedReference
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PACKAGETYPEID", referencedColumnName = "ID", insertable = false, updatable = false)
    private PackageType packageType;
}
