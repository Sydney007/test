package za.co.timbaron.hms.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "HMS_PACKAGE_TYPE")
public class PackageType implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "DESCRIPTION", unique = true)
    private String description;

    @Column(name = "AMOUNT", unique = true)
    private BigDecimal amount;

    @JsonBackReference
    @OneToMany(mappedBy = "packageType")
    private List<PackageTypeItems> packageItems = new ArrayList();
}
