/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.DiagnosisStatusEnum;

@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = " HMS_VITALS")
public class Vital implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "BP_SYSTOLIC", unique = true, nullable = false)
    private String bpSystolic;

    @Column(name = "BP_DISTOLIC", unique = true, nullable = false)
    private long bpDistolic;

    @Column(name = "PULSE", unique = true, nullable = false)
    private String pulse;

    @Column(name = "RESPIRATION", unique = true, nullable = false)
    private String respiration;

    @Column(name = "TEMPERATURE", unique = true, nullable = false)
    private String temperature;

    @Column(name = "WEIGHT", unique = true, nullable = false)
    private String weight;

    @Column(name = "BLOODPRESSURE", unique = true, nullable = false)
    private String bloodPressure;

    @Column(name = "OXYGEN_SATURATION", unique = true, nullable = false)
    private String oxygenSaturation;

    @Column(name = "HEAD_CIRCUMFERENCE", unique = true)
    private String headCircumference;

    @Column(name = "WAIST_CIRCUMFERENCE", unique = true)
    private String waistCircumference;

    @Column(name = "BMI", unique = true, nullable = false)
    private String bmi;

    @Column(name = "CHOLESTEROL", unique = true, nullable = false)
    private String cholesterol;

    @Column(name = "DATERECORDED", unique = true, nullable = false)
    private Timestamp dateRecorded;

    @Column(name = "EMPLOYEEID", unique = true, nullable = false)
    private long employeeId;

    @Column(name = "PATIENTID", unique = true, nullable = false)
    private long patientId;

    @Enumerated(EnumType.STRING)
    @Column(name = "HEALTH_STATUS", unique = true, nullable = false)
    private DiagnosisStatusEnum diagnosesStatus;

    @Transient
    private boolean newRecord;

    @Transient
    private long rowNumber;

    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;

}
