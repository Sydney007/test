package za.co.timbaron.hms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.VisitReferral;

@Repository
@Transactional
public interface VisitReferralRepo extends JpaRepository<VisitReferral, Long> {

    List<VisitReferral> findAllByVisitId(long visitId);

    VisitReferral findByVisitId(long visitId);

}
