package za.co.timbaron.hms.entity;

import java.util.List;
import lombok.Data;
import za.co.timbaron.hms.enums.CD4CountEnum;
import za.co.timbaron.hms.enums.DiagnosisStatusEnum;
import za.co.timbaron.hms.enums.SupplierEnum;

@Data
public class DropDownValuesUtil {

    private List<CD4CountEnum> cd4CountList;
    private List<SocialHistoryValues> socialHistory;
    private List<DiagnosisStatusEnum> diagnosisStatus;
    private List<VisitType> visitTypes;

    private List<AccountType> accountTypes;
    private List<PackageType> packageTypes;

    private List<RoomType> roomTypes;
    private List<SupplierEnum> suppliers;

}
