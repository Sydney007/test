package za.co.timbaron.hms.util;

import java.util.List;
import org.springframework.stereotype.Component;
import za.co.timbaron.hms.entity.DropDownValuesUtil;
import za.co.timbaron.hms.entity.User;

@Component
public class HMSUtilRepo {

    public String getMaxValue(String className, String field) throws Exception {
        return null;
    }

    public List lookUp(String searchString, String className, String searchField) throws Exception {
        return null;
    }

    public User checkUserAvailability(String username) {
        return null;
    }

    public DropDownValuesUtil getDropDownValuesUtil(long entityId) throws Exception {
        return null;
    }

    public List findAllById(long id, String className) throws Exception {
        return null;
    }

    public void delete(String className, long id) throws Exception {
    }

}
