package za.co.timbaron.hms.util;

import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.css.CssFile;
import com.itextpdf.tool.xml.css.StyleAttrCSSResolver;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.parser.XMLParser;
import com.itextpdf.tool.xml.pipeline.css.CSSResolver;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import org.dom4j.DocumentException;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.Visit;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.WordUtils;
import org.springframework.beans.factory.annotation.Value;
import za.co.timbaron.hms.entity.PatientVisitsGroupedByEntity;
import za.co.timbaron.hms.entity.VisitTreatment;

/**
 *
 * @author Matimba
 */
public class DocumentUtil {

    @Value("${images.location}")
    private String imagesLocation;

    private final int TOTAL_NUM_ROWS = 27;
    private final int DOC_BODY_NUM_ROWS = 19;
    public static final String DEST = "results/xmlworker/html_table_1.pdf";
    public static final String CSS = "table{width:100%; "
            + " line-height: inherit;"
            + "list-style: none;"
            + "    margin: 0;"
            + "font-size:9px;font-family: Brave Sans; overflow: auto; padding: 0.3in;"
            + "} "
            + ".table-items {vertical-align: top;}"
            + ".items-th {color: #fff; height: 5px;font-size:10px;font-family: Brave Sans; border: 1px #23527c; background-color: #23527c;text-align:center;}"
            + ".odd{background-color: #fff; height: 15px;}\n"
            + ".even{background-color: #EEE; height: 5px;}"
            + ""
            + " p {font: bold 100% sans-serif; font-style: italic; color:#23527c;}\n"
            + ".sub-header{font-style:italic; font-size: 70%; font-weight:normal; text-align: center; margin: 0.5em;}"
            + ""
            + ".noborder{border: 0px #BBB; padding:3px;}"
            + "th { background: #EEE; padding:2px;}"
            + "td { padding:2px;}"
            + ".balance-total {color: #fff; font-size:10px; font-family: Brave Sans; border: 1px #23527c; background-color: #23527c;}"
            + ".balance-th {height:15px;font-size:8px;font-family: Brave Sans; border: 1px #fff; background-color: #EEE; text-align:left; font-weight: bold;}"
            + ".balance-td {font-size:8px;font-family: Brave Sans; border: 1px #fff;  text-align:right;font-weight: bold;}"
            + ".balance-th-tot {font-size:8px;font-family: Brave Sans; border: 1px #23527c; background-color: #23527c; text-align:left;font-weight: bold;}"
            + ".balance-td-tot {font-size:8px;font-family: Brave Sans; border: 1px #23527c; background-color: #23527c; text-align:right;font-weight: bold;}"
            + "h1{text-transform: uppercase}"
            + "h2{text-transform: uppercase;text-align:left;font-family: Algerian; color: #23527c; font-size: 8px;}"
            + "h3{text-transform: uppercase;text-align:left;font-family: Algerian; color: #23527c; font-size: 7px;}"
            + ""
            + "";

    private static String userDir = System.getProperty("user.dir");
    private static String imagesFolder = userDir + "/src/main/webapp/resources/images/";

    /*
    public static void main(String[] args) throws IOException, com.itextpdf.text.DocumentException, DocumentException {
        File file = new File(DEST);
        file.getParentFile().mkdirs();
        //new DocumentUtil().generateInvoice(DEST);
        DocumentUtil util = new DocumentUtil();

        Timestamp now = new Timestamp(new java.util.Date().getTime());

        StringBuilder message = new StringBuilder("<p>A great property for a young family or business professional looking for the convenient lock up and go home in a secure environment.\n"
                + "This lovely unit is located in Dekko Heights complex, which is arguably one of the most sought after complexes in Halfway Gardens. Dekko Heights is located on Smuts Drive, "
                + "which offers great access to the surrounding schools, shopping centers and major routes.</p>");

        Suburb s = new Suburb();
        s.setArea("Midrand");
        s.setCity("Midrand");
        s.setName("Halfway Gardens");
        s.setPostalCode("1686");

        HMSEntity entity = new HMSEntity();
        entity.setLogo("src/main/resources/images/logo1.PNG");
        entity.setEntityName("Xigalo Clinic");
        entity.setEntitySubNameGroup("");
        entity.setAddressLine1("1 Scot street");
        entity.setAddressLine2("Smuts and 3rd Road");
        entity.setSuburb(s);
        entity.setTelephone("0115077809");
        entity.setRegistrationNumber("9005674");
        entity.setEmail("info@xigaloclinic.co.za");
        entity.setFaxNumber("0115071234");

        Visit visit = new Visit();
        visit.setVisitId(1);
        visit.setVisitDate(now);

        visit.setEntity(entity);

        Employee refDoc = new Employee();
        refDoc.setTitle(TitleEnum.MR);
        refDoc.setFullName("MIke Ikes");
        refDoc.setLastName("Dukes");

        VisitReferral referralBean = new VisitReferral();
        referralBean.setReferredToDoctor(refDoc);
        referralBean.setRemarks(message.toString());
        visit.setReferralBean(referralBean);

        SickNote sickNoteBean = new SickNote();
        sickNoteBean.setFromDate(now);
        sickNoteBean.setToDate(now);
        sickNoteBean.setReturnDate(now);
        sickNoteBean.setNatureOfSickness(message.toString());

        visit.setSickNoteBean(sickNoteBean);

        Invoice invoice = new Invoice();
        invoice.setInvoiceDate(now);

        // util.generateInvoice(invoice, entity, new Patient(), "invoice.pdf", visit);
        //  util.generateReferralLetter(entity, new Patient(), "referral-letter.pdf", visit, "audiology referral letter", "PIMS2342678");
        //  util.generateSickNote(entity, new Patient(), "sicknote.pdf", visit);
        List<PatientVisitsGroupedByEntity> visits = new ArrayList();
        util.generateMedicalHistoryDoc(entity, new Patient(), "8303285920088_medicalHistory.pdf", visits);

    }*/
    /**
     * Creates a PDF with invoice details
     *
     * @param invoice
     * @param entity
     * @param invoiceFile
     * @param visitDetails
     * @param patient
     * @return
     * @throws IOException
     * @throws com.itextpdf.text.DocumentException
     * @throws DocumentException
     */
    public boolean generateInvoice(Invoice invoice, HMSEntity entity, Patient patient, String invoiceFile, Visit visitDetails) throws IOException, com.itextpdf.text.DocumentException {

        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(invoiceFile));
        SimpleDateFormat Dateformatter = new SimpleDateFormat("EEE, dd MMM yyyy");
        document.open();

        String entityLogo = entity.getLogo().replace(imagesLocation, "");
        String logo = imagesFolder + entityLogo;

        StringBuilder sb = new StringBuilder();
        sb.append("<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" \n"
                + "style=\"border-collapse: collapse; background-color: white;\">\n"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "<td >\n"
                + "<img src=\"" + logo + "\" width=\"150px\" height'\"150px\" alt=\"\"/>\n"
                + "</td>\n"
                + "\n"
                + "<td style=\"text-indent: 0px; font-style:italic; vertical-align: middle; text-align: right;\">\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 14px; \"><h1>" + entity.getEntityName() + "</h1></span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getEntitySubNameGroup() + "</span><br/><br/>\n"
                //+ "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine1() + "</span><br/>\n"
                //+ "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine2() + "</span><br/>\n"
                //+ "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\">" + entity.getSuburb().getName()
//                + ", " + entity.getSuburb().getArea() + " , " + entity.getSuburb().getPostalCode() + "</span><br/><br/>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "\n"
                + "<td style=\"text-indent: 0px;  vertical-align: middle;text-align: left;\" colspan=\"2\">\n"
                + "<table cellpadding=\"1\" cellspacing=\"1\" width=\"30%\" style=\"margin-left:0;\">\n"
                + "<tr>\n"
                + "<td valign=\"top\" style=\"vertical-align: middle;text-indent: 0px;font-family: Algerian; width: 6.5%;font-size:11px;\">Bill To:</td>\n"
                + "<td style=\"text-indent: 0px; font-style:italic; vertical-align: middle; text-align: left;\" rowspan=\"2\" width=\"70%\">\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 12px; \">" + patient.getTitle() + " " + patient.getFullName() + " " + patient.getLastName() + "</span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size:8px;\">" + patient.getAddress().getAddressLine1() + "</span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + patient.getAddress().getAddressLine1() + "</span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + patient.getAddress().getCity() + "</span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\">" + patient.getAddress().getProvince()
                + " , " + patient.getAddress().getPostalCode() + "</span>"
                + "</td>\n"
                + " <td style=\"text-align: right;vertical-align: middle;text-indent: 0px;font-family: Algerian; width: 20%;font-size:11px;\">"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>T.</p>&nbsp; " + entity.getTelephone() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>F.</p>&nbsp;" + entity.getFaxNumber() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>E.</p>&nbsp; " + entity.getEmail() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>Pr No.</p>&nbsp; " + entity.getRegistrationNumber() + "</span> \n"
                + "</td>\n"
                + "   </tr>\n"
                + "    <tr>     \n"
                + "       <td></td>\n"
                + "   </tr>\n"
                + "  \n"
                + "</table>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr valign=\"top\">\n"
                + "<td width=\"70%\">"
                + "</td>\n"
                + "<td align=\"right\" width=\"30%\">\n"
                + "  <span style=\"font-family: Algerian; color: #23527c; font-size: 12px; \">Invoice No# " + invoice.getInvoiceNo() + "</span><br/>\n"
                + "  <span style=\"font-family: Brave Sans; color: #000000; font-size:8px;\">Date Issued: " + Dateformatter.format(invoice.getInvoiceDate()) + "</span><br/>\n"
                + "</td>\n"
                + "</tr>\n"
                + "\n"
                + "<tr>\n"
                + "<td height=\"20px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td valign=\"top\" colspan=\"2\" height=\"400px\">\n"
                + "<table class=\"table-items\"  cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"right:0;\">\n"
                + "<tr>\n"
                + "<th class=\"items-th\">ITEM</th>\n"
                + "<th class=\"items-th\">DESCRIPTION</th>\n"
                + "<th class=\"items-th\">QTY</th>\n"
                + "<th class=\"items-th\">UNIT PRICE</th>\n"
                + "<th class=\"items-th\" align=\"right\">TOTAL</th>\n"
                + "</tr>\n");

        String style = "";
        String lastStyledRow = null;

        int numberOfEmptyRows = TOTAL_NUM_ROWS - invoice.getInvoiceItems().size();
        int j = 0;

        for (VisitTreatment item : invoice.getInvoiceItems()) {

            if (j % 2 == 0) {
                style = "even";
            } else {
                style = "odd";
            }

            lastStyledRow = style;

            sb.append("<tr class=\"" + style + "\">"
                    + "<td>" + item.getTreatment() + "</td>\n"
                    + "<td>" + item.getDescription() + "</td>\n"
                    + " <td align=\"center\">" + item.getQuantity() + "</td>\n"
                    + " <td align=\"right\">" + item.getAmount() + "</td>\n"
                    + " <td align=\"right\">" + item.getTotalAmount() + "</td>\n"
                    + "</tr>");
            j++;
        }

        //Insert empty rows
        for (int i = 0; i < numberOfEmptyRows; i++) {

            if (lastStyledRow != null) {
                if (lastStyledRow.matches("even")) {
                    style = "odd";
                } else {
                    style = "even";
                }

                lastStyledRow = style;
            } else {
                if (i % 2 == 0) {
                    style = "even";
                } else {
                    style = "odd";
                }
            }

            sb.append("<tr class=\"" + style + "\">"
                    + "<td>&nbsp;</td>\n"
                    + " <td></td>\n"
                    + " <td align=\"center\"></td>\n"
                    + " <td align=\"right\"></td>\n"
                    + " <td align=\"right\"></td>\n"
                    + "</tr>");
        }

        sb.append("</table>\n"
                + "</td>\n"
                + "</tr>\n"
                + "\n"
                + "<tr>\n"
                + "<td height=\"20px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "</table>"
                + ""
                + "<table>"
                + "<tr>"
                + "<td width=\"80%\" rowspan=\"5\" valign=\"top\" style=\"background-color: #EEE;\">"
                + "<table>"
                + "<tr>"
                + "<td align=\"center\" width=\"25%\">"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\">"
                + "Scan with <p>Zapper </p>&nbsp; to pay "
                + "</span><br/>\n"
                + "<img src=\"src/main/resources/images/qr.PNG\" width=\"100px\" height'\"100px\" alt=\"\"/>\n"
                + "</td>"
                + "<td align=\"center\">"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;text-align:center;\">"
                + "The <p>Zapper </p>&nbsp; App is available from "
                + "</span><br/><br/><br/>\n"
                + "<img src=\"src/main/resources/images/apple-store.PNG\" width=\"80px\" height=\"20px\" alt=\"\"/>&nbsp;&nbsp;\n"
                + "<img src=\"src/main/resources/images/google-play.PNG\" width=\"80px\" height=\"20px\" alt=\"\"/>&nbsp;&nbsp;\n"
                + "<img src=\"src/main/resources/images/windows-store.PNG\" width=\"80px\" height=\"20px\" alt=\"\"/><br/><br/><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\">"
                + "A free, Safe and Secure Service by <p>Zapper </p>. <p>www.zapper.com</p>"
                + "</span>\n"
                + "</td>"
                + "<td align=\"center\" width=\"25%\">"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491; text-align:center;\">"
                + "Pay with "
                + "</span><br/>\n"
                + "<img src=\"src/main/resources/images/master.PNG\" width=\"30px\" height'\"30px\" alt=\"\"/>\n"
                + "<img src=\"src/main/resources/images/visa.PNG\" width=\"30px\" height'\"30px\" alt=\"\"/>\n"
                + "<img src=\"src/main/resources/images/paypal.PNG\" width=\"30px\" height'\"30px\" alt=\"\"/>\n"
                + "</td>"
                + "</tr>"
                + "</table>"
                + "</td>"
                + "<td width=\"20%\">"
                + "<table class=\"balance\" cellpadding=\"0\" cellspacing=\"0\" width=\"30%\" style=\"margin-right:0;\" style=\"text-align: right; right:0\">\n"
                + "     <tr>\n"
                + "      <th class=\"balance-th\">Sub Total</th>\n"
                + "      <td height=\"20px\" class=\"balance-td\">R" + invoice.getBalanceDue() + "</td>\n"
                + "   </tr>\n"
                + "   <tr>\n"
                + "    <th class=\"balance-th\">VAT @ 15%</th>\n"
                + "    <td height=\"20px\" class=\"balance-td\">R" + invoice.getTax() + "</td>\n"
                + "  </tr>\n"
                + "  <tr>\n"
                + "    <th class=\"balance-th\">Total</th>\n"
                + "    <td height=\"20px\" class=\"balance-td\">R" + invoice.getTotalBalanceDue() + "</td>\n"
                + "  </tr>\n"
                + "  <tr>\n"
                + "    <th class=\"balance-th\">Amount Paid</th>\n"
                + "    <td height=\"20px\" class=\"balance-td\">R" + invoice.getAmountPaid() + "</td>\n"
                + "  </tr>\n"
                + "  <tr class=\"balance-total\">\n"
                + "    <td class=\"balance-th-tot\">Total Due</td>\n"
                + "    <td height=\"20px\" class=\"balance-td-tot\">R" + invoice.getTotalBalanceDue() + "</td>\n"
                + "  </tr>\n"
                + "</table>\n"
                + "</td>"
                + "</tr>"
                + "</table>");

        CSSResolver cssResolver = new StyleAttrCSSResolver();
        CssFile cssFile = XMLWorkerHelper.getCSS(new ByteArrayInputStream(CSS.getBytes()));
        cssResolver.addCss(cssFile);

        // HTML
        HtmlPipelineContext htmlContext = new HtmlPipelineContext(null);
        htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());

        // Pipelines
        PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
        HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
        CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

        // XML Worker
        XMLWorker worker = new XMLWorker(css, true);
        XMLParser p = new XMLParser(worker);
        p.parse(new ByteArrayInputStream(sb.toString().getBytes()));

        document.close();
        return true;
    }

    public boolean generateReferralLetter(HMSEntity entity, Patient patient, String referralLetter, Visit visitDetails, String referralReason, String referenceNumber) throws IOException, DocumentException, com.itextpdf.text.DocumentException {

        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(referralLetter));
        document.open();

        String entityLogo = entity.getLogo().replace(imagesLocation, "");
        String logo = imagesFolder + entityLogo;

        StringBuilder sb = new StringBuilder();
        sb.append("<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" \n"
                + "style=\"border-collapse: collapse; background-color: white;\">\n"
                + "<tr valign=\"top\">\n"
                + "<td >\n"
                + "<img src=\"" + logo + "\"  width=\"380px\"/>\n"
                + "</td>\n"
                + "<td style=\"text-indent: 0px; font-style:italic; vertical-align: middle; text-align: right;\">\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 14px; \"><h1>" + entity.getEntityName() + "</h1></span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getEntitySubNameGroup() + "</span><br/><br/>\n"
                //+ "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine1() + "</span><br/>\n"
                //+ "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine2() + "</span><br/>\n"
                //+ "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\">" + entity.getSuburb().getName()
                //+ ", " + entity.getSuburb().getArea() + " , " + entity.getSuburb().getPostalCode() + "</span><br/><br/>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "<td>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td colspan=\"2\" style=\"border-width: 1px; border-color: #23527c  white white white; text-align:center\">"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>T.</p>&nbsp; " + entity.getTelephone() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>F.</p>&nbsp;" + entity.getFaxNumber() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>E.</p>&nbsp; " + entity.getEmail() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>Pr No.</p>&nbsp; " + entity.getRegistrationNumber() + "</span> \n"
                + "</td>"
                + "</tr>"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "<td>\n"
                + "</td>\n"
                + "</tr>\n"
                + "</table>"
                + ""
                + "<table>"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\">\n"
                + "  <span style=\"font-family: Algerian; color: #23527c; font-size: 10px; \"><h1>" + referralReason + "</h1></span><br/>\n"
                + "</td>\n"
                + "</tr>"
                + "<tr>\n"
                + "<td height=\"20px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "</table>"
                + ""
                + "<table style=\"text-align:center;font-family: Algerian;border:1px #23527c;\">\n"
                + "<tr>\n"
                + "<td height=\"15px\">\n"
                + "</td>\n"
                + "</tr>"
                + "<tr>"
                + "<td>\n"
                + "To\n"
                + "</td>\n"
                + "<td>\n"
                + "<span>" + UppercaseUtil.uppercaseFirstLetter(visitDetails.getReferralBean().getReferredToDoctor().getTitle().name()) + " " + visitDetails.getReferralBean().getReferredToDoctor().getFullName() + " " + visitDetails.getReferralBean().getReferredToDoctor().getLastName() + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-------------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "<td width=\"4%\">\n"
                + "Date\n"
                + "</td>\n"
                + "<td>\n"
                + "<span>" + visitDetails.getVisitDate() + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td width=\"15%\">\n"
                + "Patient Name\n"
                + "</td>\n"
                + "<td>\n"
                + "<span>" + UppercaseUtil.uppercaseFirstLetter(patient.getTitle().name()) + " " + patient.getFullName() + " " + patient.getLastName() + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-------------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "<td >\n"
                + "Age\n"
                + "</td>\n"
                + "<td>\n"
                + "<span>" + patient.getDob() + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td>\n"
                + "Reference Number\n"
                + "</td>\n"
                + "<td>\n"
                + "<span><h1>" + referenceNumber + "</h1></span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-------------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "</table>"
                + ""
                /*      
                 */
                + generateTableBodyWithContents("Reason for referral", visitDetails.getReferralBean().getRemarks(), 16)
                /*      
                 */
                + ""
                + "<table style=\"text-align:center;font-family: Algerian;\">\n"
                + "<tr>\n"
                + "<td height=\"75px\">\n"
                + "</td>\n"
                + "</tr>"
                + "<tr>"
                + "<td>\n"
                + "From\n"
                + "</td>\n"
                + "<td>\n"
                //                + "<span>" + UppercaseUtil.uppercaseFirstLetter(visitDetails.getDoctor().getTitle().name()) + " " + visitDetails.getDoctor().getFullName() + " " + visitDetails.getDoctor().getLastName() + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "------------------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "<td width=\"7%\">\n"
                + "Signature\n"
                + "</td>\n"
                + "<td>\n"
                + "<span></span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td colspan =\"2\" height=\"45px\">\n"
                + "</td>\n"
                + "</tr>"
                + "<tr>"
                + "<td width=\"5%\">\n"
                + "Stamp\n"
                + "</td>\n"
                + "<td>\n"
                + "<span></span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "------------------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "</table>"
        );

        CSSResolver cssResolver = new StyleAttrCSSResolver();
        CssFile cssFile = XMLWorkerHelper.getCSS(new ByteArrayInputStream(CSS.getBytes()));
        cssResolver.addCss(cssFile);

        // HTML
        HtmlPipelineContext htmlContext = new HtmlPipelineContext(null);
        htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());

        // Pipelines
        PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
        HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
        CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

        // XML Worker
        XMLWorker worker = new XMLWorker(css, true);
        XMLParser p = new XMLParser(worker);
        p.parse(new ByteArrayInputStream(sb.toString().getBytes()));

        document.close();
        return true;
    }

    public boolean generateSickNote(HMSEntity entity, Patient patient, String sickNote, Visit visitDetails) throws IOException, DocumentException, com.itextpdf.text.DocumentException {

        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(sickNote));
        SimpleDateFormat Dateformatter = new SimpleDateFormat("yyyy-MM-dd");
        document.open();

        String entityLogo = entity.getLogo().replace(imagesLocation, "");
        String logo = imagesFolder + entityLogo;

        StringBuilder sb = new StringBuilder();
        sb.append("<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" \n"
                + "style=\"border-collapse: collapse; background-color: white;\">\n"
                + "<tr valign=\"top\">\n"
                + "<td >\n"
                + "<img src=\"" + logo + "\" width=\"380px\"/>\n"
                + "</td>\n"
                + "<td style=\"text-indent: 0px; font-style:italic; vertical-align: middle; text-align: right;\">\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 14px; \"><h1>" + entity.getEntityName() + "</h1></span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getEntitySubNameGroup() + "</span><br/><br/>\n"
//                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine1() + "</span><br/>\n"
  //              + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine2() + "</span><br/>\n"
    //            + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\">" + entity.getSuburb().getName()
      //          + ", " + entity.getSuburb().getArea() + " , " + entity.getSuburb().getPostalCode() + "</span><br/><br/>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "<td>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td colspan=\"2\" style=\"border-width: 1px; border-color: #23527c  white white white; text-align:center\">"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>T.</p>&nbsp; " + entity.getTelephone() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>F.</p>&nbsp;" + entity.getFaxNumber() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>E.</p>&nbsp; " + entity.getEmail() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>Pr No.</p>&nbsp; " + entity.getRegistrationNumber() + "</span> \n"
                + "</td>"
                + "</tr>"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "<td>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\">\n"
                + "  <span style=\"font-family: Algerian; color: #23527c; font-size: 12px; \">MEDICAL CERTIFICATE</span><br/>\n"
                + "  <span style=\"font-family: Algerian; color: #23527c; font-size: 8px; \">THIS IS TO CERTIFY THAT</span><br/>\n"
                + "</td>\n"
                + "</tr>"
                + "\n"
                + "<tr>\n"
                + "<td height=\"20px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "</table>"
                + ""
                + "<table style=\"text-align:center;font-family: Algerian;\">\n"
                + "<tr>\n"
                + "<td  valign=\"bottom\" colspan=\"2\">\n"
                + "<span>" + UppercaseUtil.uppercaseFirstLetter(patient.getTitle().name()) + " " + patient.getFullName() + " " + patient.getLastName() + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                + "------------------------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td height=\"15px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td width=\"11%\" style=\"text-align:left;\">\n"
                + "Consulted me on\n"
                + "</td>\n"
                + "<td>\n"
                + "<span>" + Dateformatter.format(visitDetails.getVisitDate()) + "</span><br/>\n"//color: #23527c;
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                + "---------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>                  \n"
                + "</table>\n"
                + "\n"
                + "<table style=\"text-align:center;font-family: Algerian;\">\n"
                + "<tr>\n"
                + "<td height=\"15px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td colspan=\"4\" style=\"text-align:left;\">\n"
                + "He/She is not fit for work/School\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td height=\"15px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "</table>"
                + "\n"
                + "<table style=\"text-align:center;font-family: Algerian;\">\n"
                + "<tr>\n"
                + "<td width=\"4%\">\n"
                + "From\n"
                + "</td>\n"
                + "<td width=\"46%\">\n"
                //                + "<span>" + Dateformatter.format(visitDetails.getSickNoteBean().getFromDate()) + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; font-size: 8px; top:35px; position:absolute;\">"
                + "--------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "<td width=\"2%\">\n"
                + "To\n"
                + "</td>\n"
                + "<td width=\"48%\">\n"
                //                + "<span>" + visitDetails.getSickNoteBean().getToDate() + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; font-size: 8px; top:35px; position:absolute;\">"
                + "---------------------------------------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "</table>\n"
                + "\n"
                + "<table style=\"text-align:center;font-family: Algerian;\">\n"
                + "<tr>\n"
                + "<td height=\"15px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td width=\"25%\" style=\"text-align:left;\">\n"
                + "He/She will be fit to resume duty on\n"
                + "</td>\n"
                + "<td>\n"
                //                + "<span>" + Dateformatter.format(visitDetails.getSickNoteBean().getReturnDate()) + "</span><br/>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; top:35px; position:absolute;\">"
                + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                + "-----------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>\n"
                + "</table>\n"
                + "\n"
                /*
                
                 */
                //                + generateTableBodyWithContents("Nature of illness", visitDetails.getSickNoteBean().getNatureOfSickness(), 14)
                /*
                
                 */
                + "<table>"
                + "<tr>\n"
                + "<td height=\"80px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td style=\"text-align:center; width: 20%;\">"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\"></span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">"
                + "_________________________________</span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">Stamp</span>\n"
                + "</td>"
                + ""
                + "<td width=\"60%\">"
                + "</td>"
                + "<td style=\"text-align:center; width: 20%;\">"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">" + Dateformatter.format(visitDetails.getVisitDate()) + "</span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">"
                + "_________________________________</span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">Date</span>\n"
                + "</td>"
                + "</tr>"
                + "</table>");

        CSSResolver cssResolver = new StyleAttrCSSResolver();
        CssFile cssFile = XMLWorkerHelper.getCSS(new ByteArrayInputStream(CSS.getBytes()));
        cssResolver.addCss(cssFile);

        // HTML
        HtmlPipelineContext htmlContext = new HtmlPipelineContext(null);
        htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());

        // Pipelines
        PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
        HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
        CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

        // XML Worker
        XMLWorker worker = new XMLWorker(css, true);
        XMLParser p = new XMLParser(worker);
        p.parse(new ByteArrayInputStream(sb.toString().getBytes()));

        document.close();
        return true;
    }

    public boolean generateMedicalHistoryDoc(HMSEntity entity, Patient patient, String medicalHistoryDoc, List<PatientVisitsGroupedByEntity> visits) throws IOException, DocumentException, com.itextpdf.text.DocumentException {

        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(medicalHistoryDoc));
        SimpleDateFormat Dateformatter = new SimpleDateFormat("yyyy-MM-dd");

        String entityLogo = entity.getLogo().replace(imagesLocation, "");
        String logo = imagesFolder + entityLogo;

        document.open();

        StringBuilder body = new StringBuilder();

        visits.stream().map((visitsGroupedByEntity) -> {
            body.append("<ul>");
            body.append("<li><h1 style=\"text-align:left;font-family: Algerian; color: #23527c; font-size: 10px; \">")
                    .append(visitsGroupedByEntity.getEntity().getEntityName())
                    .append("</h1><br/></li>");
            return visitsGroupedByEntity;
        }).map((visitsGroupedByEntity) -> {
            visitsGroupedByEntity.getVisits().stream().map((visit) -> {
                body.append("<li>");
                //
                body.append("<div class=\"timeline-item\">");
                //Visit reason
                String doctor = "";//UppercaseUtil.uppercaseFirstLetter(visit.getDoctor().getTitle().name()) + " " + visit.getDoctor().getFullName() + " " + visit.getDoctor().getLastName();
                body.append("<h3 class=\"timeline-header\">").append(visit.getVisitReason())
                        .append(" (").append(doctor).append(")<br/> <small>").append(visit.getVisitDate()).append("</small></h3><br/>");
                return visit;
            }).map((visit) -> {
                /**/
                body.append("<div class=\"timeline-body\">");
                //Treatments
                body.append("<div class=\"x_panel\">\n"
                        + "       <div class=\"x_title\">\n"
                        + "           <h2>Treatments</h2>          \n"
                        + "           <div class=\"clearfix\"></div>\n"
                        + "       </div>\n"
                        + "       <div class=\"x_content\">\n"
                        + "           <ul class=\"list-unstyled msg_list\">\n");
                /*visit.getVisitTreatmentItems().forEach((treatment) -> {
                    body.append("  <li>\n <a>\n <i>\n  <h3>").append(treatment.getTreatment()).append("</h3>\n <small class=\"time\">").append(treatment.getVisitDate())
                            .append("</small>\n          </i>\n          <h3>\n").append(treatment.getDescription()).append(" \n          </h3>\n      </a>\n  </li>");
                });*/
                return visit;
            }).map((visit) -> {
                body.append("</ul>\n"
                        + "</div>\n"
                        + "</div>");
                //Treatments
                //Notes
                body.append("<div class=\"x_panel\">\n"
                        + "       <div class=\"x_title\">\n"
                        + "           <h2>Notes</h2>          \n"
                        + "           <div class=\"clearfix\"></div>\n"
                        + "       </div>\n"
                        + "       <div class=\"x_content\">\n"
                        + "           <ul class=\"list-unstyled msg_list\">\n");
                /*for (Note note : visit.getNotes()) {
                    body.append(" <li>\n"
                            + "      <a>\n"
                            + "          <i>\n"
                            + "              <h3>" + UppercaseUtil.uppercaseFirstLetter(note.getDoctor().getTitle().name()) + ".  " + note.getDoctor().getFullName() + " " + note.getDoctor().getLastName() + "</h3>\n"
                            + "              <small class=\"time\">" + note.getNoteDate() + "</small>\n"
                            + "          </i>\n"
                            + "          <h3>\n"
                            + "             " + note.getDescription() + " \n"
                            + "          </h3>\n"
                            + "      </a>\n"
                            + "   </li>");
                }*/
                return visit;
            }).map((visit) -> {
                body.append("</ul>\n"
                        + "</div>\n"
                        + "</div>");
                //Notes
                //Disclosures 
                body.append("<div class=\"x_panel\">\n"
                        + "       <div class=\"x_title\">\n"
                        + "           <h2>Disclosures</h2>          \n"
                        + "           <div class=\"clearfix\"></div>\n"
                        + "       </div>\n"
                        + "       <div class=\"x_content\">\n"
                        + "           <ul class=\"list-unstyled msg_list\">\n");
                /*for (PatientDisclosure disclosure : visit.getDisclosures()) {
                    body.append(" <li>\n"
                            + "      <a>\n"
                            + "          <i>\n"
                            + "              <h3>" + UppercaseUtil.uppercaseFirstLetter(disclosure.getDoctor().getTitle().name()) + ".  " + disclosure.getDoctor().getFullName() + " " + disclosure.getDoctor().getLastName() + "</h3>\n"
                            + "              <small class=\"time\">" + disclosure.getVisitDate() + "</small>\n"
                            + "          </i>\n"
                            + "          <h3>\n"
                            + "             " + disclosure.getDescription() + " \n"
                            + "          </h3>\n"
                            + "      </a>\n"
                            + "   </li>");
                }*/
                return visit;
            }).map((_item) -> {
                body.append("</ul>\n"
                        + "</div>\n"
                        + "</div>");
                //Disclosures
                return _item;
            }).map((_item) -> {
                body.append("</div>");
                /**/
                return _item;
            }).map((_item) -> {
                body.append("</div>");
                return _item;
            }).forEachOrdered((_item) -> {
                body.append("</li>");
            });
            return visitsGroupedByEntity;
        }).forEachOrdered((_item) -> {
            body.append("</ul>");
        });

        StringBuilder sb = new StringBuilder();
        sb.append("<html>\n"
                + "<head>\n"
                + "</head>\n"
                + "<body>"
                + "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" \n"
                + "style=\"border-collapse: collapse; background-color: white;\">\n"
                + "<tr valign=\"top\">\n"
                + "<td >\n"
                + "<img src=\"" + logo + "\" width=\"380px\"/>\n"
                + "</td>\n"
                + "<td style=\"text-indent: 0px; font-style:italic; vertical-align: middle; text-align: right;\">\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 14px; \"><h1>" + entity.getEntityName() + "</h1></span><br/>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getEntitySubNameGroup() + "</span><br/><br/>\n"
//                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine1() + "</span><br/>\n"
  //              + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px;\">" + entity.getAddressLine2() + "</span><br/>\n"
    //            + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\">" + entity.getSuburb().getName()
      //          + ", " + entity.getSuburb().getArea() + " , " + entity.getSuburb().getPostalCode() + "</span><br/><br/>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "<td>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td colspan=\"2\" style=\"border-width: 1px; border-color: #23527c  white white white; text-align:center\">"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>T.</p>&nbsp; " + entity.getTelephone() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>F.</p>&nbsp;" + entity.getFaxNumber() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>E.</p>&nbsp; " + entity.getEmail() + "</span>\n"
                + "<span style=\"font-family: Brave Sans; color: #000000; font-size: 8px; line-height: 1.1843491;\"><p>Pr No.</p>&nbsp; " + entity.getRegistrationNumber() + "</span> \n"
                + "</td>"
                + "</tr>"
                + "<tr valign=\"top\" style=\"height:20px\">\n"
                + "<td>\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td align=\"center\" colspan=\"2\">\n"
                + "  <span style=\"font-family: Algerian; color: #23527c; font-size: 12px; \">MEDICAL HISTORY</span><br/>\n"
                + "</td>\n"
                + "</tr>"
                + "\n"
                + "<tr>\n"
                + "<td height=\"20px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td colspan=\"2\">\n"
                + "  <span style=\"text-align:right;font-family: Algerian; color: #23527c; font-size: 12px; \">Visit(s) Details</span><br/>\n"
                + "  <span style=\"text-align:right;font-family: Algerian; color: #23527c; font-size: 12px; \">----------------------------------</span><br/>\n"
                + "</td>\n"
                + "</tr>"
                + "\n"
                + "</table>"
                /*
                  body starts
                 */
                + body.toString()
                /*
                    body end
                 */
                + "<table>"
                + "<tr>\n"
                + "<td height=\"80px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>"
                + "<td style=\"text-align:center; width: 20%;\">"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\"></span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">"
                + "_________________________________</span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">Stamp</span>\n"
                + "</td>"
                + ""
                + "<td width=\"60%\">"
                + "</td>"
                + "<td style=\"text-align:center; width: 20%;\">"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">" + Dateformatter.format(new Date()) + "</span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">"
                + "_________________________________</span>\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 8px; line-height: 1.1843491;\">Date</span>\n"
                + "</td>"
                + "</tr>"
                + "</table>"
                + "</body>\n"
                + "</html>"
        );

        CSSResolver cssResolver = new StyleAttrCSSResolver();
        CssFile cssFile = XMLWorkerHelper.getCSS(new ByteArrayInputStream(CSS.getBytes()));
        cssResolver.addCss(cssFile);

        // HTML
        HtmlPipelineContext htmlContext = new HtmlPipelineContext(null);
        htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());

        // Pipelines
        PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
        HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
        CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

        // XML Worker
        XMLWorker worker = new XMLWorker(css, true);
        XMLParser p = new XMLParser(worker);
        p.parse(new ByteArrayInputStream(sb.toString().getBytes()));

        document.close();
        return true;
    }

    private String generateTableBodyWithContents(String fieldText, String message, int width) {

        String paragraph = message.toString().replace("</p>", "").replace("<p>", "");

        String paragraphWithBreak = WordUtils.wrap(paragraph, 120, "<br/>", false);

        String paragraphs[] = paragraphWithBreak.split("<br/>");

        int numParagraphs = paragraphs.length;

        String lineLengthPerWidth = "";
        if (width > 14) {
            lineLengthPerWidth = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";

        } else {
            lineLengthPerWidth = "-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";
        }

        StringBuilder tableRows = new StringBuilder("<table style=\"text-align:center;font-family: Algerian;font-family: Algerian;font-size: 8px;\">\n"
                + "<tr>\n"
                + "<td height=\"30px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td width=\"" + width + "%\" style=\"text-align:left;\">\n"
                + "<span style=\"font-family: Algerian; font-size: 10px; \"> " + fieldText + "</span>"
                + "</td>\n"
                + "<td>\n"
                + "<span>"
                + paragraphs[0] + "</span><br/>\n"
                + "<span>"
                + lineLengthPerWidth
                + "</span>"
                + "</td>\n"
                + "</tr>  \n");

        for (int i = 1; i < numParagraphs; i++) {
            tableRows.append("<tr>"
                    + "<td colspan=\"2\">"
                    + "<span>" + paragraphs[i] + "</span><br/>"
                    + "<span>"
                    + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                    + "------------------------------------------------------------------------------------------------------------------------------"
                    + "</span>"
                    + "</td>"
                    + "</tr>");
        }

        int totalEmptyNumRows = DOC_BODY_NUM_ROWS - numParagraphs;

        for (int i = 1; i < totalEmptyNumRows; i++) {
            tableRows.append("<tr>"
                    + "<td colspan=\"2\">"
                    + "<span></span><br/>"
                    + "<span>"
                    + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                    + "------------------------------------------------------------------------------------------------------------------------------"
                    + "</span>"
                    + "</td>"
                    + "</tr>");
        }

        tableRows.append("</table>");

        return tableRows.toString();

    }
}
