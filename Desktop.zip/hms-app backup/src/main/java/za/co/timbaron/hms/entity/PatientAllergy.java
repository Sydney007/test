/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.AllergyEnum;

/**
 *
 * @author Matimba
 */
@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_PATIENT_ALLERGIES")
public class PatientAllergy implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "EMPLOYEEID", unique = true, nullable = false)
    private long employeeId;

    @Column(name = "PATIENTID", unique = true, nullable = false)
    private long patientId;

    @Enumerated(EnumType.STRING)
    @Column(name = "ALLERGY", unique = true, nullable = false)
    private AllergyEnum allergy;

    @Transient
    private boolean newEntry;

    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;
}
