package za.co.timbaron.hms.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.CountryEnum;
import za.co.timbaron.hms.enums.GenderEnum;
import za.co.timbaron.hms.enums.LanguageEnum;
import za.co.timbaron.hms.enums.MaritalStatusEnum;
import za.co.timbaron.hms.enums.RaceEnum;
import za.co.timbaron.hms.enums.TitleEnum;

@Getter
@Setter
@MappedSuperclass
public class UserDetails {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Transient
    private boolean entityDispenseMedicine;

    @Column(name = "FULLNAME", nullable = false)
    private String fullName;

    @Column(name = "LASTNAME", nullable = false)
    private String lastName;

    @Column(name = "INITIALS", nullable = false)
    private String initials;

    @Column(name = "DOB", nullable = false)
    private String dob;

    @Column(name = "KNOWNAS", nullable = false)
    private String knownAs;

    @Column(name = "PHOTO", nullable = false)
    private String photo;

    @Column(name = "IDENTITYNUMBER", nullable = false)
    private String identityNumber;

    @Column(name = "DATECREATED", nullable = false)
    private Timestamp dateCreated;

    @Column(name = "DATEMODIFIED", nullable = false)
    private Timestamp dateModified;

    @Column(name = "SMOKER", nullable = false)
    private Boolean smoker;

    @Column(name = "CELLNO", nullable = false)
    private String cellNo;

    @Column(name = "TELEPHONE", nullable = false)
    private String telephone;

    @Column(name = "ALTERNATETELEPHONE", nullable = true)
    private String alternateTelephone;

    @Column(name = "EMAIL", nullable = false)
    private String email;

    @Column(name = "DECEASED", nullable = false)
    private Boolean deceased;

    @Column(name = "DATEDECEASED")
    private Timestamp dateDeceased;

    @Enumerated(EnumType.STRING)
    @Column(name = "TITLE", nullable = false)
    private TitleEnum title;

    @Enumerated(EnumType.STRING)
    @Column(name = "RACE", nullable = false)
    private RaceEnum race;

    @Enumerated(EnumType.STRING)
    @Column(name = "GENDER", nullable = false)
    private GenderEnum gender;

    @Enumerated(EnumType.STRING)
    @Column(name = "COUNTRY", nullable = false)
    private CountryEnum country;

    @Enumerated(EnumType.STRING)
    @Column(name = "LANGUAGE", nullable = false)
    private LanguageEnum language;

    @Enumerated(EnumType.STRING)
    @Column(name = "MARITALSTATUS", nullable = false)
    private MaritalStatusEnum maritalStatus;

    @Column(name = "LASTLOGIN", nullable = false)
    private Timestamp lastLogin;

    @Column(name = "USERID", nullable = false)
    private long userId;

    @OneToOne
    @JoinColumn(name = "USERID", referencedColumnName = "ID", insertable = false, updatable = false)
    private User userDetails;

    @Transient
    private Address address;

}
