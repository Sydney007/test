package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.MedicalAidProviderEnum;


@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_MEDICAL_AID")
public class MedicalAid implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "PLAN", unique = true, nullable = false)
    private String plan;

    @Column(name = "BALANCE", unique = true, nullable = false)
    private BigDecimal balance;

    @Column(name = "SAVINGSBALANCE", unique = true, nullable = false)
    private BigDecimal savingsBalance;

    @Column(name = "MEDICALAIDNO", unique = true, nullable = false)
    private String medicalAidNo;

    @Column(name = "EFFECTIVEDATE", unique = true, nullable = false)
    private Date effectiveDate;

    @Column(name = "ACTIVE", unique = true, nullable = false)
    private boolean active;

    @Column(name = "IDENTITYNUMBER", unique = true, nullable = false)
    private String identityNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "PROVIDER", unique = true, nullable = false)
    private MedicalAidProviderEnum provider;

    @OneToOne
    @JoinColumn(name = "USERID", referencedColumnName = "ID")
    private User user;

}
