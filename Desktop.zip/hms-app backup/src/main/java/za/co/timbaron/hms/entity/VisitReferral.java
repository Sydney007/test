/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import za.co.timbaron.hms.enums.EntityTypeEnum;

@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_VISIT_REFERRAL")
public class VisitReferral implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long referralId;

    @Column(name = "REFERRALDATE", unique = true, nullable = false)
    private Timestamp referralDate;

    @Column(name = "REASON", unique = true, nullable = false)
    private String reason;

    @Column(name = "REMARKS", unique = true, nullable = false)
    private String remarks;

    @Column(name = "PATIENTIDNO", unique = true, nullable = false)
    private String patientIdNo;

    @Column(name = "REFERREDBYEMPID", unique = true, nullable = false)
    private long referredByEmpId;

    @Column(name = "REFERREDTOEMPID", unique = true, nullable = false)
    private long referredToEmpId;

    @Column(name = "REFERRALTYPEID", unique = true, nullable = false)
    private long referralTypeId;

    @Column(name = "REFERENCENUMBER", unique = true, nullable = false)
    private String referenceNumber;

    @Transient
    private EntityTypeEnum entityType;

    @Transient
    private String referredByDoctor;

    @Transient
    private Employee referredToDoctor;

    @Column(name = "VISITID", unique = true, nullable = false)
    private long visitId;

    @Column(name = "REFERREDBYENTITYID", unique = true, nullable = false)
    private long referredByEntityId;

    @Column(name = "REFERREDTOENTITYID", unique = true, nullable = false)
    private long referredToEntityId;
   
}
