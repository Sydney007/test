package za.co.timbaron.hms.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import za.co.timbaron.hms.enums.RelationshipEnum;
import za.co.timbaron.hms.enums.TitleEnum;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "HMS_EMERGENCY_CONTACT")
public class EmergencyContact implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "TITLE")
    private TitleEnum title;

    @Column(name = "FIRSTNAME")
    private String firstName;

    @Column(name = "LASTNAME")
    private String lastName;

    @Column(name = "CONTACTNO")
    private String contactNo;

    @Enumerated(EnumType.STRING)
    @Column(name = "RELATIONSHIP")
    private RelationshipEnum relationship;

    @OneToOne
    @JoinColumn(name = "USERID", referencedColumnName = "ID")
    private User user;

}
