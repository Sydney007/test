package za.co.timbaron.hms.enums;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum AllergyEnum {
    EGGS,
    MILK,
    MUSTARD,
    PEANUTS,
    SEAFOOD,
    SOY,
    SULPHITES,
    SMELL,
    TREE_NUTS,
    WHEAT,
    DRUGS,
    FOOD_INTOLERANCE,
    SESAME_AND_OTHER_SEEDS,
    FRUITS,
    DUST,
    ORAL_SYNDROME,
    ALCOHOL_REACTION,
    GENERAL_AVOIDANCE,
    SKIN_ALLERGY,
    SPICES;
}
