package za.co.timbaron.hms.web.security;

import com.google.gson.Gson;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Menu;
import za.co.timbaron.hms.entity.PackageTypeItems;
import za.co.timbaron.hms.entity.RedirectBean;
import za.co.timbaron.hms.entity.Submenu;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.enums.AvailabilityStatusEnum;
import za.co.timbaron.hms.enums.LandingPageEnum;
import za.co.timbaron.hms.enums.PackageTypeEnum;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.service.EmployeeService;
import za.co.timbaron.hms.service.MyUserDetailsModel;
import za.co.timbaron.hms.service.UserService;
import za.co.timbaron.hms.util.EntityHelperBean;
import za.co.timbaron.hms.util.EntityIdAndIDNumberBeanHelper;
import za.co.timbaron.hms.util.UserPrincipalHelper;

/**
 * Spring Security success handler, specialized for Ajax requests.
 */
@Component
public class RestAuthenticationSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    @Autowired
    private RedirectBean redirectBean;

    @Autowired
    private EntityIdAndIDNumberBeanHelper entityIdAndIDNumberBeanHelper;

    @Autowired
    private Gson gson;

    @Autowired
    private UserService userService;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private EntityHelperBean entityHelperBean;

    @Autowired
    private UserPrincipalHelper userprincipalHelper;

    private String landingPage = "";
    private String isActiveMenu = "";

    private static final Logger logger = LoggerFactory.getLogger(RestAuthenticationSuccessHandler.class);

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
            Authentication authentication)
            throws ServletException, IOException {

        Object principal = authentication.getPrincipal();
        User loggedUser = ((MyUserDetailsModel) principal).getLoggedUser();
        Object entityDetails = ((MyUserDetailsModel) principal).getUserDetails();

        String recipient = "";
        String recipientEmail = "";
        String recipientTelephone = "";

        UserTypeEnum userType = loggedUser.getUserType();

        entityIdAndIDNumberBeanHelper.setIdNumber(loggedUser.getIdentityNumber());
        userprincipalHelper.setLoggedUser(loggedUser);
        userprincipalHelper.setUserPrincipal(entityDetails);

        if (entityDetails instanceof HMSEntity) {
            HMSEntity entity = ((HMSEntity) entityDetails);
            entityIdAndIDNumberBeanHelper.setEntityId(entity.getId());

            recipient = entity.getEntityName();
            recipientEmail = entity.getEmail();
            recipientTelephone = entity.getTelephone();

            entityHelperBean.setAddress(entity, recipient, recipientTelephone, recipientEmail);
            entityHelperBean.setPracticeConsultationFee(entity.getConsultationFee());
            entityHelperBean.setEntityDispenseMedicine(entity.isEntityDispenseMedicine());
            entityHelperBean.setEntityName(entity.getEntityName());

        } else if (entityDetails instanceof Employee) {
            Employee employee = ((Employee) entityDetails);
            entityIdAndIDNumberBeanHelper.setEntityId(employee.getEntity().getId());
            entityIdAndIDNumberBeanHelper.setId(employee.getId());

            HMSEntity entity = employee.getEntity();

            recipientEmail = entity.getEmail();
            recipientTelephone = entity.getTelephone();
            recipient = entity.getEntityName();

            entityHelperBean.setAddress(entity, recipient, recipientTelephone, recipientEmail);
            entityHelperBean.setPracticeConsultationFee(entity.getConsultationFee());
            entityHelperBean.setEntityDispenseMedicine(entity.isEntityDispenseMedicine());
            entityHelperBean.setEntityName(entity.getEntityName());

            if (userType != UserTypeEnum.RECEPTIONIST || userType != UserTypeEnum.ENTITY) {
                employee.setAvailabilityStatus(AvailabilityStatusEnum.AVAILABLE);
                Timestamp now = new Timestamp(new java.util.Date().getTime());
                loggedUser.setLastLogin(now);
                employee.setLastLogin(now);
                userService.persistObject(employee);
                userService.saveOrUpdate(loggedUser);
            }
        }

        StringBuilder menuList = new StringBuilder();
        StringBuilder entityManagementSubmenu = new StringBuilder();
        StringBuilder mySpaceSubmenu = new StringBuilder();
        StringBuilder billingSubmenu = new StringBuilder();
        StringBuilder adminSubmenu = new StringBuilder();

        List<PackageTypeItems> menus = ((MyUserDetailsModel) principal).getUserMenu();

        int i = 0;

        for (PackageTypeItems packageType : menus) {
            Menu menu = packageType.getMenu();
            System.out.println(" menu = " + menu.getMenuName());
            PackageTypeEnum userPackageType = PackageTypeEnum.getById(packageType.getPackageType().getId());

            if (menu.isActive()) {

                String href = "href=\"" + menu.getUrl() + "\"";
                String menuName = menu.getMenuName();
                String activeSubmenu = "";
                boolean ariaExpanded = false;

                if (!menu.getSubmenus().isEmpty()) {

                    List<Submenu> subMenusList = menu.getSubmenus();

                    Collections.sort(subMenusList, new Comparator<Submenu>() {
                        public int compare(Submenu o1, Submenu o2) {
                            return o1.getSubMenu().compareTo(o2.getSubMenu());
                        }
                    });

                    for (Submenu subMenu : subMenusList) {

                        if (subMenu.isActive()) {

                            if (menu.getUrl().matches("MySpace") && subMenu.getUrl().toLowerCase().matches("evaluations")) {
                                activeSubmenu = "class=\"active\"";
                                ariaExpanded = true;
                            } else if (!menu.getUrl().matches("MySpace") && (subMenu.getUrl().toLowerCase().matches("profile")
                                    || subMenu.getUrl().toLowerCase().matches("latestinvoices") || subMenu.getUrl().toLowerCase().matches("patientfile"))) {
                                activeSubmenu = "class=\"active\"";
                                ariaExpanded = true;
                            } else {
                                activeSubmenu = "";
                                ariaExpanded = false;
                            }

                            String subMenuName = subMenu.getUrl().toLowerCase();
                            String menuAction = "ng-click=\"ctrl.changeView('" + subMenuName + "')\" ";

                            if (menu.getUrl().matches("EntityManagement")) {
                                entityManagementSubmenu.append("<li role=\"presentation\" ").append(activeSubmenu)
                                        .append(" >").append("<a href=\"#")
                                        .append(subMenuName).append("_content\" id=\"")
                                        .append(subMenuName).append("-tab\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"")
                                        .append(ariaExpanded).append("\">")
                                        .append("<i class=\"").append(subMenu.getCssIcon()).append("\"></i> ")
                                        .append(subMenu.getSubMenu())
                                        .append("")
                                        .append(" </a>")
                                        .append("</li>");
                            } else if (menu.getUrl().matches("MySpace")) {
                                mySpaceSubmenu.append("<li role=\"presentation\" ").append(activeSubmenu)
                                        .append(" >").append("<a href=\"#")
                                        .append(subMenuName).append("_content\" id=\"")
                                        .append(subMenuName).append("-tab\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"")
                                        .append(ariaExpanded).append("\">")
                                        .append("<i class=\"").append(subMenu.getCssIcon()).append("\"></i> ")
                                        .append(subMenu.getSubMenu())
                                        .append("")
                                        .append(" </a>")
                                        .append("</li>");
                            } else if (menu.getUrl().matches("Billing")) {
                                billingSubmenu.append("<li role=\"presentation\" ").append(activeSubmenu)
                                        .append(" >").append("<a href=\"#")
                                        .append(subMenuName).append("_content\" id=\"")
                                        .append(subMenuName).append("-tab\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"")
                                        .append(ariaExpanded).append("\">")
                                        .append("<i class=\"").append(subMenu.getCssIcon()).append("\"></i> ")
                                        .append(subMenu.getSubMenu())
                                        .append("")
                                        .append(" </a>")
                                        .append("</li>");
                            } else if (menu.getUrl().matches("Administration")) {
                                adminSubmenu.append("<li role=\"presentation\" ").append(activeSubmenu)
                                        .append(" >").append("<a href=\"#")
                                        .append(subMenuName).append("_content\" id=\"")
                                        .append(subMenuName).append("-tab\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"")
                                        .append(ariaExpanded).append("\">")
                                        .append("<i class=\"").append(subMenu.getCssIcon()).append("\"></i> ")
                                        .append(subMenu.getSubMenu())
                                        .append("")
                                        .append(" </a>")
                                        .append("</li>");
                            }
                        }
                    }
                }

                if (userType == UserTypeEnum.RECEPTIONIST) {
                    landingPage = LandingPageEnum.ADMINISTRATION.getDescription();
                } else if (userType == UserTypeEnum.DOCTOR || userType == UserTypeEnum.NURSE) {
                    landingPage = LandingPageEnum.CONSULTATION.getDescription();
                } else if (userType == UserTypeEnum.ENTITY && userPackageType != PackageTypeEnum.BASIC) {
                    landingPage = LandingPageEnum.DASHBOARD.getDescription();
                } else {
                    landingPage = LandingPageEnum.ENTITYMANAGEMENT.getDescription();
                }

                boolean userHasAccess = menu.getAccessRoles().contains(userType.getId() + "");

                if (userHasAccess) {
                    menuList.append("<li ").append(isActiveMenu).append(" ><a ").append(href).append(" ><i class=\"").append(menu.getCssClass()).append("\"></i> ")
                            .append(menuName).append(" </a>");
                    menuList.append("</li>");
                }

                i++;
            }
        }

        System.out.println("menuList.toString() = "+menuList.toString());
        redirectBean.setEntityManagementSubmenu(entityManagementSubmenu.toString());
        redirectBean.setMySpaceSubmenu(mySpaceSubmenu.toString());
        redirectBean.setBillingSubmenu(billingSubmenu.toString());
        redirectBean.setMenuList(menuList.toString());
        redirectBean.setAdminSubmenu(adminSubmenu.toString());
        redirectBean.setLandingPage(landingPage);

        logger.debug("RestAuthenticationSuccessHandler.class -> onAuthenticationSuccess method: [User logged in successfully]");

        Thread thread = new Thread() {
            public void run() {
                logoutUsers();
            }
        };

        thread.start();

        SecurityUtils.sendResponse(response, HttpServletResponse.SC_OK, redirectBean.getLandingPage());
    }

    private void logoutUsers() {
        logger.debug("RestAuthenticationSuccessHandler.class -> run method: users [Thread started]");
        // List<Employee> users = employeeService.findUsersAwayForMoreThan30Minutes(entityIdAndIDNumberBeanHelper.getEntityId());
        //logger.debug("RestAuthenticationSuccessHandler.class -> run method: users [" + gson.toJson(users) + "]");
    }
}
