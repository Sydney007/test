package za.co.timbaron.hms.dao.impl;


public class UserDaoImpl {

   /* public User findById(long id) {
        return getByKey(id);
    }

    public User findByUsername(String username) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<User> cr = cb.createQuery(User.class);
        Root<User> root = cr.from(User.class);
        cr.select(root).where(cb.equal(root.get("username"), username)).distinct(true);

        Query<User> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    public HMSEntity getEntityDetails(String registrationNumber) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<HMSEntity> cr = cb.createQuery(HMSEntity.class);
        Root<HMSEntity> root = cr.from(HMSEntity.class);
        cr.select(root).where(cb.equal(root.get("registrationNumber"), registrationNumber)).distinct(true);

        Query<HMSEntity> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    public Employee getEmployeeDetails(String idNumber) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Employee> cr = cb.createQuery(Employee.class);
        Root<Employee> root = cr.from(Employee.class);
        cr.select(root).where(cb.equal(root.get("identityNumber"), idNumber)).distinct(true);

        Query<Employee> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    public List<PackageTypeItems> getPackageTypeUsermenu(long packageTypeId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<PackageTypeItems> cr = cb.createQuery(PackageTypeItems.class);
        Root<PackageTypeItems> root = cr.from(PackageTypeItems.class);
        cr.select(root).where(cb.equal(root.get("packageTypeId"), packageTypeId))
                .distinct(true)
                .orderBy(cb.asc(root.get("id")));

        Query<PackageTypeItems> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List<User> findAllUsers() {
        Query qry = getSession().createQuery("From User");
        return qry.list();
    }

    @Override
    public void saveOrUpdate(User user) {
        getSession().saveOrUpdate(user);
        getSession().flush();
    }


    @Override
    public User findByIdNumber(String identityNumber) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<User> cr = cb.createQuery(User.class);
        Root<User> root = cr.from(User.class);
        cr.select(root).where(cb.equal(root.get("identityNumber"), identityNumber)).distinct(true);

        Query<User> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    @Override
    public UserRawPassword findPasswordByIdNumber(String identityNumber) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<UserRawPassword> cr = cb.createQuery(UserRawPassword.class);
        Root<UserRawPassword> root = cr.from(UserRawPassword.class);
        cr.select(root).where(cb.equal(root.get("identityNumber"), identityNumber)).distinct(true);

        Query<UserRawPassword> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }*/
}
