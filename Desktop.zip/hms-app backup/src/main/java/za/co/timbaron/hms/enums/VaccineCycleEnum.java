package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum VaccineCycleEnum {
    BIRTH,
    SIX_WEEKS,
    TEN_WEEKS,
    FOURTEEN_WEEKS,
    NINE_MONTH,
    TWELVE_MONTH,
    FIFTHTEEN_MONTH,
    EIGHTEEN_MONTH,
    SIX_YEARS,
    TWELVE_YEARS,
    EIGHTEEN_YEARS;
}
