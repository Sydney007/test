/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.service;

import java.sql.Date;
import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Bed;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.InvoicesStats;
import za.co.timbaron.hms.entity.ItemsServices;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.Room;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;
import za.co.timbaron.hms.enums.SupplierEnum;

/**
 *
 * @author Matimba
 */
@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface HMSEntityService {

    HMSEntity findById(long id);

    HMSEntity findByRegistrationNumber(String identityNumber);

    List<HMSEntity> findAllEntities();

    void save(HMSEntity entity);

    void remove(HMSEntity entity);

    List<Room> findEntityRooms(long entityId);

    List<Bed> findRoomBedsByRoomId(long roomId);

    List<Invoice> findInvoicesByEntityID(long entityId, InvoiceStatusEnum status);

    List<Invoice> findPatientInvoicesByIDNumber(String identityNumber, InvoiceStatusEnum status);

    List<InvoicesStats> findInvoiceStatsByEntityId(long entityId);

    List<Medicine> findAllMedicinesByEntityId(long entityId);

    List<Invoice> findInvoicesByEntityIdAndDateRange(long entityId, Date fromDate, Date toDate);

    List<ItemsServices> findAllItemsServicesByEntityId(long entityId);

    List<Employee> findAllUsersByEntityId(long entityId);
    
    void persistObject(Object entity);

}
