package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum OccupationTypeEnum {

    UNEMPLOYED("Unemployed"),
    ADMIN_CLERK("Admin Clerk"),
    CLEANER("Cleaner"),
    DOCTOR("Doctor"),
    NURSE("Nurse"),
    RECEPTIONIST("Receptionist"),
    SURGEON("Surgeon"),
    JAVA_DEVELOPER("Java Developer"),
    UNKNOW("Unknown");

    private final String type;

    OccupationTypeEnum(String gender) {
        this.type = gender;
    }

    public static OccupationTypeEnum getByType(String type) {
        for (OccupationTypeEnum e : values()) {
            if (e.type.equals(type)) {
                return e;
            }
        }
        return UNKNOW;
    }
}
