package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.CD4CountEnum;
import za.co.timbaron.hms.enums.DiagnosisStatusEnum;
import za.co.timbaron.hms.enums.VisitTypeEnum;

@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_VISIT")
public class Visit implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "VISITDATE", nullable = false)
    private Timestamp visitDate;

    @Column(name = "VISITREASON", nullable = false)
    private String visitReason;

    @Enumerated(EnumType.STRING)
    @Column(name = "DIAGNOSESSTATUS", nullable = false)
    private DiagnosisStatusEnum diagnosisStatus;

    @Column(name = "VISITYEAR", nullable = false)
    private String visitYear;

    @Column(name = "VISITMONTH", nullable = false)
    private String visitMonth;

    @Enumerated(EnumType.STRING)
    @Column(name = "VISITTYPE", nullable = false)
    private VisitTypeEnum visitType;

    @Enumerated(EnumType.STRING)
    @Column(name = "CDCOUNT", nullable = false)
    private CD4CountEnum cdCount;

    @Column(name = "VISITCONSENTFLAG", nullable = false, columnDefinition = "TINYINT(1)")
    private boolean visitConsentFlag;

    @Column(name = "VISITCONSENTSIGNATURE")
    private String visitConsentSignature;

    @Column(name = "REFERRALVISIT", nullable = false, columnDefinition = "TINYINT(1)")
    private boolean referralVisit;

    @Column(name = "SICKNOTEREQUIRED", nullable = false, columnDefinition = "TINYINT(1)")
    private boolean sickNoteRequired;

    @Transient
    private VisitReferral referralBean = new VisitReferral();

    @ManyToOne
    @JoinColumn(name = "EMPLOYEEID", referencedColumnName = "ID")
    private Employee doctor;

    @ManyToOne
    @JoinColumn(name = "PATIENTID", referencedColumnName = "ID")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "ENTITYID", referencedColumnName = "ID")
    private HMSEntity entity;

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<SocialHistory> socialHistoryList = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<Vital> vitals = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<Invoice> invoices = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<PatientMedicalProblem> medicalProblems = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<PatientMedication> medications = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<VisitImage> scans = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<PatientAllergy> allergies = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<PatientDisclosure> disclosures = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<Note> notes = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<PatientImmunization> vaccines = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<VisitTreatment> visitTreatmentItems = new HashSet();

    @OneToOne(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private SickNote sickNoteBean = new SickNote();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<Notification> notifications = new HashSet();

    @Transient
    private List<VisitReferral> referrals;

    @Transient
    private boolean downloadVisitDetails;

    @Transient
    private Set<UserImage> visitImages = new HashSet();

    @OneToMany(mappedBy = "visit", cascade = CascadeType.PERSIST)
    private Set<Appointment> appointments = new HashSet();

}
