package za.co.timbaron.hms.web.security;

import com.google.gson.Gson;
import java.io.IOException;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.enums.AvailabilityStatusEnum;
import za.co.timbaron.hms.service.EmployeeService;
import za.co.timbaron.hms.service.MyUserDetailsModel;

/**
 *
 * @author Matimba
 */
@Component
public class LogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private Gson gson;

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {

        if (authentication != null) {
            Object principal = authentication.getPrincipal();
            User loggedUser = ((MyUserDetailsModel) principal).getLoggedUser();
            Object entityDetails = ((MyUserDetailsModel) principal).getUserDetails();

            if (entityDetails instanceof Employee) {
                Employee employee = ((Employee) entityDetails);
                employee.setAvailabilityStatus(AvailabilityStatusEnum.OFFLINE);

                Timestamp now = new Timestamp(new java.util.Date().getTime());
                loggedUser.setLastLogin(now);
                employee.setLastLogin(now);

                //employee.setAddress(null);

                employeeService.persistObject(loggedUser);
                employeeService.persistObject(employee);
            }

            new SecurityContextLogoutHandler().logout(request, response, authentication);
        }

        super.onLogoutSuccess(request, response, authentication);
    }
}
