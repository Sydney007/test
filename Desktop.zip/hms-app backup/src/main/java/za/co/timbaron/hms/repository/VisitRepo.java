package za.co.timbaron.hms.repository;

import java.sql.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.Visit;

@Repository
@Transactional
public interface VisitRepo extends JpaRepository<Visit, Long> {

    List<Visit> findAllByPatient(Patient patient);

    List<Visit> findAllByEntity(HMSEntity entity);

    List<Visit> findAllByEntityAndVisitDateBetween(HMSEntity entity, Date visitDateStart, Date visitDateEnd);

    List<Visit> findAllByPatientAndVisitDateBetween(Patient patient, Date visitDateStart, Date visitDateEnd);

    List<Visit> findAllByPatientAndEntity(Patient patient, HMSEntity entity);

    List<Visit> findAllByPatientAndEntityAndVisitDateBetween(Patient patient, HMSEntity entity, Date visitDateStart, Date visitDateEnd);

    @Query("select distinct entity.id From Visit where patient = :patient")
    List<Long> findAllPatientVisitsEntitiesByPatient(@Param("patient") Patient patient);

    @Query("select distinct entity.id From Visit where patient = :patient and visitDate between :startDate and :endDate")
    List<Long> findAllPatientVisitsEntitiesByPatientAndDateRange(@Param("patient") Patient patient, @Param("startDate") Date startDate, @Param("endDate") Date endDate);

    List<Visit> findAllByPatientAndReferralVisit(Patient patient, boolean referralVisit);

}
