package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 *
 * @author ABMC684
 */
@Data
@EqualsAndHashCode
@ToString
public class PatientVisitsGroupedByEntity implements Serializable {

    private HMSEntity entity;
    private List<Visit> visits;
    private boolean expanded = false;
    private String activeCollapse = "";

}
