/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
public class RedirectBean {

    private String landingPage;

    private String menuList;

    private String entityManagementSubmenu;

    private String mySpaceSubmenu;

    private String billingSubmenu;

    private String adminSubmenu;

}
