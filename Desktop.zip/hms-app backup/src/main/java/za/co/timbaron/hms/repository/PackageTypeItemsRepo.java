package za.co.timbaron.hms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.PackageTypeItems;


@Repository
@Transactional
public interface PackageTypeItemsRepo extends JpaRepository<PackageTypeItems, Long> {

    List<PackageTypeItems> findByPackageTypeId(long packageTypeId);
}
