package za.co.timbaron.hms.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Notification;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.entity.UserRawPassword;
import za.co.timbaron.hms.enums.AvailabilityStatusEnum;
import za.co.timbaron.hms.enums.EntityTypeEnum;
import za.co.timbaron.hms.enums.UploadTypeEnum;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.model.Response;
import za.co.timbaron.hms.service.EmployeeService;
import za.co.timbaron.hms.service.HMSEntityService;
import za.co.timbaron.hms.service.HMSUtilService;
import za.co.timbaron.hms.service.MyUserDetailsModel;
import za.co.timbaron.hms.service.UserService;
import za.co.timbaron.hms.util.DaysTimeDifferenceUtil;
import za.co.timbaron.hms.util.DocumentUtilAndUploader;
import za.co.timbaron.hms.util.EntityIdAndIDNumberBeanHelper;
import za.co.timbaron.hms.util.UppercaseUtil;
import za.co.timbaron.hms.util.UserPrincipalHelper;

/**
 *
 * @author Matimba
 */
@RestController
@Api(value = "Employee management API")
@RequestMapping({"/employee"})
@Slf4j
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
 
    @Autowired
    private Gson gson;

    @Autowired
    private EntityIdAndIDNumberBeanHelper entityIdAndIDNumberBeanHelper;

    @Autowired
    private DaysTimeDifferenceUtil daysTimeDifferenceUtil;

    @Autowired
    private UserService userService;

    @Autowired
    private HMSUtilService hmsUtilService;
    
    @Autowired
    private HMSEntityService hmsService;

    @Autowired
    private ObjectMapper objectMapper;

    private Timestamp now = new Timestamp(new java.util.Date().getTime());

    @Autowired
    private DocumentUtilAndUploader documentUtilAndUploader;

    @Value("${images.location}")
    private String serverLocation;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserPrincipalHelper userprincipalHelper;
 
    @RequestMapping(value = "/getEmployeeName/{idNumber}", method = RequestMethod.GET)
    public @ResponseBody 
    Employee getEmployeeName(@PathVariable String idNumber) {
        checkAuthentication();
        return employeeService.findEmployeeByEmployeeNumber(idNumber);
    }

    @RequestMapping(value = "/checkEmployeeAvailabilty", method = RequestMethod.GET)
    public @ResponseBody
    List<Employee> checkEmployeeAvailabilty() {
        checkAuthentication();
        log.debug("EmployeeController.class -> checkEmployeeAvailabilty method: [Check Employees Availabilty]");
        
         

        List<Employee> availableEmployees = employeeService.checkEmployeeAvailabilty(hmsService.findById(entityIdAndIDNumberBeanHelper.getEntityId()));

        for (Employee o : availableEmployees) {

            Employee e = new Employee();
            e.setId(o.getId());
            e.setFullName(o.getFullName());
            e.setLastName(o.getLastName());
            e.setAvailabilityStatus(o.getAvailabilityStatus());
            o = e;
        }
        
        return availableEmployees;
    }

    @RequestMapping(value = "/saveOrUpdate", method = RequestMethod.POST)
    public @ResponseBody
    Response saveOrUpdate(MultipartHttpServletRequest request) {
        checkAuthentication();
        log.debug("EmployeeController.class -> saveOrUpdate method: [Save Employee]");
        Response response = new Response();

        try {

            MultipartFile logo = request.getFile("logo");
            String employeeBeanString = request.getParameter("employeeBean");

            Employee employee = objectMapper.readValue(employeeBeanString, Employee.class);

            if (employee.isNewEmployee()) {
                createEmployeeLogonDetails(employee);
            }

            UserImage image = hmsUtilService.findProfilePicByIdNo(userService.findByIdNumber(employee.getIdentityNumber()));

            if (logo != null) {
                String photo = documentUtilAndUploader.uploadImage(logo, employee.getIdentityNumber(), "profilepic");
                employee.setPhoto(photo);
            }

            if (image == null) {
                image = new UserImage();
            }

           // image.setUserIdNo(employee.getIdentityNumber());
            image.setUploadDate(now);
            image.setUploadType(UploadTypeEnum.LOGO);
            image.setImageSize("0");
            image.setImageName("profilepic");
            image.setServer(serverLocation);
            image.setImageData(null);
            image.setUploadType(null);

            //employee.getEmergencyContact().setRelationship(null);
            //employee.getEmergencyContact().setTitle(null);

            //employee.getEmployer().setDepartment(null);

            employeeService.saveOrUpdate(employee);
            //employeeService.persistObject(employee.getAddress());
            //employeeService.persistObject(employee.getEmployer());
//          employeeService.persistObject(employee.getEmergencyContact());
            employeeService.persistObject(image);

            /*if (employee.getMedicalAid() != null) {
                employee.getMedicalAid().setProvider(null);
                employee.getMedicalAid().setBalance(BigDecimal.ZERO);
                employee.getMedicalAid().setSavingsBalance(BigDecimal.ZERO);
                employee.getMedicalAid().setIdentityNumber(employee.getIdentityNumber());
                employeeService.persistObject(employee.getMedicalAid());
            }*/

            response.setFailed(false);
            response.setMessage("Employee details successfully saved/updated.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return response;
    }

    @RequestMapping(value = "/updateEmployeeAvailabilityStatus", method = RequestMethod.POST)
    public @ResponseBody
    Response updateEmployeeAvailabilityStatus(@RequestBody String availabilityStatus) {
        checkAuthentication();
        log.debug("EmployeeController.class -> updateEmployeeAvailabilityStatus method: [Update Employee Availability Status]");

        Response response = new Response();

        try {
            SecurityContext securityContext = SecurityContextHolder.getContext();
            Authentication authentication = securityContext.getAuthentication();

            Object principal = authentication.getPrincipal();
            User loggedUser = ((MyUserDetailsModel) principal).getLoggedUser();
            Object entityDetails = ((MyUserDetailsModel) principal).getUserDetails();

            AvailabilityStatusEnum status = AvailabilityStatusEnum.valueOf(availabilityStatus);

            if (entityDetails instanceof Employee) {
                Employee employee = ((Employee) entityDetails);

                if (loggedUser.getUserType() != UserTypeEnum.RECEPTIONIST || loggedUser.getUserType() != UserTypeEnum.ENTITY) {
                    employee.setAvailabilityStatus(status);
                    userService.persistObject(employee);
                }
            }

            response.setFailed(false);
            response.setMessage("Status updated successfully!.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/getEmployeeNotifications", method = RequestMethod.GET)
    public @ResponseBody
    List<Notification> getEmployeeNotifications() {
        checkAuthentication();
        List<Notification> notifications = employeeService.findAllEmployeeNotifications(entityIdAndIDNumberBeanHelper.getEntityId(), entityIdAndIDNumberBeanHelper.getId());

        for (Notification notification : notifications) {
            Map results = daysTimeDifferenceUtil.computeDiff(notification.getNotificationDate(), new java.util.Date());
            Employee employee = employeeService.findEmployeeById(notification.getFromEmployeeId());

            long hours = Long.parseLong(results.get(TimeUnit.HOURS).toString());

            String howLong = "";

            if (hours > 0) {
                howLong = hours + " hours ago.";
            } else {
                howLong = results.get(TimeUnit.MINUTES).toString() + " minutes ago.";
            }

            notification.setFrom(employee.getFullName() + " " + employee.getLastName());
            notification.setHowLongAgo(howLong);
        }

        return notifications;
    }

    @RequestMapping(value = "/getAllNotifications", method = RequestMethod.GET)
    public @ResponseBody
    List<Notification> getNotifications(@RequestParam Date fromDate, @RequestParam Date endDate) {
        checkAuthentication();
        log.debug("EmployeeController.class -> getNotifications method: [Get all Notifications fromDate = " + fromDate + "] endDate = " + endDate + "");
        List<Notification> notifications = employeeService.findAllEntityNotificationsBetweenStartAndEndDate(entityIdAndIDNumberBeanHelper.getEntityId(), fromDate, endDate);

        return notifications;
    }

    @RequestMapping(value = "/deleteNotification", method = RequestMethod.POST)
    public @ResponseBody
    Response deleteNotification(@RequestBody List<Notification> notifications) {
        checkAuthentication();
        log.debug("EmployeeController.class -> deleteNotification method: [Delete notifications]");

        Response response = new Response();

        try {

            System.out.println("notifications = " + gson.toJson(notifications));

            for (Notification noti : notifications) {
                hmsUtilService.delete("Notification", noti.getId());
            }

            response.setFailed(false);
            response.setMessage("Notification(s) deleted successfully!.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/saveNotification", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    Response saveNotification(@RequestBody Notification notification) {
        checkAuthentication();
        log.debug("EmployeeController.class -> saveNotification method: [saveNotification employees notifications]");

        Response response = new Response();

        try {
            notification.setDoctor(null);
            notification.setVisit(null);
            notification.setPatient(null);

            if (notification.isReAllocatePatient()) {
                employeeService.persistObject(notification);
                response.setFailed(false);
                response.setMessage("Patient Re-allocated successfully!.");
            } else {//Allocate patient to doctor
                Notification notificationInDB = employeeService.findNotificationByPatientId(notification.getPatient().getId()).get(0);

                if (notificationInDB != null) {
                    String tittle = notificationInDB.getDoctor().getTitle().toString();

                    String doctor = UppercaseUtil.uppercaseFirstLetter(tittle) + " " + notificationInDB.getDoctor().getFullName() + " " + notificationInDB.getDoctor().getLastName();
                    response.setFailed(true);
                    response.setMessage("Patient already allocated to (" + doctor + "). Go to notifications tab to re-allocate the patient!.");
                } else {
                    String message = notification.getNotification();
                    notification.setEntityId(entityIdAndIDNumberBeanHelper.getEntityId());
                    notification.setFromEmployeeId(entityIdAndIDNumberBeanHelper.getId());
                    notification.setNotification("Next patient in line is :" + message);
                    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                    notification.setNotificationDate(timestamp);
                    employeeService.persistObject(notification);

                    response.setFailed(false);
                    response.setMessage("Patient allocated successfully!.");
                }
            }

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    private ModelAndView checkAuthentication() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();

        if (authentication == null || userprincipalHelper.getUserPrincipal() == null) {
            return new ModelAndView(new RedirectView("logout"));
        }

        return null;
    }

    private void createEmployeeLogonDetails(Employee employee) throws Exception{

        Object userDetails = userprincipalHelper.getUserPrincipal();

        Long employeeNo = Long.parseLong(hmsUtilService.getMaxValue("Employee", "employeeNo"));
        employeeNo = employeeNo + 1L;

//        employee.getEmployer().setEmployeeNo(employeeNo.toString());
        employee.setEmployeeNo(employeeNo.toString());

        HMSEntity entity = null;

        if (userDetails instanceof HMSEntity) {
            entity = ((HMSEntity) userDetails);
        } else if (userDetails instanceof Employee) {
            Employee loggedEmployee = ((Employee) userDetails);
            entity = loggedEmployee.getEntity();
        }

        User newUser = employee.getUserDetails();
        String encodedPassword = passwordEncoder.encode(newUser.getPassword());

        UserRawPassword userPassword = new UserRawPassword();

        newUser.setAccountActive(Boolean.TRUE);
        newUser.setEntityIsHuman(Boolean.TRUE);
        newUser.setPassword(encodedPassword);
        newUser.setIdentityNumber(employee.getIdentityNumber());
        newUser.setAccountType(entity.getAccountType()); // set account type to premium account
        newUser.setEntityType(EntityTypeEnum.PERSON); //set entity type to person                 
        newUser.setPackageType(entity.getPackageType()); // set patient package
        newUser.setEntityType(null);

        userPassword.setPassword(newUser.getPassword());
        userPassword.setUser(newUser);
        employee.setDateModified(now);
       // employee.setUserType(newUser.getUserType());
        employee.setEntity(entity);
        employee.setAvailabilityStatus(AvailabilityStatusEnum.OFFLINE);

        employee.setCountry(null);
        employee.setTitle(null);
        employee.setRace(null);
        employee.setGender(null);
        employee.setLanguage(null);
        employee.setMaritalStatus(null);
        employee.setAvailabilityStatus(null);
        employee.setEntity(null);
        //employee.setLogo(null);
//        employee.setMedicalAid(null);
        //employee.setWallet(null);
        //employee.setUserType(null);

        //employee.getEmployer().setEmployerName(entity.getEntityName());

        userService.saveOrUpdate(newUser);
        userService.persistObject(userPassword);
    }
}
