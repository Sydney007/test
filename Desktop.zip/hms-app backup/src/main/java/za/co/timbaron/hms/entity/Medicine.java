package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.CategoryEnum;
import za.co.timbaron.hms.enums.SupplierEnum;

@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_MEDICINE")
public class Medicine implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "SIG_NAME", unique = true, nullable = false)
    private String sigName;

    @Column(name = "SIG_DESCRIPTION", unique = true, nullable = false)
    private String sigDescription;

    @Column(name = "STOCKINHAND", unique = true, nullable = false)
    private long stockInhand;

    @Column(name = "EXPIRYDATE", unique = true, nullable = false)
    private Date expiryDate;

    @Column(name = "PURCHASEDATE", unique = true, nullable = false)
    private Timestamp purchaseDate;

    @Column(name = "ISBNUPC", unique = true, nullable = false)
    private String isbnUpc;

    @Column(name = "COSTPRICE", unique = true, nullable = false)
    private BigDecimal costPrice;

    @Column(name = "TAXAMOUNT", unique = true, nullable = false)
    private BigDecimal taxAmount;

    @Column(name = "TOTALAMOUNT", unique = true, nullable = false)
    private BigDecimal totalAmount;

    @Column(name = "SELLINGPRICE", unique = true, nullable = false)
    private BigDecimal sellingPrice;

    @ManyToOne
    @JoinColumn(name = "ENTITYID", referencedColumnName = "ID")
    private HMSEntity entity;

    @Enumerated(EnumType.STRING)
    @Column(name = "CATEGORY", unique = true, nullable = false)
    private CategoryEnum category;

    @Enumerated(EnumType.STRING)
    @Column(name = "SUPPLIER", unique = true, nullable = false)
    private SupplierEnum supplier;
}