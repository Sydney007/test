package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import za.co.timbaron.hms.enums.AccountTypeEnum;
import za.co.timbaron.hms.enums.EntityTypeEnum;
import za.co.timbaron.hms.enums.PackageTypeEnum;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.enums.conveter.AccountTypeEnumConverter;
import za.co.timbaron.hms.enums.conveter.EntityTypeEnumConverter;
import za.co.timbaron.hms.enums.conveter.PackageTypeEnumConverter;
import za.co.timbaron.hms.enums.conveter.UserTypeEnumConverter;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "HMS_USER")
public class User implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "USERNAME", unique = true, nullable = false)
    private String username;

    @Column(name = "PASSWORD", nullable = false)
    private String password;

    @Column(name = "IDENTITYNUMBER", nullable = false)
    private String identityNumber;

    @Column(name = "ACCOUNTACTIVE", nullable = false)
    private Boolean accountActive;

    @Convert(converter = AccountTypeEnumConverter.class)
    @Column(name = "ACCOUNTTYPE", nullable = false)
    private AccountTypeEnum accountType;

    @Column(name = "ENTITYISHUMAN", nullable = false, columnDefinition = "TINYINT")
    private Boolean entityIsHuman;

    @Convert(converter = UserTypeEnumConverter.class)
    @Column(name = "USERTYPE", nullable = false)
    private UserTypeEnum userType;

    @Column(name = "LASTLOGIN", unique = true, nullable = false)
    private Timestamp lastLogin;

    @Convert(converter = EntityTypeEnumConverter.class)
    @Column(name = "ENTITYTYPE", unique = true, nullable = false)
    private EntityTypeEnum entityType;

    @Convert(converter = PackageTypeEnumConverter.class)
    @Column(name = "PACKAGETYPE", unique = true, nullable = false)
    private PackageTypeEnum packageType;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private UserRawPassword userPassword;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private Address address;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private Employer employer;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private Wallet wallet;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private UserImage logo;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private EmergencyContact emergencyContact;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private MedicalAid medicalAid;
}
