/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.TransactionTypeEnum;

@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_WALLET_TRANSACTIONS")
public class WalletTransactions implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "CURRENTBALANCE", nullable = false)
    private BigDecimal currentBalance;

    @Column(name = "AMOUNT", nullable = false)
    private BigDecimal amount;

    @Column(name = "PREVIOUSBALANCE", nullable = false)
    private BigDecimal previousBalance;

    @Column(name = "TRANSACTIONDATE", nullable = false)
    private Timestamp transactionDate;

    @Column(name = "REFERENCE", nullable = false)
    private String reference;

    @Enumerated(EnumType.STRING)
    @Column(name = "TRANSACTIONTYPE", nullable = false)
    private TransactionTypeEnum transactionType;

    @ManyToOne
    @JoinColumn(name = "INVOICEID", referencedColumnName = "ID")
    private Invoice invoice;

    @ManyToOne
    @JoinColumn(name = "WALLETID", referencedColumnName = "ID")
    private Wallet wallet;
}
