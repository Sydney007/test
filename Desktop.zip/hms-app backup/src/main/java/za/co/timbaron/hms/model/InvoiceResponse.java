/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.model;

import java.util.List;
import za.co.timbaron.hms.entity.Invoice;

/**
 *
 * @author ABMC684
 */
public class InvoiceResponse {

    private double balance;
    private List<Invoice> invoices;
    private boolean fetchAgain;

    public boolean isFetchAgain() {
        return fetchAgain;
    }

    public void setFetchAgain(boolean fetchAgain) {
        this.fetchAgain = fetchAgain;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public List<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

}
