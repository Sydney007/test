package za.co.timbaron.hms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.MedicalTreatment;

@Repository
@Transactional
public interface MedicalTreatmentRepo extends JpaRepository<MedicalTreatment, Long>{
    
}
