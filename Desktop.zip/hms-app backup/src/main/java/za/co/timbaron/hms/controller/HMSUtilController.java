package za.co.timbaron.hms.controller;

import com.google.gson.Gson;
import io.swagger.annotations.Api;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import za.co.timbaron.hms.entity.DropDownValuesUtil;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.service.HMSUtilService;
import za.co.timbaron.hms.util.EntityIdAndIDNumberBeanHelper;

@RestController
@Api(value = "HMS Util  management API")
@RequestMapping("/hmsUtil")
public class HMSUtilController {

    private static final Logger logger = LoggerFactory.getLogger(HMSUtilController.class);

    @Autowired
    private HMSUtilService hmsUtilService;

    @Autowired
    private Gson gson;

    @Autowired
    EntityIdAndIDNumberBeanHelper entityIdAndIDNumberBeanHelper;

    @RequestMapping(value = "/getDropDownValuesUtil", method = RequestMethod.GET)
    public @ResponseBody
    DropDownValuesUtil getDropDownValuesUtil() throws Exception {
        logger.debug("get Drop Down Values Util");
        return hmsUtilService.getDropDownValuesUtil(entityIdAndIDNumberBeanHelper.getEntityId());
    }

    @RequestMapping(value = "/getKnownMedicalProblems", method = RequestMethod.GET)
    public @ResponseBody
    List getKnownMedicalProblems() {
        logger.debug("get Known Medical Problems");
        return null;//hmsUtilService.getMedicalProblems();
    }

    @RequestMapping(value = "/getKnownAllergies", method = RequestMethod.GET)
    public @ResponseBody
    List getKnownAllergies() {
        logger.debug("get Known Allergies");
        return null;//hmsUtilService.getAllergies();
    }

    @RequestMapping(value = "/getAllMedicines", method = RequestMethod.GET)
    public @ResponseBody
    List getAllMedicines() {
        logger.debug("get all Medicines");
        return hmsUtilService.getAllMedicines();
    }

    @RequestMapping(value = "/getAllVaccines", method = RequestMethod.GET)
    public @ResponseBody
    List getAllVaccines() {
        logger.debug("get all Medicines");
        return null;//hmsUtilService.getAllVaccines();
    }

    @RequestMapping(value = "/lookUp", method = RequestMethod.GET)
    public @ResponseBody
    List lookUp(@RequestParam String searchString, @RequestParam String tableName, @RequestParam String searchField) throws Exception {
        logger.debug("lookUp [" + tableName + "] Condition [" + searchField + "]");
        List results = hmsUtilService.lookUp(searchString, tableName, searchField);
        return results;
    }

    @RequestMapping(value = "/checkUserAvailability", method = RequestMethod.GET)
    public @ResponseBody
    boolean checkUserAvailability(@RequestParam String username) {
        User user = hmsUtilService.checkUserAvailability(username);
        boolean result = user == null ? true : false;
        return result;
    }

}
