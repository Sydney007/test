package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum TitleEnum {
    DR,
    MR,
    MRS,
    MS,
    PROF;
}
