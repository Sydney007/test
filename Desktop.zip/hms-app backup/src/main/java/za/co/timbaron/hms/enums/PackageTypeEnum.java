package za.co.timbaron.hms.enums;

import java.text.MessageFormat;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum PackageTypeEnum {

    BASIC("Basic", 1),
    PROFESSIONAL("Professional", 2),
    ENTERPRISE("Enterprise", 3),
    PATIENT("Patient", 4);

    private final String value;
    private final long id;

    PackageTypeEnum(String value, int id) {

        this.value = value;
        this.id = id;
    }
    
    public static PackageTypeEnum getByValue(String value) {
        for (PackageTypeEnum e : values()) {
            if (e.value.equals(value)) {
                return e;
            }
        }
        log.warn(MessageFormat.format("Invalid value for PackageTypeEnum: {0}", value));
        return null;
    }

    public static PackageTypeEnum getById(long id) {
        for (PackageTypeEnum e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        log.warn(MessageFormat.format("Invalid Id for PackageTypeEnum: {0}", id));
        return null;
    }
}
