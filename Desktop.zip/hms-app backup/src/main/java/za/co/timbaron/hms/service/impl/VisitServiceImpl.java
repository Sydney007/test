package za.co.timbaron.hms.service.impl;

import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.VisitReferral;
import za.co.timbaron.hms.repository.VisitReferralRepo;
import za.co.timbaron.hms.repository.VisitRepo;
import za.co.timbaron.hms.service.VisitService;

/**
 *
 * @author Matimba
 */
@Service("visitService")
@Transactional
public class VisitServiceImpl implements VisitService {

    @Autowired
    private VisitRepo visitRepo;

    @Autowired
    private VisitReferralRepo visitReferralRepo;

    @Override
    public Visit findById(long id) {
        return visitRepo.findById(id).get();
    }

    @Override
    public List<Visit> findAllByEntity(HMSEntity entity) {
        return visitRepo.findAllByEntity(entity);
    }

    @Override
    public List<Visit> findAllVisitsByDateRange(HMSEntity entity, Date startDate, Date endDate) {
        return visitRepo.findAllByEntityAndVisitDateBetween(entity, startDate, endDate);
    }

    @Override
    public void save(Visit visit) {
        visitRepo.save(visit);
    }

    @Override
    public void remove(Visit visit) {
        //visitRepo.remove(visit);
    }

    @Override
    public void persistRelatedObject(Object entity) {
        //visitRepo.persistRelatedObject(entity);
    }

    @Override
    public List<VisitReferral> getVisitReferralDetails(long visitId) {
        return visitReferralRepo.findAllByVisitId(visitId);
    }

    @Override
    public void deleteObject(Object entity) {
        //visitRepo.deleteObject(entity);
    }

}
