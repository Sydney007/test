/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

/**
 *
 * @author schauke
 */
public class UppercaseUtil {

    public static String uppercaseFirstLetter(String word) {
        word = word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase();
        return word;
    }

}
