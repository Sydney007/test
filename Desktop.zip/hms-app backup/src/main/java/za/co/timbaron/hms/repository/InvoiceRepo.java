package za.co.timbaron.hms.repository;

import java.sql.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;

@Repository
@Transactional
public interface InvoiceRepo extends JpaRepository<Invoice, Long> {

    List<Invoice> findAllByPatientIdNoAndInvoiceStatus(String patientIdNo, InvoiceStatusEnum invoiceStatus);

    List<Invoice> findAllByEntityIdAndInvoiceStatus(long entityId, InvoiceStatusEnum invoiceStatus);

    @Query("Select i From Invoice i where i.entityId = :entityId and i.invoiceDate between :fromDate and :toDate "
            + "order by i.invoiceDate desc")
    List<Invoice> findInvoicesByEntityIdAndDateRange(@Param("entityId") long entityId, @Param("fromDate") Date fromDate,
            @Param("toDate") Date toDate);

    List<Invoice> findAllByEntityIdAndInvoiceDateBetween(long entityId, Date invoiceDateStart, Date invoiceDateEnd);

    List<Invoice> findAllByPatientIdNo(String patientIdNo);
}
