/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Data;

@Data
@Entity
@Table(name = "HMS_NOTIFICATION")
public class Notification implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "ENTITYID")
    private long entityId;

    @Column(name = "TOEMPLOYEEID")
    private long toEmployeeId;

    @Column(name = "FROMEMPLOYEEID")
    private long fromEmployeeId;

    @Column(name = "NOTIFICATION")
    private String notification;

    @Column(name = "VIEWED")
    private boolean viewed;

    @Column(name = "NOTIFICATIONDATE")
    private Timestamp notificationDate;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TOEMPLOYEEID", referencedColumnName = "ID", insertable = false, updatable = false, nullable = true)
    private Employee doctor = new Employee();

    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;

    @ManyToOne
    @JoinColumn(name = "PATIENTID", referencedColumnName = "ID")
    private Patient patient;

    @Transient
    private boolean reAllocatePatient;

    @Transient
    private String from;

    @Transient
    private String howLongAgo;
}
