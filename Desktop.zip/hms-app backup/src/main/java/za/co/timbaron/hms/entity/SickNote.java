/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_VISIT_SICK_NOTE")
public class SickNote implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "VISITDATE", nullable = false)
    private Timestamp visitDate;

    @Column(name = "FROMDATE", nullable = false)
    private Timestamp fromDate;

    @Column(name = "TODATE", nullable = false)
    private Timestamp toDate;

    @Column(name = "RETURNDATE", nullable = false)
    private Timestamp returnDate;

    @Column(name = "PATIENTID", nullable = false)
    private long patientId;

    @Column(name = "NATUREOFSICKNESS", nullable = false)
    private String natureOfSickness;

    @OneToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;
}
