package za.co.timbaron.hms.service.impl;

import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Notification;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.repository.NotificationRepo;
import za.co.timbaron.hms.service.EmployeeService;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private NotificationRepo notificationRepo;

    @Override
    public Employee findEmployeeById(long id) {
        return employeeRepo.findById(id).get();
    }

    @Override
    public Employee findEmployeeByEmployeeNumber(String employeeNumber) {
        return employeeRepo.findByEmployeeNo(employeeNumber);
    }

    @Override
    public Employee findEmployeeByIdentityNumber(String idNumber) {
        return employeeRepo.findByIdentityNumber(idNumber);
    }

    @Override
    public List<Employee> checkEmployeeAvailabilty(HMSEntity entity) {
        return employeeRepo.findAllByEntityIdAndUserType(entity, UserTypeEnum.DOCTOR);
    }

    @Override
    public void saveOrUpdate(Employee employee) {
        employeeRepo.saveAndFlush(employee);
    }

    @Override
    public void persistObject(Object entity) {

    }

    @Override
    public List<Notification> findAllEmployeeNotifications(long entityId, long employeeId) {
        return notificationRepo.findAllByEntityIdAndToEmployeeId(entityId, employeeId);
    }

    @Override
    public List<Notification> findAllEntityNotificationsBetweenStartAndEndDate(long entityId, Date fromDate, Date toDate) {
        return notificationRepo.findAllByEntityIdAndNotificationDateBetween(entityId, fromDate, toDate);
    }

    @Override
    public Notification findNotificationById(long id) {
        return notificationRepo.findById(id).get();
    }

    @Override
    public List<Employee> findUsersAwayForMoreThan30Minutes(HMSEntity entity) {
        return employeeRepo.findUsersAwayForMoreThan30Minutes(entity);
    }

 
    @Override
    public List<Notification> findNotificationByPatientId(long patientId) {
        return notificationRepo.findAllByPatientId(patientId);
    }

    @Override
    public List<Notification> findNotificationByVisitId(long id) {
        return notificationRepo.findAllByVisitId(id);
    }

}
