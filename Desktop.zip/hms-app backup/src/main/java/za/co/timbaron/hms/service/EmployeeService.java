package za.co.timbaron.hms.service;

import java.sql.Date;
import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Notification;

@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface EmployeeService {

    Employee findEmployeeById(long id);

    Employee findEmployeeByEmployeeNumber(String employeeNumber);

    Employee findEmployeeByIdentityNumber(String identityNumber);

    List<Employee> checkEmployeeAvailabilty(HMSEntity entity);

    List<Notification> findAllEmployeeNotifications(long entityId, long employeeId);

    List<Notification> findAllEntityNotificationsBetweenStartAndEndDate(long entityId, Date fromDate, Date toDate);

    void saveOrUpdate(Employee employee);

    void persistObject(Object entity);

    Notification findNotificationById(long id);

    List<Notification> findNotificationByVisitId(long id);

    List<Notification> findNotificationByPatientId(long patientId);

    List<Employee> findUsersAwayForMoreThan30Minutes(HMSEntity entity);

}
