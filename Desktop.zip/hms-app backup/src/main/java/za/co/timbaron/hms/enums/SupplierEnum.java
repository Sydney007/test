package za.co.timbaron.hms.enums;

public enum SupplierEnum {
    CIPLA,
    NEO;
}
