package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum VaccineEnum {
    ORAL_POLIO("Oral Polio"),
    BCG("BCG"),
    DIPHTHERIA("Diphtheria"),
    TETANUS("Tetanus"),
    ACELLULAR("Acellular"),
    PERTUSSIS("Pertussis"),
    HAEMOPHILUS("Haemophilus"),
    INFLUENZA("Influenza"),
    POLIO("Polio"),
    PNEUMOCOCCAL_CONJUGATED("Pneumococcal Conjugated"),
    ROTAVIRUS("Rotavirus"),
    HEPATITIS_B("Hepatitis B"),
    HEPATITIS_A("Hepatitis A"),
    MEASLES("Measles"),
    VARICELLA("Varicella"),
    MUMPS("Mumps"),
    RUBBELA("Rubbela");

    private final String name;

    VaccineEnum(String name) {
        this.name = name;
    }

    public static VaccineEnum getByName(String name) {
        for (VaccineEnum e : values()) {
            if (e.name.equals(name)) {
                return e;
            }
        }
        return null;
    }

}
