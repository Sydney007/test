/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 *
 * @author Matimba
 */
@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_ENTITY_PATIENTS")
public class EntityPatient implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "PATIENTIDNO", unique = true)
    private String patientIdNo;

    @Column(name = "ENTITYID", unique = true)
    private long entityId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PATIENTIDNO", referencedColumnName = "IDENTITYNUMBER", insertable = false, updatable = false)
    private Patient patient = new Patient();
}
