package za.co.timbaron.hms.service;

import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.PackageTypeItems;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserRawPassword;

@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface UserService {

    User findById(long id);

    User findByUsername(String username);

    User findByIdNumber(String identityNumber);

    UserRawPassword findPasswordByUser(User user);

    HMSEntity getEntityDetails(String registrationNumber);

    Employee getEmployeeDetails(String idNumber);

    List<PackageTypeItems> getPackageTypeUsermenu(long packageTypeId);

    List<User> findAllUsers();

    void saveOrUpdate(User user);

    public void persistObject(Object entity);
}
