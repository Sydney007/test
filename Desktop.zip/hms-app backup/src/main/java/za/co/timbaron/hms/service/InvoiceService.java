/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.service;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Invoice;

/**
 *
 * @author Matimba
 */
@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface InvoiceService {

    void save(Invoice invoice);

    void manualBindingSave(Invoice invoice);

}
