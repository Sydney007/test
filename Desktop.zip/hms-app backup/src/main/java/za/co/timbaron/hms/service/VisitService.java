/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.service;

import java.sql.Date;
import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.VisitReferral;

/**
 *
 * @author Matimba
 */
@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface VisitService {

    Visit findById(long id);

    List<Visit> findAllByEntity(HMSEntity entity);

    List<Visit> findAllVisitsByDateRange(HMSEntity entity, Date startDate, Date endDate);

    void save(Visit visit);

    void remove(Visit visit);

    void persistRelatedObject(Object entity);

    void deleteObject(Object entity);

    List<VisitReferral> getVisitReferralDetails(long visitId);

}
