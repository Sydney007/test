package za.co.timbaron.hms.repository;

import java.sql.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Notification;

@Repository
@Transactional
public interface NotificationRepo extends JpaRepository<Notification, Long> {

    List<Notification> findAllByEntityIdAndToEmployeeId(long entityId, long toEmployeeId);    

    @Query("From Notification where entityId = :entityId and DATE_FORMAT(notificationDate, '%Y-%m-%d') "
            + "between :fromDate and :toDate ")
    List<Notification> findAllNotificationsNotificationDateBetween(@Param("entityId") long entityId,
            @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    List<Notification> findAllByEntityIdAndNotificationDateBetween(long entityId, Date notificationDateFrom, Date notificationDateTo);

    List<Notification> findAllByVisitId(long visitId);

    List<Notification> findAllByPatientId(long patientId);

}
