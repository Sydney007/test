/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.DropDownValuesUtil;
import za.co.timbaron.hms.entity.MedicalTreatment;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.enums.AllergyEnum;
import za.co.timbaron.hms.enums.MedicalProblemEnum;
import za.co.timbaron.hms.util.HMSUtilRepo;
import za.co.timbaron.hms.repository.MedicalTreatmentRepo;
import za.co.timbaron.hms.repository.MedicineRepo;
import za.co.timbaron.hms.repository.UserImageRepo;
import za.co.timbaron.hms.enums.UploadTypeEnum;
import za.co.timbaron.hms.enums.VaccineEnum;
import za.co.timbaron.hms.service.HMSUtilService;

/**
 *
 * @author Matimba
 */
@Service("hmsUtilService")
@Transactional
public class HMSUtilServiceImpl implements HMSUtilService {

    @Autowired
    private HMSUtilRepo hmsUtilRepo;

    @Autowired
    private MedicineRepo medicineRepo;

    @Autowired
    private MedicalTreatmentRepo medicalTreatmentRepo;

    @Autowired
    private UserImageRepo userImageRepo;

    @Override
    public List<Medicine> getAllMedicines() {
        return medicineRepo.findAll();
    }

    @Override
    public DropDownValuesUtil getDropDownValuesUtil(long entityId) throws Exception {
        return hmsUtilRepo.getDropDownValuesUtil(entityId);
    }

    @Override
    public MedicalTreatment findMedicalTreatmentById(long id) {
        return medicalTreatmentRepo.findById(id).get();
    }

    @Override
    public List lookUp(String searchString, String tableName, String searchField) throws Exception {
        return hmsUtilRepo.lookUp(searchString, tableName, searchField);
    }

    @Override
    public User checkUserAvailability(String username) {
        return hmsUtilRepo.checkUserAvailability(username);
    }

    @Override
    public String getMaxValue(String tableName, String field) throws Exception {
        return hmsUtilRepo.getMaxValue(tableName, field);
    }

    @Override
    public void delete(String tableName, long id) throws Exception {
        hmsUtilRepo.delete(tableName, id);
    }

    @Override
    public UserImage findProfilePicByIdNo(User user) {
        return userImageRepo.findByUserAndUploadType(user, UploadTypeEnum.LOGO);
    }

    @Override
    public List<MedicalProblemEnum> getMedicalProblems() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<AllergyEnum> getAllergies() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<VaccineEnum> getAllVaccines() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
