package za.co.timbaron.hms.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import za.co.timbaron.hms.entity.PackageTypeItems;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.repository.HMSEntityRepo;
import za.co.timbaron.hms.repository.PackageTypeItemsRepo;
import za.co.timbaron.hms.repository.UserRepo;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private HMSEntityRepo hmsEntityRepo;

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private PackageTypeItemsRepo packageTypeItemsRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = userRepo.findByUsername(username);
        Object entityDetails = null;
        List<PackageTypeItems> packageMenu = null;

        if (user == null) {
            throw new UsernameNotFoundException("Username not found");
        } else {

            if (!user.getEntityIsHuman()) {
                entityDetails = hmsEntityRepo.findByRegistrationNumber(user.getIdentityNumber());
            } else {
                entityDetails = employeeRepo.findByIdentityNumber(user.getIdentityNumber());
            }

            packageMenu = packageTypeItemsRepo.findByPackageTypeId(user.getPackageType().getId());
        }

        MyUserDetailsModel loggedUserModel = new MyUserDetailsModel(user.getUsername(), user.getPassword(),
                user.getAccountActive(), true, true, true, getGrantedAuthorities(user), user, entityDetails, packageMenu);
        return loggedUserModel;
    }

    private List<GrantedAuthority> getGrantedAuthorities(User user) {
        List<GrantedAuthority> authorities = new ArrayList<>();

        authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

        return authorities;
    }

}
