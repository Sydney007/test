package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum GenderEnum {
    MALE("M"),
    FEMALE("F");

    private final String gender;

    GenderEnum(String gender) {
        this.gender = gender;
    }

    public static GenderEnum getByGender(String gender) {
        for (GenderEnum e : values()) {
            if (e.gender.equals(gender)) {
                return e;
            }
        }
        return null;
    }
}
