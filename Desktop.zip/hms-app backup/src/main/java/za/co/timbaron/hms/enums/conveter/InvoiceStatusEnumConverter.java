/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.enums.conveter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;

/**
 *
 * @author schauke
 */
@Converter
public class InvoiceStatusEnumConverter implements AttributeConverter<InvoiceStatusEnum, String> {

    @Override
    public String convertToDatabaseColumn(InvoiceStatusEnum value) {
        if (value == null) {
            return null;
        }

        return value.getStatus();
    }

    @Override
    public InvoiceStatusEnum convertToEntityAttribute(String value) {
        if (value == null) {
            return null;
        }

        return InvoiceStatusEnum.getByStatus(value);
    }
}
