package za.co.timbaron.hms.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.Api;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserDetails;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.model.Response;
import za.co.timbaron.hms.service.PatientService;
import za.co.timbaron.hms.service.UserService;
import za.co.timbaron.hms.util.UserPrincipalHelper;

/**
 *
 * @author Matimba
 */
@RestController
@Api(value = "User management API")
@RequestMapping({"/user"})
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private UserPrincipalHelper userprincipalHelper;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @RequestMapping(value = "/getUserdetails", method = RequestMethod.GET)
    public @ResponseBody
    Map getUserdetails() {

        Object userDetails = userprincipalHelper.getUserPrincipal();
        String jobTitle = "", companyName = "";

        UserTypeEnum userType = userprincipalHelper.getLoggedUser().getUserType();

        boolean isDoctor = false;

        if (userDetails instanceof HMSEntity) {

            HMSEntity entity = ((HMSEntity) userDetails);
            jobTitle = "";
            companyName = "";

        } else if (userDetails instanceof Employee) {

            Employee employee = ((Employee) userDetails);
            jobTitle = userType.getValue();
            companyName = employee.getEntity().getEntityName();
            isDoctor = true;

        } else if (userDetails instanceof Patient) {

            Patient patient = ((Patient) userDetails);
            //jobTitle = patient.getEmployer().getOccupationType().getType();
            //companyName = patient.getEmployer().getEmployerName();
        }

        Map<String, Object> user = new HashMap<>();
        user.put("entityDetails", userDetails);
        user.put("jobTitle", jobTitle);
        user.put("companyName", companyName);
        user.put("isDoctor", isDoctor);
        user.put("userTypeId", userprincipalHelper.getLoggedUser().getUserType().getId());

        return user;
    }

    @RequestMapping(value = "/saveOrUpdate", method = RequestMethod.POST)
    public @ResponseBody
    Map saveOrUpdateUser(MultipartHttpServletRequest request) {

        Map<String, Object> result = new HashMap<>();

        try {
            Timestamp now = new Timestamp(new java.util.Date().getTime());

            String visitBeanString = request.getParameter("userEditBean");
            UserDetails userDetails = objectMapper.readValue(visitBeanString, UserDetails.class);
            userDetails.setDateModified(now);

            List<MultipartFile> images = new ArrayList();

            MultipartFile file = request.getFile("file_0");
            if (file != null) {
                images.add(file);
            }

            Object principalDetails = userprincipalHelper.getUserPrincipal();

            //isDoctor
            /* (userDetails.getUserType() == UserTypeEnum.DOCTOR) {

                Employee oldEmpDetails = ((Employee) principalDetails);

                Employee updatedEmpDetails = new Employee();

                BeanUtils.copyProperties(userDetails, updatedEmpDetails);

                updatedEmpDetails.setEntityId(oldEmpDetails.getEntityId());
                updatedEmpDetails.setEmployeeNo(oldEmpDetails.getEmployeeNo());
                updatedEmpDetails.setId(oldEmpDetails.getId());

                updatedEmpDetails.getAddress().setUser(userService.findByIdNumber(oldEmpDetails.getIdentityNumber()));

                updatedEmpDetails.getEmergencyContact().setTitle(null);
                updatedEmpDetails.getEmergencyContact().setUserIdNo(oldEmpDetails.getIdentityNumber());

                if (oldEmpDetails.getAddress() != null) {
                    updatedEmpDetails.getAddress().setId(oldEmpDetails.getAddress().getId());
                }

                if (oldEmpDetails.getEmergencyContact() != null) {
                    updatedEmpDetails.getEmergencyContact().setId(oldEmpDetails.getEmergencyContact().getId());
                }

                userService.persistObject(updatedEmpDetails);

            } else //isPatient
            if (UserTypeEnum.PATIENT == userDetails.getUserType()) {

                Patient patient = new Patient();
                BeanUtils.copyProperties(userDetails, patient);

                patient.setIdentityNumber(userprincipalHelper.getLoggedUser().getIdentityNumber());
                userService.persistObject(patient);

            }*/
            result.put("message", "Profile updated successfully");
            result.put("errorOccurred", false);

        } catch (Exception e) {
            result.put("message", e.getMessage());
            result.put("errorOccurred", true);

            e.printStackTrace();
        }
        return result;
    }

    @RequestMapping(value = "/getEvaluations", method = RequestMethod.GET)
    public @ResponseBody
    Map getEvaluations() {

        Map<String, Object> user = new HashMap<>();

        return user;
    }

    @RequestMapping(value = "/gallery", method = RequestMethod.GET)
    public @ResponseBody
    List loadUserGallery() {
        return patientService.findPatientScansByIdNo(userprincipalHelper.getLoggedUser().getIdentityNumber());
    }

    @RequestMapping(value = "/getPrescriptions", method = RequestMethod.GET)
    public @ResponseBody
    List getPrescriptions() {
        Patient patient = patientService.findByIdentityNumber(userprincipalHelper.getLoggedUser().getIdentityNumber());
        return patientService.findPatientMedicationById(patient.getId());
    }

    @RequestMapping(value = "/getInvoices", method = RequestMethod.GET)
    public @ResponseBody
    List<Invoice> getInvoices() {
        return patientService.findPatientInvoicesByIdNo(userprincipalHelper.getLoggedUser().getIdentityNumber());
    }

    @RequestMapping(value = "/getWallet", method = RequestMethod.GET)
    public @ResponseBody
    Map getWallet() {
        Map<String, Object> user = new HashMap<>();

        return user;
    }

    @RequestMapping(value = "/getMedicalProblems", method = RequestMethod.GET)
    public @ResponseBody
    List getMedicalProblems() {
        Patient patient = patientService.findByIdentityNumber(userprincipalHelper.getLoggedUser().getIdentityNumber());
        return patientService.findPatientMedicalProblemsByPatient(patient.getId());
    }

    @RequestMapping(value = "/findByIdNumber", method = RequestMethod.GET)
    public @ResponseBody
    User findByIdNumber(@RequestParam String identityNo) {
        return userService.findByIdNumber(identityNo);
    }

    @RequestMapping(value = "/updateUserCredentials", method = RequestMethod.POST)
    public @ResponseBody
    Response updateUserCredentials(@RequestBody User user) {
        Response response = new Response();

        try {
            /*String password = passwordEncoder.encode(user.getOriginalPasswordBean()..getPassword());
            user.setPassword(password);
            userService.persistObject(user);
            userService.persistObject(user.getOriginalPasswordBean());
            response.setFailed(false);
            response.setMessage("User credentials updated successfully.");*/
        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
        }

        return response;
    }

}
