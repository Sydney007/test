/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

/**
 *
 * @author ABMC684
 */
import java.io.IOException;

import org.apache.commons.lang.WordUtils;

public class WrapTest {

    private final static int DOC_BODY_NUM_ROWS = 19;

    /*public static void main(String[] args) throws IOException {

        StringBuilder str = new StringBuilder("<p>A great property for a young family or business professional looking for the convenient lock up and go home in a secure environment.\n"
                + "This lovely unit is located in Dekko Heights complex, which is arguably one of the most sought after complexes in Halfway Gardens. Dekko Heights is located on Smuts Drive, "
                + "which offers great access to the surrounding schools, shopping centers and major routes.</p>");

        String paragraph = str.toString().replace("</p>", "").replace("<p>", "");

        String value = WordUtils.wrap(paragraph, 150, "<br/>", false);

        String paragraphs[] = value.split("<br/>");

        int numParagraphs = paragraphs.length;

        String textHeading = "Nature of illness";

        StringBuilder tableRows = new StringBuilder("<table style=\"font-family: Algerian;font-family: Algerian; color: #23527c; font-size: 8px;\">\n"
                + "<tr>\n"
                + "<td height=\"30px\">\n"
                + "</td>\n"
                + "</tr>\n"
                + "<tr>\n"
                + "<td width=\"14%\" style=\"text-align:left;\">\n"
                + "<span style=\"font-family: Algerian; color: #23527c; font-size: 10px; \"> " + textHeading + "</span>"
                + "</td>\n"
                + "<td>\n"
                + "<span>"
                + paragraphs[0] + "</span><br/>\n"
                + "<span>"
                + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                + "------------------------------------------------------------------------------------------"
                + "</span>"
                + "</td>\n"
                + "</tr>  \n");

        for (int i = 1; i < numParagraphs; i++) {
            tableRows.append("<tr>"
                    + "<td colspan=\"2\">"
                    + "<span>" + paragraphs[i] + "</span><br/>"
                    + "<span>"
                    + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                    + "------------------------------------------------------------------------------------------------------------------------------"
                    + "</span>"
                    + "</td>"
                    + "</tr>");
        }

        int totalEmptyNumRows = DOC_BODY_NUM_ROWS - numParagraphs;

        for (int i = 1; i < totalEmptyNumRows; i++) {
            tableRows.append("<tr>"
                    + "<td colspan=\"2\">"
                    + "<span></span><br/>"
                    + "<span>"
                    + "-----------------------------------------------------------------------------------------------------------------------------------------------------"
                    + "------------------------------------------------------------------------------------------------------------------------------"
                    + "</span>"
                    + "</td>"
                    + "</tr>");
        }

        tableRows.append("</table>");

        System.out.println(tableRows);

    }*/
}
