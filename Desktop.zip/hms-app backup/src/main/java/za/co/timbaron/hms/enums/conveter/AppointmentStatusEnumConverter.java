/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.enums.conveter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import za.co.timbaron.hms.enums.AppointmentStatusEnum;

/**
 *
 * @author schauke
 */
@Converter
public class AppointmentStatusEnumConverter implements AttributeConverter<AppointmentStatusEnum, String> {

    @Override
    public String convertToDatabaseColumn(AppointmentStatusEnum value) {
        if (value == null) {
            return null;
        }

        return value.getDescription();
    }

    @Override
    public AppointmentStatusEnum convertToEntityAttribute(String value) {
        if (value == null) {
            return null;
        }

        return AppointmentStatusEnum.getByDescription(value);
    }
}
