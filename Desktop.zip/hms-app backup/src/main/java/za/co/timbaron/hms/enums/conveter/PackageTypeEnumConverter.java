package za.co.timbaron.hms.enums.conveter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import za.co.timbaron.hms.enums.PackageTypeEnum;

@Converter
public class PackageTypeEnumConverter  implements AttributeConverter<PackageTypeEnum, String> {

    @Override
    public String convertToDatabaseColumn(PackageTypeEnum value) {
        if (value == null) {
            return null;
        }

        return value.getValue();
    }

    @Override
    public PackageTypeEnum convertToEntityAttribute(String value) {
        if (value == null) {
            return null;
        }

        return PackageTypeEnum.getByValue(value);
    }
    
}
