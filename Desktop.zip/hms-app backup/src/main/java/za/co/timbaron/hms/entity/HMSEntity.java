package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;
import za.co.timbaron.hms.enums.AccountTypeEnum;
import za.co.timbaron.hms.enums.EntityTypeEnum;
import za.co.timbaron.hms.enums.PackageTypeEnum;
import za.co.timbaron.hms.enums.conveter.AccountTypeEnumConverter;
import za.co.timbaron.hms.enums.conveter.EntityTypeEnumConverter;
import za.co.timbaron.hms.enums.conveter.PackageTypeEnumConverter;

@Data
@Entity
@Table(name = "HMS_ENTITY")
public class HMSEntity implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "CONSULTATIONFEE", unique = false, nullable = false)
    private BigDecimal consultationFee;

    @Column(name = "ENTITYNAME", unique = true, nullable = false)
    private String entityName;

    @Column(name = "ENTITYSUBNAMEGROUP", unique = true, nullable = false)
    private String entitySubNameGroup;

    @Column(name = "TELEPHONE", unique = true, nullable = false)
    private String telephone;

    @Column(name = "FAXNUMBER", unique = true, nullable = false)
    private String faxNumber;

    @Column(name = "EMAIL", unique = true, nullable = false)
    private String email;

    @Column(name = "LOGO", unique = true, nullable = false)
    private String logo;

    @Column(name = "PROFILEPIC", unique = true, nullable = false)
    private String profilePic;

    @Column(name = "DATECREATED", nullable = false)
    private Date dateCreated;

    @Column(name = "ENTITYDISPENSEMEDICINE", nullable = false)
    private boolean entityDispenseMedicine;

    @Column(name = "REGISTRATIONNUMBER", nullable = false)
    private String registrationNumber;

    @Column(name = "PRACTICENO", nullable = false)
    private String practiceNo;

    @Convert(converter = PackageTypeEnumConverter.class)
    @Column(name = "PACKAGETYPE", nullable = false)
    private PackageTypeEnum packageType;

    @Convert(converter = EntityTypeEnumConverter.class)
    @Column(name = "ENTITYTYPE", nullable = false)
    private EntityTypeEnum entityType;

    @Convert(converter = AccountTypeEnumConverter.class)
    @Column(name = "ACCOUNTTYPE", nullable = false)
    private AccountTypeEnum accountType;

    @OneToMany(mappedBy = "entity", cascade = CascadeType.ALL)
    private Set<Employee> employees = new HashSet();

    @OneToMany(mappedBy = "entity", cascade = CascadeType.ALL)
    private Set<Visit> visits = new HashSet();
    
    @OneToMany(mappedBy = "entity", cascade = CascadeType.ALL)
    private Set<Medicine> medicines = new HashSet();

}
