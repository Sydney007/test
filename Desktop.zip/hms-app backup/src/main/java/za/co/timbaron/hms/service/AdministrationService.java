package za.co.timbaron.hms.service;

import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.entity.HMSEntity;

@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface AdministrationService {

    Appointment findById(long id);

    List<Appointment> findAppointmentsByEntity(HMSEntity entity, String startDate, String endDate);

    List<Appointment> findUserAppointmentsById(long userId, String startDate, String endDate);

    void save(Appointment appointment);

    void delete(Appointment appointment);
    
    void persistObject(Object entity);

}
