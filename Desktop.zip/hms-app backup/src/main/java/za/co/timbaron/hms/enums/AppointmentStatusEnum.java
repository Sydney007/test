package za.co.timbaron.hms.enums;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum AppointmentStatusEnum {

    ACCEPTED("Accepted", 1),
    CANCELLED("Cancelled", 2),
    DECLINED("Declined", 3),
    NEW_TIME("New Time", 4),
    UNKNOW("Unknown", 0);

    private final String description;
    private final long id;

    AppointmentStatusEnum(String description, int id) {
        this.description = description;
        this.id = id;
    }

    public static AppointmentStatusEnum getByDescription(String type) {
        for (AppointmentStatusEnum e : values()) {
            if (e.description.equals(type)) {
                return e;
            }
        }
        return UNKNOW;
    }

    public static AppointmentStatusEnum getById(long id) {
        for (AppointmentStatusEnum e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        return UNKNOW;
    }
}
