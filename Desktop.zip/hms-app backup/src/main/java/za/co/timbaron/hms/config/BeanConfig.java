/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import za.co.timbaron.hms.entity.DropDownValuesUtil;
import za.co.timbaron.hms.entity.RedirectBean;
import za.co.timbaron.hms.util.EntityHelperBean;
import za.co.timbaron.hms.util.DaysTimeDifferenceUtil;
import za.co.timbaron.hms.util.DocumentUtilAndUploader;
import za.co.timbaron.hms.util.EmailUtil;
import za.co.timbaron.hms.util.EntityIdAndIDNumberBeanHelper;
import za.co.timbaron.hms.util.DocumentUtil;
import za.co.timbaron.hms.util.NumbersGenerator;
import za.co.timbaron.hms.util.POICellValuesUtil;
import za.co.timbaron.hms.util.UserPrincipalHelper;

/**
 *
 * @author Matimba
 */
@Configuration
public class BeanConfig {

    @Bean
    public DocumentUtil getInvoiceUtil() {
        return new DocumentUtil();
    }

    @Bean
    public RedirectBean getRedirectBean() {
        return new RedirectBean();
    }

    @Bean
    public Gson gson() {
        return new Gson();
    }

    @Bean
    public NumbersGenerator accountNoAndInvoiceNoGenerator() {
        return new NumbersGenerator();
    }

    @Bean
    public DropDownValuesUtil dropDownValuesUtil() {
        return new DropDownValuesUtil();
    }

    @Bean
    public DocumentUtilAndUploader getDocumentUtilAndUploader() {
        return new DocumentUtilAndUploader();
    }

    @Bean
    public DaysTimeDifferenceUtil getDaysTimeDifferenceUtil() {
        return new DaysTimeDifferenceUtil();
    }

    @Bean
    public POICellValuesUtil getPOICellValuesUtil() {
        return new POICellValuesUtil();
    }

    @Bean
    public UserPrincipalHelper getUserPrincipalHelper() {
        return new UserPrincipalHelper();
    }

    @Bean
    public EntityIdAndIDNumberBeanHelper getEntityIdAndIDNumberBeanHelper() {
        return new EntityIdAndIDNumberBeanHelper();
    }

    @Bean
    public EmailUtil getEmailUtil() {
        return new EmailUtil();
    }

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper;
    }

    @Bean
    public EntityHelperBean entityHelperBean() {
        return new EntityHelperBean();
    }
}
