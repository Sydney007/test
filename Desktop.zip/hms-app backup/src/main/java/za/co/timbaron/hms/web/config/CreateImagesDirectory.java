/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.web.config;

import java.io.File;

/**
 *
 * @author Matimba
 */
public class CreateImagesDirectory {

    private String directory;
    private final String projectHome = System.getProperty("user.dir");

    public CreateImagesDirectory() {

        File imagesDirectory = new File(projectHome + "/src/main/webapp/resources/images");

        if (!imagesDirectory.exists()) {
            imagesDirectory.mkdir();
        }

    }

    public String getDirectory() {
        return directory;
    }

}
