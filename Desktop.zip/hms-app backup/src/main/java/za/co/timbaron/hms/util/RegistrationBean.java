/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import java.io.Serializable;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserImage;

/**
 *
 * @author sydney
 */
public class RegistrationBean implements Serializable {

    private HMSEntity entity;
    private User account;
    private UserImage logo;

    public HMSEntity getEntity() {
        return entity;
    }

    public void setEntity(HMSEntity entity) {
        this.entity = entity;
    }

    public User getAccount() {
        return account;
    }

    public void setAccount(User account) {
        this.account = account;
    }

    public UserImage getLogo() {
        return logo;
    }

    public void setLogo(UserImage logo) {
        this.logo = logo;
    }
}
