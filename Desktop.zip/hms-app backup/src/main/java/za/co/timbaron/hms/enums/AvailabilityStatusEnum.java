package za.co.timbaron.hms.enums;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum AvailabilityStatusEnum {

    AVAILABLE("Available", "#26B99A", "fa-check-circle"),
    AWAY("Away", "#f47920", "fa-toggle-off"),
    BUSY("Busy", "#FF0000", "fa-ban"),
    DO_NOT_DISTURB("Do not Disturb", "#FF0000", "fa-minus-circle"),
    OFFLINE("Offline", "#FF0000", "fa-minus-circle");

    private final  String status;
    private final  String styleClass;
    private final  String icon;

    AvailabilityStatusEnum(String status, String styleClass, String icon) {
        this.status = status;
        this.styleClass = styleClass;
        this.icon = icon;
    }


    public static AvailabilityStatusEnum getByStatus(String status) {
        for (AvailabilityStatusEnum e : values()) {
            if (e.status == null ? status == null : e.status.equals(status)) {
                return e;
            }
        }
        return null;
    }
}
