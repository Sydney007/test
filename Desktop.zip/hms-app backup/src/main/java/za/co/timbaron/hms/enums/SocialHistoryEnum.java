package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum SocialHistoryEnum {
    NO,
    EVERY_2_DAYS,
    EVERY_WEEK,
    DAILY,
    ONCE_A_MONTH,
    ONCE_A_WEEK;
}
