/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Patient;

@Repository
@Transactional
public interface AppointmentRepo extends JpaRepository<Appointment, Long> {

    List<Appointment> findAllByEntity(HMSEntity entity);

    List<Appointment> findAllByPatient(Patient patient);

    @Query("select a From Appointment a where a.entity = :entity and DATE_FORMAT(a.startDate, '%Y-%m-%d') >= :startDate "
            + " AND DATE_FORMAT(a.endDate, '%Y-%m-%d') <= :endDate")
    List<Appointment> findAllByEntityAndDateRange(@Param("entity") HMSEntity entity, @Param("startDate") String startDate, @Param("endDate") String endDate);

    List<Appointment> findAllByEntityAndStartDateGreaterThanEqualAndEndDateLessThanEqual(HMSEntity entity, String startDate, String endDate);

    //Will be revisited
    /*@Query("select a From Appointment a where a.userId = :userId and DATE_FORMAT(a.STARTDATE, '%Y-%m-%d') >= :startDate "
            + " OR DATE_FORMAT(a.ENDDATE, '%Y-%m-%d') <= :endDate")
    List<Appointment> findAllByUserAppointmentsByIdAndStartDateAndEndDates(@Param("userId") long userId, @Param("startDate") Date startDate, @Param("endDate") Date endDate);
     */
    //List<Appointment> findAllByUserIdAndStartDateGreaterThanEqualAndEndDateLessThanEqual(long entityId, Date startDate, Date endDate);
}
