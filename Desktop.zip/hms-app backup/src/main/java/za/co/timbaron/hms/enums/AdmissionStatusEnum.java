package za.co.timbaron.hms.enums;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum AdmissionStatusEnum {
    ADMITTED,
    DISCHARGED;
}
