package za.co.timbaron.hms.service.impl;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.EntityPatient;
import za.co.timbaron.hms.entity.Evaluation;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.MedicalAid;
import za.co.timbaron.hms.entity.PatientMedicalProblem;
import za.co.timbaron.hms.entity.PatientMedication;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.PaymentTransaction;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.VisitReferral;
import za.co.timbaron.hms.entity.Wallet;
import za.co.timbaron.hms.enums.UploadTypeEnum;
import za.co.timbaron.hms.repository.AppointmentRepo;
import za.co.timbaron.hms.repository.EmployerRepo;
import za.co.timbaron.hms.repository.EntityPatientRepo;
import za.co.timbaron.hms.repository.EvaluationRepo;
import za.co.timbaron.hms.repository.InvoiceRepo;
import za.co.timbaron.hms.repository.MedicalAidRepo;
import za.co.timbaron.hms.repository.PatientMedicalProblemRepo;
import za.co.timbaron.hms.repository.PatientMedicationRepo;
import za.co.timbaron.hms.repository.PatientRepo;
import za.co.timbaron.hms.repository.PaymentTransactionRepo;
import za.co.timbaron.hms.repository.UserImageRepo;
import za.co.timbaron.hms.repository.VisitReferralRepo;
import za.co.timbaron.hms.repository.VisitRepo;
import za.co.timbaron.hms.service.PatientService;

/**
 *
 * @author Matimba
 */
@Service("patientService")
public class PatientServiceImpl implements PatientService {

    @Autowired
    private PatientRepo patientRepo;

    @Autowired
    private EntityPatientRepo entityPatientRepo;

    @Autowired
    private VisitRepo visitRepo;

    @Autowired
    private AppointmentRepo appointmentRepo;

    @Autowired
    private EmployerRepo employerRepo;

    @Autowired
    private MedicalAidRepo medicalAidRepo;

    @Autowired
    private UserImageRepo userImageRepo;

    @Autowired
    private InvoiceRepo invoiceRepo;

    @Autowired
    private VisitReferralRepo visitReferralRepo;

    @Autowired
    private PaymentTransactionRepo paymentTransactionRepo;

    @Autowired
    private PatientMedicalProblemRepo patientMedicalProblemRepo;

    @Autowired
    private PatientMedicationRepo patientMedicationRepo;

    @Autowired
    private EvaluationRepo evaluationRepo;

    @Override
    public Patient findById(long id) {
        return patientRepo.findById(id).get();
    }

    @Override
    public Patient findByIdentityNumber(String identityNumber) {
        return patientRepo.findByIdentityNumber(identityNumber);
    }

    @Override
    public List<Patient> findAllByEntityId(long entityId) {
        List<EntityPatient> entityPatients = entityPatientRepo.findAllByEntityId(entityId);

        List<Patient> patients = new ArrayList();

        for (EntityPatient entityPatient : entityPatients) {
            patients.add(entityPatient.getPatient());
        }

        patients.stream().filter((patient) -> (patient.getUserDetails().getWallet() == null)).forEachOrdered((patient) -> {
            Wallet wallet = new Wallet();
            wallet.setBalance(BigDecimal.ZERO);
            patient.getUserDetails().setWallet(wallet);
        });
        return patients;
    }

    @Override
    public List<Appointment> findAllPatientAppointments(Patient patient) {
        return appointmentRepo.findAllByPatient(patient);
    }

    @Override
    public List<Visit> findAllPatientVisits(Patient patient) {
        return visitRepo.findAllByPatient(patient);
    }

    @Override
    public List<Visit> findPatientVisitsByDateRange(Patient patient, Date startDate, Date endDate) {
        return visitRepo.findAllByPatientAndVisitDateBetween(patient, startDate, endDate);
    }

    @Override
    public void save(Patient patient) {
        patientRepo.save(patient);
    }

    @Override
    public void delete(Patient patient) {
        patientRepo.delete(patient);
    }

    @Override
    public EntityPatient findEntityPatientByIdNo(String identityNumber) {
        return entityPatientRepo.findByPatientIdNo(identityNumber);
    }

    /*@Override
    public Employer findPatientEmployerByIdNo(String identityNumber) {
        return employerRepo.findByUserIdNo(identityNumber);
    }*/
    @Override
    public MedicalAid findPatientMedicalAidByIdNo(String identityNumber) {
        return medicalAidRepo.findByIdentityNumber(identityNumber);
    }

    @Override
    public List<PaymentTransaction> findPatientWalletTransactionsByIdNo(String identityNumber) {
        return paymentTransactionRepo.findAllByPatientIdNo(identityNumber);
    }

    @Override
    public List<Long> findAllEntityVisitsByPatient(Patient patient) {
        return visitRepo.findAllPatientVisitsEntitiesByPatient(patient);
    }

    @Override
    public List<Long> findAllPatientVisitsEntitiesByPatientAndDateRange(Patient patient, Date startDate, Date endDate) {
        return visitRepo.findAllPatientVisitsEntitiesByPatientAndDateRange(patient, startDate, endDate);
    }

    @Override
    public List<Visit> findPatientVisitsByEntity(Patient patient, HMSEntity entity) {
        return visitRepo.findAllByPatientAndEntity(patient, entity);
    }

    @Override
    public List<Visit> findPatientVisitsByEntityAndDateRange(Patient patient, HMSEntity entity, Date startDate, Date endDate) {
        return visitRepo.findAllByPatientAndEntityAndVisitDateBetween(patient, entity, startDate, endDate);
    }

    @Override
    public List<Visit> findPatientReferralVisitsByIdNo(Patient patient) {
        return visitRepo.findAllByPatientAndReferralVisit(patient, true);
    }

    @Override
    public UserImage findImageByIdNoAndUploadTypeId(UploadTypeEnum uploadType, User user) {
        return userImageRepo.findByUserAndUploadType(user, uploadType);
    }

    @Override
    public List<Invoice> findPatientInvoicesByIdNo(String identityNumber) {
        return invoiceRepo.findAllByPatientIdNo(identityNumber);
    }

    @Override
    public VisitReferral findVisitReferralByVisitId(Long visitId) {
        return visitReferralRepo.findByVisitId(visitId);
    }

    @Override
    public List<PatientMedicalProblem> findPatientMedicalProblemsByPatient(long patientId) {
        return patientMedicalProblemRepo.findAllByPatientId(patientId);
    }

    @Override
    public List<PatientMedication> findPatientMedicationById(long patientId) {
        return patientMedicationRepo.findAllByPatientId(patientId);
    }

    @Override
    public List<UserImage> findPatientScansByIdNo(String identityNumber) {
        return userImageRepo.findAllByUserIdNo(identityNumber);
    }

    @Override
    public List<Evaluation> findPatientPatientEvaluationsByIdNo(String identityNumber) {
        return evaluationRepo.findAllByPatientIdNo(identityNumber);
    }

    @Override
    public void persistObject(Object entity) {
    }
}
