/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "HMS_VISIT_TREATMENTS")
public class VisitTreatment implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "VISITDATE", unique = true, nullable = false)
    private Timestamp visitDate;

    @Column(name = "EMPLOYEEIDNO", unique = true, nullable = false)
    private String employeeIdNo;

    @Column(name = "PATIENTIDNO", unique = true, nullable = false)
    private String patientIdNo;

    @Column(name = "TREATMENT", unique = true, nullable = false)
    private String treatment;

    @Column(name = "DESCRIPTION", unique = true, nullable = false)
    private String description;

    @Column(name = "AMOUNT", unique = true, nullable = false)
    private BigDecimal amount;

    @Column(name = "TOTALAMOUNT", unique = true, nullable = false)
    private BigDecimal totalAmount;

    @Column(name = "QUANTITY", unique = true, nullable = false)
    private long quantity;

    @Column(name = "INVOICEID", nullable = false)
    private long invoiceId;

    @Transient
    private boolean newRecord; //for new Invoice entry

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;

}
