/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_SOCIAL_HISTORY")
public class SocialHistory implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "ALCOHOL", unique = true, nullable = false)
    private String alcohol;

    @Column(name = "EXERCISE", unique = true, nullable = false)
    private String exercise;

    @Column(name = "DRUGS", unique = true, nullable = false)
    private String drugs;

    @Column(name = "SMOKING", unique = true, nullable = false)
    private String smoking;

    @Column(name = "EMPLOYEEID", unique = true, nullable = false)
    private long employeeId;

    @Column(name = "PATIENTID", unique = true, nullable = false)
    private long patientId;

    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;
}
