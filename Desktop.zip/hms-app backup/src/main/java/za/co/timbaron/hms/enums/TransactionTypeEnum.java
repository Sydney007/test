package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum TransactionTypeEnum {
    CREDIT,
    DEBIT,
    DEPOSIT,
    PAYMENT,
}
