package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum LanguageEnum {
    AFRIKAANS,
    ENGLISH,
    SOTHO,
    XITSONGA,
    TSHIVENDA,
    ISIZULU,
    ISIXHOSA,
    TSWANA;
}
