package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum MaritalStatusEnum {
    DIVORCED,
    MARRIED,
    COMMON_LAW,
    SINGLE,
    SEPARATED,
    WIDOWED;
}
