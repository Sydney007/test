package za.co.timbaron.hms.enums;

import java.text.MessageFormat;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum AppointmentFrequentlyEnum {

    WEEKLY("Weekly", 1),
    MONTHLY("Monthly", 2),
    ONCEOFF("OnceOff", 3);

    private final String description;
    private final long id;

    AppointmentFrequentlyEnum(String description, int id) {
        this.description = description;
        this.id = id;
    }

    public static AppointmentFrequentlyEnum getByDescription(String description) {
        for (AppointmentFrequentlyEnum e : values()) {
            if (e.description.equalsIgnoreCase(description)) {
                return e;
            }
        }
        log.warn(MessageFormat.format("Invalid type for AppointmentFrequentlyEnum: {0}", description));
        return null;
    }

    public static AppointmentFrequentlyEnum getById(int id) {
        for (AppointmentFrequentlyEnum e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        log.warn(MessageFormat.format("Invalid id for AppointmentFrequentlyEnum: {0}", id));
        return null;
    }
}
