/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.service;

import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.DropDownValuesUtil;
import za.co.timbaron.hms.entity.MedicalTreatment;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.enums.AllergyEnum;
import za.co.timbaron.hms.enums.MedicalProblemEnum;
import za.co.timbaron.hms.enums.VaccineEnum;


@Transactional(propagation = Propagation.REQUIRED, readOnly = false, rollbackFor = Exception.class)
public interface HMSUtilService {

    List<MedicalProblemEnum> getMedicalProblems();

    List<AllergyEnum> getAllergies();

    List<Medicine> getAllMedicines();

    List<VaccineEnum> getAllVaccines();

    String getMaxValue(String tableName, String field) throws Exception;

    List lookUp(String searchString, String tableName, String searchField) throws Exception;

    User checkUserAvailability(String username);

    DropDownValuesUtil getDropDownValuesUtil(long entityId) throws Exception;

    MedicalTreatment findMedicalTreatmentById(long id);

    void delete(String tableName, long id) throws Exception;

    UserImage findProfilePicByIdNo(User user);

}
