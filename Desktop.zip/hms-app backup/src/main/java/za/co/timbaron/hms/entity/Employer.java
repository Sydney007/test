package za.co.timbaron.hms.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import za.co.timbaron.hms.enums.EmploymentTypeEnum;
import za.co.timbaron.hms.enums.OccupationTypeEnum;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "HMS_EMPLOYER")
public class Employer implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "EMPLOYERNAME", nullable = false)
    private String employerName;

    @Column(name = "TELEPHONE", nullable = false)
    private String telephone;

    @Column(name = "EMPLOYEENO", nullable = false)
    private String employeeNo;

    @Column(name = "EMPLOYEDFROM", nullable = false)
    private String employedFrom;

    @Column(name = "EMPLOYED", nullable = false)
    private boolean employed;

    @Enumerated(EnumType.STRING)
    @Column(name = "EMPLOYMENTTYPE", nullable = false)
    private EmploymentTypeEnum employmentTypeId;

    @Enumerated(EnumType.STRING)
    @Column(name = "OCCUPATIONTYPE", nullable = false)
    private OccupationTypeEnum occupationType;

    @Column(name = "DEPARTMENT", nullable = false)
    private String department;

    @OneToOne
    @JoinColumn(name = "USERID", referencedColumnName = "ID")
    private User user;
}
