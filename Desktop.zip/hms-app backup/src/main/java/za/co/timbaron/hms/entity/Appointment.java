package za.co.timbaron.hms.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.AppointmentFrequentlyEnum;
import za.co.timbaron.hms.enums.AppointmentStatusEnum;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.enums.conveter.AppointmentStatusEnumConverter;
import za.co.timbaron.hms.enums.conveter.UserTypeEnumConverter;
import za.co.timbaron.hms.util.Day;

@Entity
@Getter
@Setter
@Table(name = "HMS_APPOINTMENT")
public class Appointment implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "ALLDAY")
    private boolean allDay;

    @Column(name = "STARTTIME")
    private String startTime;

    @Column(name = "ENDTIME")
    private String endTime;

    @Column(name = "STARTDATE")
    private String startDate;

    @Column(name = "ENDDATE")
    private String endDate;

    @Column(name = "VISITDATE", nullable = false)
    private Date visitDate;

    @Column(name = "DESCRIPTION", nullable = false)
    private String description;

    @Column(name = "INTERVAL_", nullable = false)
    private long interval;

    @Column(name = "BYMONTHDAY", nullable = false)
    private String byMonthDay;

    @Column(name = "BYWEEKDAYS", nullable = false)
    private String byWeekDays;

    @Column(name = "PARENTID", nullable = false)
    private long parentId;

    @Transient
    private String patientIdNo;

    @Transient
    private List<Day> weeklyDays;

    @Transient
    private boolean newEvent;

    @Enumerated(EnumType.STRING)
    @Column(name = "FREQUENTLY", nullable = false)
    private AppointmentFrequentlyEnum frequently;

    @Convert(converter = UserTypeEnumConverter.class)
    @Column(name = "USERTYPE", nullable = false)
    private UserTypeEnum userType;

    @Convert(converter = AppointmentStatusEnumConverter.class)
    @Column(name = "STATUS")
    private AppointmentStatusEnum status;

    @JsonIgnore
    @Column(name = "CREATEDBYID")
    private long createdById;

    @ManyToOne
    @JoinColumn(name = "ENTITYID", referencedColumnName = "ID")
    private HMSEntity entity;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;

    @ManyToOne
    @JoinColumn(name = "PATIENTID", referencedColumnName = "ID")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "DOCTORID", referencedColumnName = "ID")
    private Employee doctor;

    @OneToOne
    @JoinColumn(name = "CREATEDBYID", referencedColumnName = "ID", insertable = false, updatable = false)
    private Employee createdBy;

    @JsonBackReference
    @OneToMany(mappedBy = "appointment", cascade = CascadeType.PERSIST)
    private Set<AppointmentDateRange> appointmentDateRanges = new HashSet();

}
