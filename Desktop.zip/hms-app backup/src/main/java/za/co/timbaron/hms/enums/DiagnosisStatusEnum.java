package za.co.timbaron.hms.enums;

import java.text.MessageFormat;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum DiagnosisStatusEnum {

    ACUTE("Acute", "#26B99A"),
    BAD("Bad", "#f47920"),
    CRITICAL("Critical", "#FF0000"),
    GOOD("Good", "#26B99A"),
    NORMAL("Normal", "#26B99A");

    private final String status;
    private final String css;

    DiagnosisStatusEnum(String status, String css) {
        this.status = status;
        this.css = css;
    }

    public String getStatus() {
        return status;
    }

    public static DiagnosisStatusEnum getByStatus(String status) {
        for (DiagnosisStatusEnum e : values()) {
            if (e.status.equals(status)) {
                return e;
            }
        }
        log.warn(MessageFormat.format("Invalid status for DiagnosisStatusEnum: {0}", status));
        return null;
    }
}
