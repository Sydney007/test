package za.co.timbaron.hms;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Slf4j
@EnableJpaRepositories
@SpringBootApplication
@ComponentScan
public class HmsApp {

    public static void main(String[] args) {
        SpringApplication.run(HmsApp.class, args);
        log.debug("--Application has Started--");
    }
}
