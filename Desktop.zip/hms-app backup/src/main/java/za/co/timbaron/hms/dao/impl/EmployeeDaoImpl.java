/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.dao.impl;

/**
 *
 * @author Matimba
 */

public class EmployeeDaoImpl  {

    /*@Override
    public Employee getEmployeeById(long id) {

        CriteriaBuilder cb = createEntityCriteriaBuilder();

        CriteriaQuery<Employee> cr = createEntityCriteria();
        Root<Employee> root = createEntityRootCriteria();

        cr.select(root).where(cb.equal(root.get("id"), id));

        Query<Employee> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    @Override
    public Employee getEmployeeByEmployeeNumber(String employeeNumber) {

        CriteriaBuilder cb = createEntityCriteriaBuilder();
        CriteriaQuery<Employee> cr = createEntityCriteria();
        Root<Employee> root = createEntityRootCriteria();

        cr.select(root).where(cb.equal(root.get("employeeNo"), employeeNumber));

        Query<Employee> query = getSession().createQuery(cr);

        return query.uniqueResult();

    }

    @Override
    public Employee getEmployeeByIDNumber(String idNumber) {

        CriteriaBuilder cb = createEntityCriteriaBuilder();
        CriteriaQuery<Employee> cr = createEntityCriteria();
        Root<Employee> root = createEntityRootCriteria();

        cr.select(root).where(cb.equal(root.get("identityNumber"), idNumber));

        Query<Employee> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    @Override
    public List<Employee> checkEmployeeAvailabilty(long entityId) {

        CriteriaBuilder builder = createEntityCriteriaBuilder();
        CriteriaQuery<Employee> criteriaQuery = createEntityCriteria();
        Root<Employee> root = createEntityRootCriteria();

        Predicate[] predicates = new Predicate[2];
        predicates[0] = builder.equal(builder.upper(root.get("entityId")), entityId);
        predicates[1] = builder.equal(builder.upper(root.get("userTypeId")), new Long(2));

        criteriaQuery.select(root).where(predicates);

        Query<Employee> query = getSession().createQuery(criteriaQuery);

        return query.list();
    }

    @Override
    public List<Notification> getEmployeeNotifications(long entityId, long employeeId) {

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery<Notification> criteriaQuery = builder.createQuery(Notification.class);
        Root<Notification> root = criteriaQuery.from(Notification.class);

        Predicate[] predicates = new Predicate[2];
        predicates[0] = builder.equal(builder.upper(root.get("entityId")), entityId);
        predicates[1] = builder.equal(builder.upper(root.get("toEmployeeId")), employeeId);

        criteriaQuery.select(root).where(predicates).distinct(true);

        Query<Notification> query = getSession().createQuery(criteriaQuery);

        return query.list();
    }

    @Override
    public void saveOrUpdate(Employee employee) {
        persist(employee);
    }

    @Override
    public List<Notification> getAllNotifications(long entityId, Date fromDate, Date toDate) {
        /*StringBuilder myQuery = new StringBuilder();
        myQuery.append("From Notification ").append(" where entityId = :entityId and DATE_FORMAT(notificationDate, '%Y-%m-%d') between '")
                .append(fromDate).append("' and '").append(toDate)
                .append("'");

        Query qry = getSession().createQuery(myQuery.toString());
        qry.setParameter("entityId", entityId);*/

        /*CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Notification> cr = cb.createQuery(Notification.class);
        Root<Notification> root = cr.from(Notification.class);

        Predicate[] predicates = new Predicate[2];
        predicates[0] = cb.equal(cb.upper(root.get("entityId")), entityId);
        predicates[1] = cb.between(root.get("notificationDate"), fromDate, toDate);
        
        //cq.select( cb.function("to_char", String.class, root.get("begin_exam"), cb.literal("YYYY-MM-DD")));


        cr.select(root).where(predicates).distinct(true);

        Query<Notification> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public Notification findNotificationById(long id) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Notification> cr = cb.createQuery(Notification.class);
        Root<Notification> root = cr.from(Notification.class);
        cr.select(root).where(cb.equal(root.get("id"), id));

        Query<Notification> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }


    @Override
    public Notification findNotificationByPatientId(long patientId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Notification> cr = cb.createQuery(Notification.class);
        Root<Notification> root = cr.from(Notification.class);
        cr.select(root).where(cb.equal(root.get("patientId"), patientId));

        Query<Notification> query = getSession().createQuery(cr);

        return query.uniqueResult();

    }

    @Override
    public Notification findNotificationByVisitId(long id) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Notification> cr = cb.createQuery(Notification.class);
        Root<Notification> root = cr.from(Notification.class);
        cr.select(root).where(cb.equal(root.get("visitId"), id));

        Query<Notification> query = getSession().createQuery(cr);

        return (Notification) query.uniqueResult();
    }*/
}
