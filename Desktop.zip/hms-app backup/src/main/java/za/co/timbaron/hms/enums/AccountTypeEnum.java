package za.co.timbaron.hms.enums;

import java.text.MessageFormat;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum AccountTypeEnum {

    TRIAL(1, "Trial"),
    PREMIUM(2, "Premium");

    private final long id;
    private final String type;

    AccountTypeEnum(long id, String type) {
        this.type = type;
        this.id = id;
    }

    public static AccountTypeEnum getById(long id) {
        for (AccountTypeEnum e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        log.warn(MessageFormat.format("Invalid Id for AccountTypeEnum: {0}", id));
        return null;
    }
    
     public static AccountTypeEnum getByType(String type) {
        for (AccountTypeEnum e : values()) {
            if (e.type.equals(type)) {
                return e;
            }
        }
        log.warn(MessageFormat.format("Invalid type for AccountTypeEnum: {0}", type));
        return null;
    }

}
