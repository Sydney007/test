package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum PaymentMethodEnum {
    CASH,
    MEDICAL_AID,
    WALLET;
}
