/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_VISIT_IMAGES")
public class VisitImage implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "IMAGEID", nullable = false)
    private long imageId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "IMAGEID", referencedColumnName = "ID", insertable = false, updatable = false)
    private UserImage image = new UserImage();

    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;
}
