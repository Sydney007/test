package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum MedicalAidProviderEnum {
    AECI,
    BONITAS,
    BANKMED,
    DISCOVERY,
    MEDIHELP,
    FEDHEALTH,
    SUREMED,
    LIBERTY;
}
