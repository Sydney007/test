package za.co.timbaron.hms.repository;

import java.util.Map;

/**
 *
 * @author Matimba
 */
public class DynamicQueries {

    public static String getMaxValue(Map<String, Object> params) {

        String tableName = (String) params.get("tableName");
        String column = (String) params.get("column");

        StringBuilder sql = new StringBuilder();

        sql.append("SELECT IFNULL(MAX(").append(column).append("), -1) FROM ").append(tableName).append(";");

        return sql.toString();
    }

}
