package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum RoomTypeEnum {
    A_AND_E,
    CASUALTY,
    CONSULTING_ROOM,
    DAY_ROOM,
    DISPENSARY,
    EMERGENCY_ROOM,
    ER,
    DELIVERY_ROOM,
    HIGH_DEPENDENCY_UNIT,
    ICU,
    INTENSIVE_CARE,
    MATERNITY_WARD,
    NURSERY,
    OPERATING_ROOM,
    OPERATING_THEATRE,
    PADDED_CELL,
    SURGERY,
    THEATRE,
    WARD;
}
