package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum ReferralTypeEnum {
    EXTERNAL,
    INTERNAL,
}
