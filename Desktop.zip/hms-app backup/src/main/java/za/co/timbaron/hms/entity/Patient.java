package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "HMS_PATIENT")
public class Patient extends UserDetails implements Serializable {

    @Column(name = "ACCOUNTNUMBER", nullable = false)
    private long accountNumber;

    @Column(name = "PATIENTID", nullable = false)

    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL)
    private Set<Visit> visits = new HashSet();
    
    @OneToMany(mappedBy = "patient", cascade = CascadeType.PERSIST)
    private Set<Notification> notifications = new HashSet();

}
