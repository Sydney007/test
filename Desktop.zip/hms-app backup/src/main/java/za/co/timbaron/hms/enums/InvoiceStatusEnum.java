package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum InvoiceStatusEnum {

    CANCELLED("Cancelled", "btn-warning", "#f47920"),
    OVERDUE("Overdue", "btn-danger", "#FF0000"),
    PAID("Paid", "btn-success", "#26B99A"),
    SENT("Sent", "btn-primary", "#425567");

    private final String status;
    private final String styleClass;
    private final String backgroundColor;

    InvoiceStatusEnum(String status, String styleClass, String backgroundColor) {
        this.status = status;
        this.styleClass = styleClass;
        this.backgroundColor = backgroundColor;
    }

    public static InvoiceStatusEnum getByStatus(String status) {
        for (InvoiceStatusEnum e : values()) {
            if (e.status.equalsIgnoreCase(status)) {
                return e;
            }
        }
        return null;
    }
}
