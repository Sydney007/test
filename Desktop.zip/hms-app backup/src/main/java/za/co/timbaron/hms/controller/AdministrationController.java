package za.co.timbaron.hms.controller;

import com.google.gson.Gson;
import io.swagger.annotations.Api;
import java.sql.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.entity.AppointmentDateRange;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.enums.AppointmentFrequentlyEnum;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.model.Response;
import za.co.timbaron.hms.service.EmployeeService;
import za.co.timbaron.hms.service.MyUserDetailsModel;
import za.co.timbaron.hms.service.PatientService;
import za.co.timbaron.hms.util.EmailUtil;
import za.co.timbaron.hms.util.EntityIdAndIDNumberBeanHelper;
import za.co.timbaron.hms.service.AdministrationService;
import za.co.timbaron.hms.service.HMSEntityService;
import za.co.timbaron.hms.util.Day;

@RestController
@Api(value = "Administration Util  management API")
@RequestMapping("/administration")
@Slf4j
public class AdministrationController {

    @Autowired
    private AdministrationService administrationService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private EmployeeService employeeService;
    
     @Autowired
    private HMSEntityService entityService;

    @Autowired
    private Gson gson;
    
    @Autowired
    private EntityIdAndIDNumberBeanHelper entityIdAndIDNumberBeanHelper;

    @Autowired
    private EmailUtil emailUtil;

    @RequestMapping(value = "/getAppointments", method = RequestMethod.GET)
    public @ResponseBody
    List<Appointment> getAppointments(@RequestParam String startDate, @RequestParam String endDate) {
        log.debug(" ");
        log.debug("AdministrationController.class -> getAppointments method: [Get All Appointments fromDate = " + startDate + " endDate = " + endDate + "]");

        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User loggedUser = ((MyUserDetailsModel) principal).getLoggedUser();

        List<Appointment> appointments = null;
        UserTypeEnum userType = loggedUser.getUserType();

        if (userType == UserTypeEnum.RECEPTIONIST || userType == UserTypeEnum.ENTITY) {
            appointments = administrationService.findAppointmentsByEntity(entityService.findById(entityIdAndIDNumberBeanHelper.getEntityId()), startDate, endDate);
        } else {
            appointments = administrationService.findUserAppointmentsById(loggedUser.getId(), startDate, endDate);
        }

        return appointments;
    }

    @RequestMapping(value = "/saveAppointment", method = RequestMethod.POST)
    public @ResponseBody
    Response saveAppointment(@RequestBody Appointment appointment) {

        log.debug("AdministrationController.class -> saveAppointment method: [Save patient appointment]");
        Response response = new Response();

        try {

            Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            User loggedUser = ((MyUserDetailsModel) principal).getLoggedUser();

            Patient patient = patientService.findByIdentityNumber(appointment.getPatientIdNo());
            Employee doctor = employeeService.findEmployeeById(appointment.getDoctor().getId());

            if (patient == null) {

                response.setFailed(true);
                response.setMessage("Patient not found.! Please Register patient </a>");
                response.setUrl("");

            } else {

                if (appointment.isNewEvent()) {
                    appointment.setEntity(entityService.findById(entityIdAndIDNumberBeanHelper.getEntityId()));
                    appointment.setCreatedBy(employeeService.findEmployeeById(entityIdAndIDNumberBeanHelper.getId()));
                    appointment.setUserType(loggedUser.getUserType());
                    appointment.setPatient(patient);
                    appointment.setVisitDate(new Date(new java.util.Date().getTime()));
                }

                appointment.setDoctor(null);
                appointment.setPatient(null);
                appointment.setStatus(null);
                appointment.setCreatedBy(null);

                if (appointment.getFrequently() == AppointmentFrequentlyEnum.WEEKLY) {
                    StringBuilder days = new StringBuilder();

                    for (Day day : appointment.getWeeklyDays()) {
                        days.append(day.getId()).append(",");
                    }

                    String weeklyDays = days.substring(0, days.length() - 1);

                    appointment.setByWeekDays(weeklyDays);
                }

                administrationService.save(appointment);

                if (appointment.getFrequently() == AppointmentFrequentlyEnum.MONTHLY && appointment.getInterval() >= 1) {

                    LocalDate date1 = new LocalDate(appointment.getStartDate());
                    LocalDate date2 = new LocalDate(appointment.getEndDate());

                    System.out.println(date1.toString("yyyy-MM-dd"));
                    System.out.println(date2.toString("yyyy-MM-dd"));

                    while (date1.isBefore(date2)) {
                        date1 = date1.plus(Period.months(Integer.parseInt("" + appointment.getInterval())));
                        if (date1.isBefore(date2)) {
                            Appointment appointmentObj = new Appointment();

                            BeanUtils.copyProperties(appointment, appointmentObj);

                            System.out.println(date1.toString("yyyy-MM-dd"));

                            appointmentObj.setId(0);
                            appointmentObj.setStartDate(date1.toString("yyyy-MM-dd"));
                            appointmentObj.setEndDate(date1.toString("yyyy-MM-dd"));
                            appointmentObj.setParentId(appointment.getId());
                            administrationService.save(appointmentObj);
                        }
                    }
                } else if (appointment.getFrequently() == AppointmentFrequentlyEnum.WEEKLY) {

                    LocalDate date1 = new LocalDate(appointment.getStartDate());
                    LocalDate date2 = new LocalDate(appointment.getEndDate());

                    while (date1.isBefore(date2)) {
                        LocalDate startDate = date1.dayOfMonth().withMinimumValue();
                        LocalDate endDate = date1.dayOfMonth().withMaximumValue().plusDays(1);
                        date1 = date1.plus(Period.months(1));

                        AppointmentDateRange appointmentDateRangeObj = new AppointmentDateRange();
                        appointmentDateRangeObj.setStart(startDate.toString());

                        if (endDate.isAfter(date2)) {
                            appointmentDateRangeObj.setEnd(date2.toString());
                        } else {
                            appointmentDateRangeObj.setEnd(endDate.toString());
                        }
                        
                        appointmentDateRangeObj.setAppointment(appointment);
                        administrationService.persistObject(appointmentDateRangeObj);
                    }
                }

                Employee createdBy = employeeService.findEmployeeById(appointment.getCreatedById());

                appointment.setDoctor(doctor);
                appointment.setPatient(patient);
                appointment.setCreatedBy(createdBy);

                emailUtil.send(appointment);
                response.setFailed(false);
                response.setMessage("Appointment saved successfully!");
                response.setObjectResultSet(appointment);
                response.setUrl("");
            }

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return response;
    }
}
