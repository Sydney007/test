/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.enums.conveter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import za.co.timbaron.hms.enums.AccountTypeEnum;

/**
 *
 * @author schauke
 */
@Converter
public class AccountTypeEnumConverter implements AttributeConverter<AccountTypeEnum, String> {

    @Override
    public String convertToDatabaseColumn(AccountTypeEnum value) {
        if (value == null) {
            return null;
        }

        return value.getType();
    }

    @Override
    public AccountTypeEnum convertToEntityAttribute(String value) {
        if (value == null) {
            return null;
        }

        return AccountTypeEnum.getByType(value);
    }

}
