/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.dao.impl;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.Notification;
import za.co.timbaron.hms.entity.PaymentTransaction;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.VisitReferral;
import za.co.timbaron.hms.util.UppercaseUtil;
import za.co.timbaron.hms.repository.VisitRepo;


public class VisitDaoImpl  {

    /*@Autowired
    private EmployeeRepo employeeDao;

    @Override
    public Visit findById(long id) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Visit> cr = cb.createQuery(Visit.class);
        Root<Visit> root = cr.from(Visit.class);
        cr.select(root).where(cb.equal(root.get("visitId"), id));

        Query<Visit> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    @Override
    public List<Visit> findAllVisits(long entityId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Visit> cr = cb.createQuery(Visit.class);
        Root<Visit> root = cr.from(Visit.class);
        cr.select(root).where(cb.equal(root.get("entityId"), entityId));

        Query<Visit> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List<Visit> findAllVisitsByDateRange(long entityId, String startDate, String endDate) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Visit> cr = cb.createQuery(Visit.class);
        Root<Visit> root = cr.from(Visit.class);

        Predicate[] predicates = new Predicate[2];
        predicates[0] = cb.equal(cb.upper(root.get("entityId")), entityId);
        predicates[1] = cb.between(root.get("DATE_FORMAT(visitDate, '%Y-%m-%d')"), startDate, endDate);

        cr.select(root).where(predicates).distinct(true);

        Query<Visit> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public void save(Visit visit) {
        persist(visit);
    }

    @Override
    public void remove(Visit visit) {
        delete(visit);
    }

    @Override
    public void persistRelatedObject(Object entity) {
        persistObject(entity);
    }

    @Override
    public List<VisitReferral> getVisitReferralDetails(long visitId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<VisitReferral> cr = cb.createQuery(VisitReferral.class);
        Root<VisitReferral> root = cr.from(VisitReferral.class);
        cr.select(root).where(cb.equal(root.get("visitId"), visitId));

        Query<VisitReferral> query = getSession().createQuery(cr);
        List<VisitReferral> referrals = query.list();

        for (VisitReferral visitReferral : referrals) {

            Employee byDoctor = employeeDao.getEmployeeById(visitReferral.getReferredByEmpId());
            Employee toDoctor = employeeDao.getEmployeeById(visitReferral.getReferredToEmpId());

            visitReferral.setReferredByDoctor(UppercaseUtil.uppercaseFirstLetter(byDoctor.getTitle().name()) + " " + byDoctor.getFullName() + " " + byDoctor.getLastName() + " (" + byDoctor.getEntity().getEntityName() + ")");
            visitReferral.setReferredToDoctor(toDoctor);
        }
        return referrals;
    }*/
}
