/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import za.co.timbaron.hms.entity.Address;
import za.co.timbaron.hms.entity.Bed;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.InvoicesStats;
import za.co.timbaron.hms.entity.ItemsServices;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.Room;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserRawPassword;
import za.co.timbaron.hms.enums.CategoryEnum;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;
import za.co.timbaron.hms.model.InvoiceResponse;
import za.co.timbaron.hms.model.Response;
import za.co.timbaron.hms.service.HMSEntityService;
import za.co.timbaron.hms.service.HMSUtilService;
import za.co.timbaron.hms.service.UserService;
import za.co.timbaron.hms.util.BedBean;
import za.co.timbaron.hms.util.DaysTimeDifferenceUtil;
import za.co.timbaron.hms.util.DocumentUtilAndUploader;
import za.co.timbaron.hms.util.EntityIdAndIDNumberBeanHelper;
import za.co.timbaron.hms.util.POICellValuesUtil;
import za.co.timbaron.hms.util.RegistrationBean;
import za.co.timbaron.hms.util.UserPrincipalHelper;

/**
 *
 * @author Matimba
 */
@RestController
@Api(value = "Entity management API")
@RequestMapping({"/entity"})
@Slf4j
public class HMSEntityController {

   /* @Autowired
    private HMSEntityService entityService;

    @Autowired
    private UserService userService;

    @Autowired
    private Gson gson;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private DocumentUtilAndUploader documentUtilAndUploader;

    @Autowired
    POICellValuesUtil poiCellValuesUtil;

    @Autowired
    private DaysTimeDifferenceUtil daysTimeDifferenceUtil;

    @Autowired
    private EntityIdAndIDNumberBeanHelper entityIdAndIDNumberBeanHelper;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private UserPrincipalHelper userprincipalHelper;

    @Autowired
    private HMSUtilService hmsUtilService;

    @RequestMapping(value = "/getEntitydetails", method = RequestMethod.GET)
    public @ResponseBody
    HMSEntity getEntitydetails() {

        Object userDetails = userprincipalHelper.getUserPrincipal();

        HMSEntity entity = null;

        if (userDetails instanceof HMSEntity) {
            entity = ((HMSEntity) userDetails);
        } else if (userDetails instanceof Employee) {
            Employee employee = ((Employee) userDetails);
            entity = employee.getEntity();
        }

        return entity;
    }

    @RequestMapping(value = "/isEntityDispenseMedicine", method = RequestMethod.GET)
    public @ResponseBody
    boolean isEntityDispenseMedicine() {
        checkAuthentication();
        return entityService.findById(entityIdAndIDNumberBeanHelper.getEntityId()).isEntityDispenseMedicine();
    }

    @RequestMapping(value = "/getDataFromDb", method = RequestMethod.POST)
    public @ResponseBody
    List getDataFromDb(@RequestParam String tableName, @RequestParam long roomId) {
        checkAuthentication();

        List results = null;
        long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

        if (tableName.equalsIgnoreCase("rooms")) {
            results = entityService.findEntityRooms(entityIdAndIDNumberBeanHelper.getEntityId());
        } else if (tableName.equalsIgnoreCase("beds")) {
            results = entityService.findRoomBedsByRoomId(roomId);
        } else if (tableName.equalsIgnoreCase("pharmacy") || tableName.equalsIgnoreCase("medicine")) {
            results = entityService.findAllMedicinesByEntityId(entityId);
        } else if (tableName.equalsIgnoreCase("suppliers")) {
            results = entityService.findAllSuppliersByEntityId(entityId);
        }

        return results;
    }

    @RequestMapping(value = "/saveRoom", method = RequestMethod.POST)
    public @ResponseBody
    Response saveRoom(@RequestBody Room room) {
        Response response = new Response();

        try {

            long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

            Room newRoom = room;
            newRoom.setEntityId(entityId);
            newRoom.setBeds(null);
            newRoom.setDepartment(null);
            newRoom.setRoomType(null);

            entityService.persistObject(newRoom);

            long roomId = newRoom.getId();

            response.setFailed(false);
            response.setMessage(roomId + "");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/removeBed", method = RequestMethod.POST)
    public @ResponseBody
    Response removeBedById(@RequestBody Bed bed) {
        Response response = new Response();

        try {
            hmsUtilService.delete("Bed", bed.getId());
            response.setFailed(false);
            response.setMessage("Bed removed successfully.");
        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/deleteDatabaseRecord", method = RequestMethod.POST)
    public @ResponseBody
    Response savedeleteDatabaseRecordRoom(@RequestBody Object object) {
        Response response = new Response();

        try {

            System.out.println(gson.toJson(object));
            entityService.persistObject(object);

            response.setFailed(false);
            response.setMessage("Record deleted successfully.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/saveBed", method = RequestMethod.POST)
    public @ResponseBody
    Response saveBed(@RequestBody BedBean bedBean) {
        Response response = new Response();

        try {

            long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

            for (Bed bed : bedBean.getBeds()) {
                bed.setRoomId(bedBean.getRoomId());
                bed.setEntityId(entityId);
                bed.setPatient(null);
                bed.setBedType(null);
                entityService.persistObject(bed);
            }

            response.setFailed(false);
            response.setMessage("Bed added successfully.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/saveOrUpdateItem", method = RequestMethod.POST)
    public @ResponseBody
    Response saveOrUpdateItem(@RequestBody ItemsServices itemBean) {
        Response response = new Response();

        try {

            long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

            itemBean.setDateAdded(new Date(new java.util.Date().getTime()));
            itemBean.setEntityId(entityId);

            entityService.persistObject(itemBean);

            response.setFailed(false);
            response.setMessage("Item Updated/Added successfully.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/getEntityInvoices", method = RequestMethod.GET)
    public @ResponseBody
    List<Invoice> getEntityInvoices(@RequestParam Date fromDate, @RequestParam Date endDate) throws ParseException {
        checkAuthentication();
        log.debug("HMSEntityController.class -> getEntityInvoices method: [fromDate : " + fromDate + "  endDate: " + endDate + "]");
        long entityId = entityIdAndIDNumberBeanHelper.getEntityId();
        return entityService.findInvoicesByEntityIdAndDateRange(entityId, fromDate, endDate);
    }

    @RequestMapping(value = "/getLatestInvoices", method = RequestMethod.GET)
    public @ResponseBody
    InvoiceResponse getLatestInvoices() throws ParseException {
        checkAuthentication();
        long entityId = entityIdAndIDNumberBeanHelper.getEntityId();
        InvoiceResponse response = getInvoices(InvoiceStatusEnum.SENT);

        //Get invoices again if more than 5 days old invoices exists
        if (response.isFetchAgain()) {
            List invoices = entityService.findInvoicesByEntityID(entityId, InvoiceStatusEnum.SENT);
            response.setInvoices(invoices);
        }

        return response;
    }

    @RequestMapping(value = "/getPaidInvoices", method = RequestMethod.GET)
    public @ResponseBody
    InvoiceResponse getPaidInvoices() throws ParseException {
        checkAuthentication();
        return getInvoices(InvoiceStatusEnum.PAID);
    }

    @RequestMapping(value = "/getOverdueInvoices", method = RequestMethod.GET)
    public @ResponseBody
    InvoiceResponse getOverdueInvoices() throws ParseException {
        checkAuthentication();
        return getInvoices(InvoiceStatusEnum.OVERDUE);
    }

    @RequestMapping(value = "/getInvoicesStats", method = RequestMethod.GET)
    public @ResponseBody
    List<InvoicesStats> getInvoicesStats() throws ParseException {
        checkAuthentication();
        long entityId = entityIdAndIDNumberBeanHelper.getEntityId();
        return entityService.findInvoiceStatsByEntityId(entityId);
    }

    @RequestMapping(value = "/saveMedicine", method = RequestMethod.POST)
    public @ResponseBody
    Response saveMedicine(@RequestBody Medicine medicine) throws ParseException {
        Response response = new Response();
        try {
            checkAuthentication();
            long entityId = entityIdAndIDNumberBeanHelper.getEntityId();
            medicine.setEntityId(entityId);
            Timestamp now = new Timestamp(new java.util.Date().getTime());
            medicine.setPurchaseDate(now);
            medicine.setSupplier(null);
            medicine.setCategory(null);
            entityService.persistObject(medicine);

            response.setFailed(false);
            response.setMessage("Medicine saved successfully.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
        }

        return response;
    }

    @RequestMapping(value = "/saveSupplier", method = RequestMethod.POST)
    public @ResponseBody
    Response saveSupplier(@RequestBody Supplier supplier) throws ParseException {
        Response response = new Response();
        try {
            checkAuthentication();
            long entityId = entityIdAndIDNumberBeanHelper.getEntityId();
            supplier.setEntityId(entityId);
            supplier.setSuburb(null);
            entityService.persistObject(supplier);

            response.setFailed(false);
            response.setMessage("Supplier saved successfully.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
        }

        return response;
    }

    
       // FileTypes
        //1 = Medicines
        //2 = Suppliers
     
    @RequestMapping(value = "/processExcel", method = RequestMethod.POST)
    public Response processExcel(@RequestParam("file") MultipartFile file, @RequestParam("fileType") int fileType) {
        Response response = new Response();
        try {

            Workbook workbook = new XSSFWorkbook(file.getInputStream());
            Sheet worksheet = workbook.getSheetAt(0);

            if (worksheet.getPhysicalNumberOfRows() <= 1000) {

                //Medicines
                if (fileType == 1) {
                    uploadMedicinesFromFile(worksheet);
                } else {
                    uploadSuppliersFromFile(worksheet);
                }

                workbook.close();

                response.setFailed(false);
                response.setMessage("File successfully uploaded.");

            } else {
                response.setFailed(true);
                response.setMessage("File is too large, only 1000 records can be processed at a time.");
            }

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
        }

        return response;
    }

    @RequestMapping(value = "/saveOrUpdate", method = RequestMethod.POST)
    public @ResponseBody
    Map saveOrUpdateEntity(MultipartHttpServletRequest request) {

        Map<String, Object> result = new HashMap<>();

        try {
            Timestamp now = new Timestamp(new java.util.Date().getTime());

            String entityBeanString = request.getParameter("entityDetails");
            HMSEntity entityDetails = objectMapper.readValue(entityBeanString, HMSEntity.class);

            MultipartFile profilePic = request.getFile("profilePic");

            if (profilePic != null) {
                entityDetails.setProfilePic(documentUtilAndUploader.uploadImage(profilePic, entityDetails.getRegistrationNumber(), "profilepic"));
            }

            MultipartFile logo = request.getFile("logo");
            if (logo != null) {
                entityDetails.setLogo(documentUtilAndUploader.uploadImage(logo, entityDetails.getRegistrationNumber(), "logo"));
            }

            entityService.save(entityDetails);

            result.put("message", "Profile updated successfully");
            result.put("errorOccurred", false);

        } catch (Exception e) {
            result.put("message", e.getMessage());
            result.put("errorOccurred", true);

            e.printStackTrace();
        }

        return result;
    }

    @RequestMapping(value = "/registerEntity", method = RequestMethod.POST)
    public @ResponseBody
    Response registerEntity(MultipartHttpServletRequest request) {
        checkAuthentication();
        Response response = new Response();

        try {

            String registrationFormString = request.getParameter("registrationForm");

            RegistrationBean registrationForm = objectMapper.readValue(registrationFormString, RegistrationBean.class);

            HMSEntity entity = entityService.findByRegistrationNumber(registrationForm.getEntity().getRegistrationNumber());
            boolean isEntityExist = entity != null ? true : false;

            if (!isEntityExist) {

                //@RequestBody 
                HMSEntity newEntity = registrationForm.getEntity();
                User newUser = registrationForm.getAccount();

                String registrationNumber = newEntity.getRegistrationNumber().replaceAll("/", "#");

                MultipartFile profilePic = request.getFile("profilePic");
                String folderName = registrationNumber.replaceAll("/", "");

                if (profilePic != null) {
                    registrationForm.getEntity().setProfilePic(documentUtilAndUploader.uploadImage(profilePic, folderName, "profilepic"));
                }

                MultipartFile logo = request.getFile("logo");

                if (logo != null) {
                    registrationForm.getEntity().setLogo(documentUtilAndUploader.uploadImage(logo, folderName, "logo"));
                }

                UserRawPassword userPassword = new UserRawPassword();
                userPassword.setPassword(newUser.getPassword());
                userPassword.setIdentityNumber(registrationNumber);

                String encodedPassword = passwordEncoder.encode(newUser.getPassword());
                newUser.setAccountActive(Boolean.TRUE);
                newUser.setEntityIsHuman(Boolean.FALSE);
                newUser.setPassword(encodedPassword);
                newUser.setIdentityNumber(registrationNumber);

                newEntity.setEntityType(newUser.getEntityType());
                newEntity.setAccountTypeId(newUser.getAccountTypeId());
                newEntity.setDateCreated(new Date(new java.util.Date().getTime()));
                newEntity.setRegistrationNumber(registrationNumber);

                Address address = new Address();
                address.setAddressLine1(newEntity.getAddressLine1());
                address.setAddressLine2(newEntity.getAddressLine2());
                address.setSuburbId(newEntity.getSuburbId());
                address.setUserIdNo(registrationNumber);
                address.setSuburb(null);

                newUser.setAddress(null);
                newUser.setEntityType(null);
                newUser.setPackageId(newEntity.getPackageId());

                newEntity.setEntityType(null);
                newEntity.setSuburb(null);

                userService.saveOrUpdate(newUser);
                entityService.save(newEntity);
                userService.persistObject(userPassword);
                userService.persistObject(address);

                response.setFailed(false);
                response.setMessage("Entity registered successfully.");

            } else {
                response.setFailed(false);
                response.setMessage("Entity exist please contact support for login details.");
            }

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/findAllItems", method = RequestMethod.GET)
    public @ResponseBody
    Response findAllItems() throws ParseException {
        Response response = new Response();
        try {
            checkAuthentication();

            long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

            response.setObjectResultSet(entityService.findAllItemsServicesByEntityId(entityId));

            response.setFailed(false);

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
        }

        return response;
    }

    @RequestMapping(value = "/findAllUsers", method = RequestMethod.GET)
    public @ResponseBody
    Response findAllUsers() throws ParseException {
        Response response = new Response();
        try {
            checkAuthentication();

            long entityId = entityIdAndIDNumberBeanHelper.getEntityId();
            List<Employee> employees = entityService.findAllUsersByEntityId(entityId);

            for (Employee emp : employees) {
                emp.getLogonDetails().setPassword("*****Encrypted******");
                emp.getLogonDetails().setUsername("*****Encrypted******");
                emp.getLogonDetails().setOriginalPasswordBean(null);
            }

            response.setObjectResultSet(employees);

            response.setFailed(false);

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
        }

        return response;
    }

    public void uploadMedicinesFromFile(Sheet worksheet) throws ParseException {

        int i = 1;
        long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

        //Reads the data in excel file until last row is encountered
        while (i <= worksheet.getLastRowNum()) {
            Row row = worksheet.getRow(i++);
            Medicine medicine = new Medicine();

            medicine.setEntityId(entityId);
            Timestamp now = new Timestamp(new java.util.Date().getTime());
            medicine.setPurchaseDate(now);
            medicine.setSupplier(null);
            medicine.setCategory(null);

            medicine.setSigName(poiCellValuesUtil.getCellValueAsString(row.getCell(0)));
            medicine.setSigDescription(poiCellValuesUtil.getCellValueAsString(row.getCell(1)));
            medicine.setStockInhand(Integer.parseInt(poiCellValuesUtil.getCellValueAsString(row.getCell(2))));

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date expiryDate = formatter.parse(poiCellValuesUtil.getCellValueAsString(row.getCell(3)));

            medicine.setExpiryDate(new Date(expiryDate.getTime()));
            medicine.setIsbnUpc(poiCellValuesUtil.getCellValueAsString(row.getCell(4)));
            medicine.setCostPrice(new BigDecimal(poiCellValuesUtil.getCellValueAsString(row.getCell(5))));
            medicine.setTaxAmount(new BigDecimal(poiCellValuesUtil.getCellValueAsString(row.getCell(6))));
            medicine.setTotalAmount(new BigDecimal(poiCellValuesUtil.getCellValueAsString(row.getCell(7))));
            medicine.setSellingPrice(new BigDecimal(poiCellValuesUtil.getCellValueAsString(row.getCell(8))));
            medicine.setSupplierId(Integer.parseInt(poiCellValuesUtil.getCellValueAsString(row.getCell(9))));
            medicine.setCategory(CategoryEnum.valueOf(poiCellValuesUtil.getCellValueAsString(row.getCell(10))));

            entityService.persistObject(medicine);
        }

    }

    public void uploadSuppliersFromFile(Sheet worksheet) throws ParseException {

        int i = 1;
        long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

        //Reads the data in excel file until last row is encountered
        while (i <= worksheet.getLastRowNum()) {
            Row row = worksheet.getRow(i++);
            Supplier supplier = new Supplier();

            supplier.setEntityId(entityId);
            supplier.setSuburb(null);

            supplier.setName(poiCellValuesUtil.getCellValueAsString(row.getCell(0)));
            supplier.setTelephone(poiCellValuesUtil.getCellValueAsString(row.getCell(1)));
            supplier.setAddressLine1(poiCellValuesUtil.getCellValueAsString(row.getCell(2)));
            supplier.setAddressLine2(poiCellValuesUtil.getCellValueAsString(row.getCell(3)));
            supplier.setSuburbId(Integer.parseInt(poiCellValuesUtil.getCellValueAsString(row.getCell(4))));

            entityService.persistObject(supplier);
        }

    }

    public InvoiceResponse getInvoices(InvoiceStatusEnum status) throws ParseException {
        InvoiceResponse response = new InvoiceResponse();
        long entityId = entityIdAndIDNumberBeanHelper.getEntityId();

        List<Invoice> invoices = entityService.findInvoicesByEntityID(entityId, status);
        double totalOutstandingBalance = 0.0;

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String today = formatter.format(new java.util.Date());

        for (Invoice invoice : invoices) {
            totalOutstandingBalance += invoice.getTotalBalanceDue().doubleValue();

            java.util.Date date2 = formatter.parse(today);

            Map results = daysTimeDifferenceUtil.computeDiff(invoice.getDateSent(), date2);

            long daysDifference = Long.valueOf(results.get(TimeUnit.DAYS).toString());
            invoice.setNumDays(daysDifference);

            //Move invoice to overdue status           
            if (daysDifference > 5 && status == status.SENT) {
                invoice.setInvoiceStatus(InvoiceStatusEnum.OVERDUE);
                response.setFetchAgain(true);
            }

            //Update invoice number of days
            entityService.persistObject(invoice);
        }

        response.setInvoices(invoices);
        response.setBalance(totalOutstandingBalance);

        return response;
    }

    private ModelAndView checkAuthentication() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();

        if (authentication == null) {
            return new ModelAndView(new RedirectView("logout"));
        }

        return null;
    }*/

}
