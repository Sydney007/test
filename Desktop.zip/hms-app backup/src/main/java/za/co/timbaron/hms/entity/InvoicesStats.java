/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 *
 * @author Matimba
 */
@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_INVOICE_STATS")
public class InvoicesStats implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "TOTALCANCELLED", unique = true, nullable = false)
    private long totalCancelled;

    @Column(name = "TOTALOVERDUE", unique = true, nullable = false)
    private long totalOverdue;

    @Column(name = "TOTALPAID", unique = true, nullable = false)
    private long totalPaid;

    @Column(name = "TOTALSENT", unique = true, nullable = false)
    private long totalSent;

    @Column(name = "TOTALUNPAID", unique = true, nullable = false)
    private long totalUnpaid;

    @Column(name = "YTDINCOME", unique = true, nullable = false)
    private BigDecimal ytdIncome;

    @Column(name = "AMOUNTBILLED", unique = true, nullable = false)
    private BigDecimal amountBilled;

    @Column(name = "ENTITYID", unique = true, nullable = false)
    private long entityId;
}
