package za.co.timbaron.hms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserRawPassword;

@Repository
@Transactional
public interface UserRawPasswordRepo extends JpaRepository<UserRawPassword, Long> {

    UserRawPassword findByUser(User user);

}
