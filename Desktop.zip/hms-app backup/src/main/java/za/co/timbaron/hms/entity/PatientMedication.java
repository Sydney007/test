package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_PATIENT_MEDICATION")
public class PatientMedication implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "DATEISSUED", unique = true, nullable = false)
    private Timestamp dateIssued;

    @Column(name = "MORNING", unique = true, nullable = false)
    private long morning;

    @Column(name = "NOON", unique = true, nullable = false)
    private long noon;

    @Column(name = "EVENING", unique = true, nullable = false)
    private long evening;

    @Column(name = "EMPLOYEEID", unique = true, nullable = false)
    private long employeeId;

    @Column(name = "PATIENTID", unique = true, nullable = false)
    private long patientId;

    @Column(name = "MEDICINEID", unique = true, nullable = false)
    private long medicineId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MEDICINEID", referencedColumnName = "ID", insertable = false, updatable = false)
    private Medicine medicine = new Medicine();

    @Transient
    private boolean newEntry;

    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;
}
