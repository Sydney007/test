package za.co.timbaron.hms.util;

import java.util.Date;

public class NumbersGenerator {
    
    private final Integer invoiceNumber = 00001; // first generated invoice number;
    private final Integer accountNo = 00001; // first generated account number;

    public String generateInvoiceNo(String currentInvoiceNo) {

        if (currentInvoiceNo != null) {
            int num = Integer.parseInt(currentInvoiceNo);
            return String.format("%05d", num + 1);
        } else {
            return String.format("%05d", invoiceNumber);
        }
    }

    public long generateAccountNo(long currentAccountNo) {

        if (0 == currentAccountNo) {
            return accountNo;
        } else {
            return currentAccountNo + 1;
        }
    }

    public String generatePrescriptionNo(String currentPrescriptionNo) {
        int pNumber = 0;
        String prescriptionNumber = "";

        if (currentPrescriptionNo != null) {
            int number = Integer.parseInt(currentPrescriptionNo.substring(1));
            pNumber = number + 1;
            prescriptionNumber = "P" + pNumber;
        } else {
            prescriptionNumber = "P" + accountNo;
        }

        return prescriptionNumber;
    }

    public String generatePaymentReference(long invoiceId) {

        Date d = new Date();
        String paymentRef = "PYMT" + String.format("%05d", invoiceId) + "_" + d.getTime();

        return paymentRef;
    }
}
