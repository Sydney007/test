/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Value;
import za.co.timbaron.hms.entity.UserImage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.PatientVisitsGroupedByEntity;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.VisitReferral;
import za.co.timbaron.hms.entity.VisitTreatment;
import za.co.timbaron.hms.service.EmployeeService;
import za.co.timbaron.hms.service.HMSEntityService;
import za.co.timbaron.hms.service.PatientService;

/**
 *
 * @author ABMC684
 */
public class DocumentUtilAndUploader {

    private static final Logger logger = LoggerFactory.getLogger(DocumentUtilAndUploader.class);

    private String userDir = System.getProperty("user.dir");

    @Value("${images.location}")
    private String serverLocation;

    @Value("${downloads.url}")
    private String downloadsLocation;

    @Autowired
    private DocumentUtil documentUtil;

    @Autowired
    private HMSEntityService entityService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private EntityIdAndIDNumberBeanHelper entityIdAndIDNumberBeanHelper;

    public String uploadImage(MultipartFile logo, String registrationNumber, String imageType) throws Exception {

        logger.debug("DocumentUtilAndUploader.class -> uploadImage method: [Uploading entity's " + imageType + "]");

        String imagesFolder = userDir + "/src/main/webapp/resources/images/";

        File imagesDirectory = new File(imagesFolder);

        // Check if the directory exists, if not create it.
        if (!imagesDirectory.exists()) {
            imagesDirectory.mkdirs();
        }

        String folderName = registrationNumber.replaceAll("/", "");

        String dir = imagesFolder + folderName;

        File file = new File(dir);
        file.mkdirs();

        String ext = ".jpg";

        String imagePath = serverLocation + folderName + "/" + imageType + ext;
        String fileName = imagesFolder + folderName + "/" + imageType + ext;

        InputStream initialStream = logo.getInputStream();
        byte[] buffer = new byte[initialStream.available()];
        initialStream.read(buffer);

        File targetFile = new File(fileName);
        OutputStream outStream = new FileOutputStream(targetFile);
        outStream.write(buffer);

        outStream.close();
        initialStream.close();

        logger.debug("Image uploaded successfully.");

        return imagePath;
    }

    public Map<String, UserImage> uploadPatientImages(List<MultipartFile> images, String patientIdno, long visitId) throws Exception {

        logger.debug("DocumentUtilAndUploader.class -> uploadPatientImages method: [Save Patient's Images]");

        String imagesFolder = userDir + "/src/main/webapp/resources/images/";

        File imagesDirectory = new File(imagesFolder);

        // Check if the directory exists, if not create it.
        if (!imagesDirectory.exists()) {
            imagesDirectory.mkdirs();
        }

        Map<String, UserImage> response = new HashMap();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String strDate = sdf.format(new java.util.Date());

        java.util.Date date = sdf.parse(strDate);

        Timestamp uploadDate = new Timestamp(date.getTime());

        String dir = imagesFolder + patientIdno + "/scans/visit_" + visitId;

        File file = new File(dir);
        file.mkdirs();

        for (MultipartFile image : images) {

            UserImage userImage = new UserImage();

            String imageName = image.getOriginalFilename().substring(0, image.getOriginalFilename().lastIndexOf('.'));

            String imagePath = serverLocation + patientIdno + "/scans/visit_" + visitId + "/" + image.getOriginalFilename();
            String fileName = imagesFolder + patientIdno + "/scans/visit_" + visitId + "/" + image.getOriginalFilename();
            userImage.setServer(serverLocation);

            InputStream initialStream = image.getInputStream();
            byte[] buffer = new byte[initialStream.available()];
            initialStream.read(buffer);

            File targetFile = new File(fileName);
            OutputStream outStream = new FileOutputStream(targetFile);
            outStream.write(buffer);

            userImage.setUploadDate(uploadDate);
            userImage.setImagePath(imagePath);
            userImage.setUserIdNo(patientIdno);
            userImage.setImageName(imageName);
            userImage.setImageData("");

            response.put(imageName, userImage);

            outStream.close();
            initialStream.close();
        }

        logger.debug("Images uploaded successfully.");

        return response;
    }

    public String generateVisitInvoiceDocument(Visit visit, Invoice invoice) {

        String downloadsFolder = userDir + "/src/main/webapp/resources/downloads/";

        File downloadsDirectory = new File(downloadsFolder);

        try {
            // Check if the directory exists, if not create it.
            if (!downloadsDirectory.exists()) {
                downloadsDirectory.mkdirs();
            }

            HMSEntity entity = entityService.findById(visit.getEntity().getId());
            Patient patient = patientService.findById(visit.getPatient().getId());

            Set<VisitTreatment> items = visit.getVisitTreatmentItems();

            invoice.setInvoiceItems(items);

            documentUtil.generateInvoice(invoice, entity, patient, downloadsFolder + "invoice_" + visit.getId() + ".pdf", visit);

            return downloadsLocation + "invoice_" + visit.getId() + ".pdf";

        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }

    public Map<String, String> generateSickNoteAndReferralLetterDocuments(Visit visit) {

        String downloadsFolder = userDir + "/src/main/webapp/resources/downloads/";

        Map<String, String> results = new HashMap();

        File downloadsDirectory = new File(downloadsFolder);

        try {
            // Check if the directory exists, if not create it.
            if (!downloadsDirectory.exists()) {
                downloadsDirectory.mkdirs();
            }

            HMSEntity entity = entityService.findById(visit.getEntity().getId());
            Patient patient = patientService.findById(visit.getPatient().getId());

            results.put("sickNoteValid", "false");
            results.put("referralLetterValid", "false");

            if (entity.getEntitySubNameGroup() == null) {
                entity.setEntitySubNameGroup(" ");
            }

            if (visit.getSickNoteBean() != null) {
                documentUtil.generateSickNote(entity, patient, downloadsFolder + "sickNote_" + visit.getId() + ".pdf", visit);
                results.put("sicknote", downloadsLocation + "sickNote_" + visit.getId() + ".pdf");
                results.put("sickNoteValid", "true");
            }

            if (visit.isReferralVisit()) {

                VisitReferral visitReferral = patientService.findVisitReferralByVisitId(visit.getId());
                visitReferral.setReferredToDoctor(employeeService.findEmployeeById(visitReferral.getReferredToEmpId()));
                visit.setReferralBean(visitReferral);

                documentUtil.generateReferralLetter(entity, patient, downloadsFolder + "referralLetter_" + visit.getId() + ".pdf", visit, visit.getReferralBean().getReason(),
                        visit.getReferralBean().getReferenceNumber());
                results.put("referralLetter", downloadsLocation + "referralLetter_" + visit.getId() + ".pdf");
                results.put("referralLetterValid", "true");
            }

            System.out.println("results = " + results);

        } catch (Exception e) {
            e.printStackTrace();
            results.put("error", e.getMessage());
        }

        return results;
    }

    public String generateMedicalHistoryDocument(List<PatientVisitsGroupedByEntity> visits, HMSEntity entity, Patient patient) {

        String downloadsFolder = userDir + "/src/main/webapp/resources/downloads/";

        File downloadsDirectory = new File(downloadsFolder);

        try {
            // Check if the directory exists, if not create it.
            if (!downloadsDirectory.exists()) {
                downloadsDirectory.mkdirs();
            }

            documentUtil.generateMedicalHistoryDoc(entity, patient, downloadsFolder + patient.getIdentityNumber() + "_medicalHistory.pdf", visits);

            return downloadsLocation + patient.getIdentityNumber() + "_medicalHistory.pdf";

        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }
}
