package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum RelationshipEnum {
    BROTHER,
    COUSIN,
    DAUGHTER,
    FATHER,
    MOTHER,
    GRAND_MOTHER,
    GRAND_FATHER,
    HUSBAND,
    WIFE,
    SISTER,
    SON;
}
