package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum CD4CountEnum {
    LESS_THAN_0_CD4_CELLS,
    LESS_THAN_00_CD4_CELLS,
    LESS_THAN_200_CD4_CELLS,
    FROM_200_TO_500_CD4_CELLS,
    ABOVE_500_CD4_CELLS;
}
