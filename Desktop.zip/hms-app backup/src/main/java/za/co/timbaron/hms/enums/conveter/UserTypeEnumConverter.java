package za.co.timbaron.hms.enums.conveter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import za.co.timbaron.hms.enums.UserTypeEnum;

@Converter
public class UserTypeEnumConverter implements AttributeConverter<UserTypeEnum, String> {

    @Override
    public String convertToDatabaseColumn(UserTypeEnum value) {
        if (value == null) {
            return null;
        }

        return value.getValue();
    }

    @Override
    public UserTypeEnum convertToEntityAttribute(String value) {
        if (value == null) {
            return null;
        }

        return UserTypeEnum.getByValue(value);
    }

}
