package za.co.timbaron.hms.enums.conveter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import za.co.timbaron.hms.enums.EntityTypeEnum;

@Converter
public class EntityTypeEnumConverter implements AttributeConverter<EntityTypeEnum, String> {

    @Override
    public String convertToDatabaseColumn(EntityTypeEnum value) {
        if (value == null) {
            return null;
        }

        return value.getName();
    }

    @Override
    public EntityTypeEnum convertToEntityAttribute(String value) {
        if (value == null) {
            return null;
        }

        return EntityTypeEnum.getByName(value);
    }
}
