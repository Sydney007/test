package za.co.timbaron.hms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import za.co.timbaron.hms.entity.User;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {

    User findById(long id);

    User findByUsername(String username);

    User findByIdentityNumber(String identityNumber);

}
