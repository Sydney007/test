/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import java.util.Collection;
import java.util.Vector;
import za.co.timbaron.hms.entity.VisitTreatment;

/**
 *
 * @author ABMC684
 */
public class ReportFactoryClass {

    public static Collection getInvoiceItems() {

        VisitTreatment treatment = new VisitTreatment();
        treatment.setId(1);
        treatment.setVisitDate(null);
        treatment.setEmployeeIdNo(null);
        treatment.setPatientIdNo(null);
        treatment.setTreatment(null);
        treatment.setDescription(null);
        //treatment.setVisit(1);
        treatment.setAmount(null);
        treatment.setTotalAmount(null);
        treatment.setQuantity(1);
        treatment.setInvoiceId(1);

        Vector items = new Vector();
        items.add(treatment);

        return items;

    }
}
