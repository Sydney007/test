package za.co.timbaron.hms.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.repository.AppointmentRepo;
import za.co.timbaron.hms.service.AdministrationService;

@Service("administrationService")
@Transactional
public class AdministrationServiceImpl implements AdministrationService {

    @Autowired
    private AppointmentRepo appointmentRepo;

    @Override
    public Appointment findById(long id) {
        return appointmentRepo.findById(id).get();
    }

    @Override
    public List<Appointment> findAppointmentsByEntity(HMSEntity entity, String startDate, String endDate) {
        return appointmentRepo.findAllByEntityAndDateRange(entity, startDate, endDate);
    }

    @Override
    public List<Appointment> findUserAppointmentsById(long userId, String startDate, String endDate) {
        return null;//appointmentRepo.findAllByUserAppointmentsByIdAndStartDateAndEndDate(userId, startDate, endDate);
    }

    @Override
    public void save(Appointment appointment) {
        appointmentRepo.save(appointment);
    }

    @Override
    public void delete(Appointment appointment) {
        appointmentRepo.delete(appointment);
    }

    @Override
    public void persistObject(Object entity) {
    }

}
