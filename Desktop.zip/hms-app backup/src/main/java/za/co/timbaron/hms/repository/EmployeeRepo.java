package za.co.timbaron.hms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.enums.UserTypeEnum;

@Repository
@Transactional
public interface EmployeeRepo extends JpaRepository<Employee, Long> {

    Employee findByEmployeeNo(String employeeNumber);

    Employee findByIdentityNumber(String identityNumber);

    @Query("Select e From Employee e where e.entity = :entity and userDetails.userType = :userType")
    List<Employee> findAllByEntityIdAndUserType(@Param("entity") HMSEntity entity, @Param("userType") UserTypeEnum userType);

    @Query("Select e From Employee e where e.entity = :entity and TIMESTAMPDIFF(MINUTE,LASTLOGIN,NOW()) > 30")
    List<Employee> findUsersAwayForMoreThan30Minutes(@Param("entity") HMSEntity entity);

    List<Employee> findAllByEntityId(long entityId);

}
