package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;
import za.co.timbaron.hms.enums.PaymentMethodEnum;
import za.co.timbaron.hms.enums.conveter.InvoiceStatusEnumConverter;

@Entity
@Getter
@Setter
@Table(name = "HMS_INVOICE")
public class Invoice implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "PATIENTIDNO", nullable = false)
    private String patientIdNo;

    @Column(name = "EMPLOYEEIDNO", nullable = false)
    private String employeeIdNo;

    @Column(name = "INVOICEDATE", nullable = false)
    private Timestamp invoiceDate;

    @Column(name = "DUEDATE", nullable = false)
    private Date dueDate;

    @Column(name = "DATESENT", nullable = false)
    private Timestamp dateSent;

    @Column(name = "DATEPAID", nullable = true)
    private Timestamp datePaid;

    @Column(name = "TAX", nullable = false)
    private BigDecimal tax;

    @Column(name = "CHARGEDAMOUNT", nullable = false)
    private BigDecimal chargedAmount;

    @Column(name = "TOTALBALANCEDUE", nullable = false)
    private BigDecimal totalBalanceDue;

    @Column(name = "BALANCEDUE", nullable = false)
    private BigDecimal balanceDue;

    @Column(name = "AMOUNTPAID", nullable = false)
    private BigDecimal amountPaid;

    @Column(name = "CONSULTATIONFEE", nullable = false)
    private BigDecimal consultationFee;

    @Column(name = "ENTITYID", nullable = false)
    private long entityId;

    @Column(name = "INVOICENO", nullable = false)
    private String invoiceNo;

    @Column(name = "NUMDAYS", nullable = false)
    private long numDays;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "INVOICEID", referencedColumnName = "ID")
    private Set<VisitTreatment> invoiceItems = new HashSet();

    @ManyToOne
    @JoinColumn(name = "VISITID", referencedColumnName = "ID")
    private Visit visit;

    /*@OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "EMPLOYEEIDNO", referencedColumnName = "IDENTITYNUMBER", insertable = false, updatable = false)
    private Employee doctor = new Employee();

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PATIENTIDNO", referencedColumnName = "IDENTITYNUMBER", insertable = false, updatable = false)
    private Patient patient = new Patient();

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ENTITYID", referencedColumnName = "ID", insertable = false, updatable = false)
    private HMSEntity entity = new HMSEntity();
     */
    @Convert(converter = InvoiceStatusEnumConverter.class)
    @Column(name = "STATUS", nullable = false)
    private InvoiceStatusEnum invoiceStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "PAYMENTMETHOD", nullable = false)
    private PaymentMethodEnum paymentMethod;

    @OneToMany(mappedBy = "invoice", cascade = CascadeType.ALL)
    private Set<WalletTransactions> invoiceTransactions = new HashSet();
}
