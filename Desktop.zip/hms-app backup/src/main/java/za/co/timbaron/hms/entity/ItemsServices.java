package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_ITEMS_SERVICES")
public class ItemsServices implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "ITEM")
    private String item;

    @Column(name = "SERVICE")
    private String service;

    @Column(name = "MEDICARE_COVERS")
    private boolean medicareCovers;

    @Column(name = "DATE_ADDED")
    private Date dateAdded;

    @Column(name = "ENTITYID")
    private long entityId;
}
