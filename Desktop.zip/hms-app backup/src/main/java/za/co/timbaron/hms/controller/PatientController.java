/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import za.co.timbaron.hms.entity.Address;
import za.co.timbaron.hms.entity.Appointment;
import za.co.timbaron.hms.model.Response;
import za.co.timbaron.hms.entity.EmergencyContact;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.Employer;
import za.co.timbaron.hms.entity.EntityPatient;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.MedicalAid;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.Note;
import za.co.timbaron.hms.entity.Notification;
import za.co.timbaron.hms.entity.PatientAllergy;
import za.co.timbaron.hms.entity.PatientDisclosure;
import za.co.timbaron.hms.entity.PatientMedicalProblem;
import za.co.timbaron.hms.entity.PatientMedication;
import za.co.timbaron.hms.entity.PatientImmunization;
import za.co.timbaron.hms.entity.PatientVisitsGroupedByEntity;
import za.co.timbaron.hms.entity.SickNote;
import za.co.timbaron.hms.util.SearchBean;
import za.co.timbaron.hms.entity.SocialHistory;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.entity.UserRawPassword;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.VisitImages;
import za.co.timbaron.hms.entity.VisitReferral;
import za.co.timbaron.hms.entity.VisitTreatment;
import za.co.timbaron.hms.entity.Vital;
import za.co.timbaron.hms.entity.PaymentTransaction;
import za.co.timbaron.hms.entity.Wallet;
import za.co.timbaron.hms.entity.WalletTransactions;
import za.co.timbaron.hms.enums.EntityTypeEnum;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;
import za.co.timbaron.hms.enums.PaymentMethodEnum;
import za.co.timbaron.hms.enums.TransactionTypeEnum;
import za.co.timbaron.hms.enums.UploadTypeEnum;
import za.co.timbaron.hms.enums.UserTypeEnum;
import za.co.timbaron.hms.service.EmployeeService;
import za.co.timbaron.hms.service.HMSUtilService;
import za.co.timbaron.hms.service.InvoiceService;
import za.co.timbaron.hms.service.PatientService;
import za.co.timbaron.hms.service.VisitService;
import za.co.timbaron.hms.util.EntityIdAndIDNumberBeanHelper;
import za.co.timbaron.hms.util.NumbersGenerator;
import za.co.timbaron.hms.service.HMSEntityService;
import za.co.timbaron.hms.service.UserService;
import za.co.timbaron.hms.util.ConsultationBean;
import za.co.timbaron.hms.util.DocumentUtilAndUploader;
import za.co.timbaron.hms.util.EntityHelperBean;
import za.co.timbaron.hms.util.PatientRegistrationBean;

/**
 *
 * @author Matimba
 */
@RestController
@Api(description = "Patient management API")
@RequestMapping({"/patient"})
public class PatientController {

    /*private static final Logger logger = LoggerFactory.getLogger(PatientController.class);

    @Autowired
    private Gson gson;

    @Autowired
    private PatientService patientService;

    @Autowired
    private VisitService visitService;

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private NumbersGenerator numbersGenerator;

    @Autowired
    private HMSUtilService hmsUtilService;

    @Autowired
    private HMSEntityService entityService;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private EntityHelperBean entityHelperBean;

    private String userDir = System.getProperty("user.dir");

    @Value("${images.location}")
    private String serverLocation;

    @Autowired
    private DocumentUtilAndUploader documentUtilAndUploader;

    @Autowired
    private EntityIdAndIDNumberBeanHelper entityIdAndIDNumberBeanHelper;

    @Autowired
    private ObjectMapper objectMapper;

    private Timestamp now = new Timestamp(new java.util.Date().getTime());

    @RequestMapping(value = "/findAll", method = RequestMethod.GET)
    public @ResponseBody
    List<Patient> patientsList() {
        checkAuthentication();
        return patientService.findAllByEntityId(entityIdAndIDNumberBeanHelper.getEntityId());
    }

    @RequestMapping(value = "/findPatientById/{id}", method = RequestMethod.GET)
    public @ResponseBody
    Patient getPatient(@PathVariable long id) {
        checkAuthentication();
        return patientService.findById(id);
    }

    @RequestMapping(value = "/findPatientByIdNo", method = RequestMethod.GET)
    public @ResponseBody
    Patient getPatientByIdNo(@RequestParam String identityNo) {
        checkAuthentication();
        return patientService.findByIdentityNumber(identityNo);
    }

    @RequestMapping(value = "/findPatientVisitById", method = RequestMethod.GET)
    public @ResponseBody
    Visit getPatientVisitById(@RequestParam long visitId) {
        checkAuthentication();

        logger.debug("PatientController.class -> getPatientVisitById method: [find patient by ID number]");
        logger.debug("PatientController.class -> Visit Id : [" + visitId + "]");

        return visitService.findById(visitId);
    }

    @RequestMapping(value = "/searchPatient", method = RequestMethod.GET)
    public @ResponseBody
    Map<String, Object> searchPatient(@RequestParam String idNumber, @RequestParam String medicalAid) {
        checkAuthentication();
        logger.debug("PatientController.class -> searchPatient method: [find patient by ID number/ Medical Aid]");
        logger.debug("PatientController.class -> searchBean method: [idNumber = " + idNumber + "]");

        Patient patient = patientService.findByIdentityNumber(idNumber);

        Map<String, Object> results = new HashMap();
        results.put("patientDetails", patient);
        results.put("entityAddress", entityHelperBean.getAddress());
        results.put("entityName", entityHelperBean.getEntityName());
        results.put("entityTelephone", entityHelperBean.getEntityTelephone());
        results.put("entityEmail", entityHelperBean.getEntityEmail());
        results.put("consultationFee", entityHelperBean.getPracticeConsultationFee());
        results.put("patientInvoices", patientService.findPatientInvoicesByIdNo(idNumber));

        return results;
    }

    @RequestMapping(value = "/saveVital", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    Response saveVital(@RequestBody Vital vital) {
        checkAuthentication();
        Response response = new Response();

        try {
            vital.setDateRecorded(now);
            vital.setDiagnosesStatus(null);
            vital.setEmployeeIdNo(entityIdAndIDNumberBeanHelper.getIdNumber());
            patientService.persistObject(vital);
            Visit visits = visitService.findById(vital.getVisitId());

            response.setFailed(false);
            response.setMessage("Vital saved successfully!.");
            response.setListResultSet(visits.getVitals());

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/searchPatientVisits", method = RequestMethod.POST)
    public @ResponseBody
    String getPatientVisits(@RequestBody SearchBean searchBean) {
        checkAuthentication();

        String result = "";
        try {
            if (searchBean.isDateRange()) {

                List<Visit> patientVisits = patientService.findPatientVisitsByIdNoAndDateRange(searchBean.getIdNumber(), searchBean.getStartDate(), searchBean.getEndDate());

                for (Visit visit : patientVisits) {
                    Employee emp = new Employee();
                    if (visit.getDoctor() != null) {
                        emp.setFullName(visit.getDoctor().getFullName());
                        emp.setLastName(visit.getDoctor().getLastName());
                        emp.setTitle(visit.getDoctor().getTitle());
                    } else {
                        Employee employee = employeeService.findEmployeeByIdentityNumber(visit.getEmployeeIdNo());
                        emp.setFullName(employee.getFullName());
                        emp.setLastName(employee.getLastName());
                        emp.setTitle(employee.getTitle());
                    }
                    visit.setDoctor(emp);
                }

                result = gson.toJson(patientVisits);

            } else {
                List<PatientVisitsGroupedByEntity> visits = getPatientVisitsGroupedByEntity(searchBean);
                result = gson.toJson(visits);
            }
        } catch (Exception e) {
            result = e.getMessage();
            e.printStackTrace();
        }

        return result;
    }

    public List<PatientVisitsGroupedByEntity> getPatientVisitsGroupedByEntity(SearchBean searchBean) {

        List<PatientVisitsGroupedByEntity> visits = new ArrayList();

        List<Long> entityIds = patientService.findAllPatientVisitsEntitiesByIdNo(searchBean.getIdNumber());

        int i = 0;

        for (Long id : entityIds) {

            PatientVisitsGroupedByEntity patientVisit = new PatientVisitsGroupedByEntity();
            patientVisit.setEntity(entityService.findById(id));

            if (i == 0) {
                patientVisit.setExpanded(true);
                patientVisit.setActiveCollapse("in");
            }

            List<Visit> patientVisits = patientService.findPatientVisitsByIdNoAndEntityId(searchBean.getIdNumber(), id);

            for (Visit visit : patientVisits) {
                Employee emp = new Employee();
                if (visit.getDoctor() != null) {
                    emp.setFullName(visit.getDoctor().getFullName());
                    emp.setLastName(visit.getDoctor().getLastName());
                    emp.setTitle(visit.getDoctor().getTitle());
                } else {
                    Employee employee = employeeService.findEmployeeByIdentityNumber(visit.getEmployeeIdNo());
                    emp.setFullName(employee.getFullName());
                    emp.setLastName(employee.getLastName());
                    emp.setTitle(employee.getTitle());
                }

                for (PatientDisclosure disclosure : visit.getDisclosures()) {
                    Employee doctor = new Employee();
                    if (disclosure.getDoctor() != null) {
                        doctor.setFullName(visit.getDoctor().getFullName());
                        doctor.setLastName(visit.getDoctor().getLastName());
                        doctor.setTitle(visit.getDoctor().getTitle());
                    } else {
                        Employee employee = employeeService.findEmployeeByIdentityNumber(visit.getEmployeeIdNo());
                        doctor.setFullName(employee.getFullName());
                        doctor.setLastName(employee.getLastName());
                        doctor.setTitle(employee.getTitle());
                    }

                    disclosure.setDoctor(doctor);
                }

                visit.setDoctor(emp);
            }

            patientVisit.setVisits(patientVisits);
            visits.add(patientVisit);

            i++;
        }

        return visits;
    }

    @RequestMapping(value = "/getPatientAppointments/{patientId}", method = RequestMethod.GET)
    public @ResponseBody
    List<Appointment> getPatientAppointments(@PathVariable long patientId) {
        checkAuthentication();
        List<Appointment> results = null;
        try {
            Patient patient = patientService.findById(patientId);
            results = patientService.getPatientAppointments(patient);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return results;
    }

    @RequestMapping(value = "/getPatientReferrals", method = RequestMethod.POST)
    public @ResponseBody
    List<Visit> getPatientReferrals(@RequestParam String identityNumber) {
        checkAuthentication();
        List<Visit> referralVisits = null;
        try {
            referralVisits = patientService.findPatientReferralVisitsByIdNo(identityNumber);
            for (Visit visit : referralVisits) {
                Employee doctor = employeeService.findEmployeeByIdentityNumber(visit.getEmployeeIdNo());
                visit.setDoctor(doctor);
                visit.setEntity(doctor.getEntity());
                visit.setReferrals(visitService.getVisitReferralDetails(visit.getVisitId()));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return referralVisits;
    }

    @RequestMapping(value = "/getPatientTransactions/{idNo}", method = RequestMethod.GET)
    public @ResponseBody
    List<PaymentTransaction> getPatientTransactions(@PathVariable String idNo) {
        checkAuthentication();
        return patientService.findPatientWalletTransactionsByIdNo(idNo);
    }

    @RequestMapping(value = "/savePatient", method = RequestMethod.POST)
    public @ResponseBody
    Response savePatient(MultipartHttpServletRequest request) {
        checkAuthentication();
        logger.debug("PatientController.class -> savePatient method: [Save Patient]");
        Response response = new Response();

        try {

            MultipartFile logo = request.getFile("logo");
            String visitBeanString = request.getParameter("patientRegistrationBean");

            PatientRegistrationBean patientRegistrationBean = objectMapper.readValue(visitBeanString, PatientRegistrationBean.class);

            Patient patient = patientRegistrationBean.getPatient();

            String encodedPassword = passwordEncoder.encode(patient.getIdentityNumber());
            long acc = Long.parseLong(hmsUtilService.getMaxValue("Patient", "accountNumber"));
            String accountNo = "" + numbersGenerator.generateAccountNo(acc);

            User lookUpUser = userService.findByIdNumber(patient.getIdentityNumber());
            UserRawPassword lookUpRawUserpassword = userService.findPasswordByIdNumber(patient.getIdentityNumber());

            User newUser = new User();
            UserRawPassword userPassword = new UserRawPassword();

            if (lookUpUser != null) {
                BeanUtils.copyProperties(lookUpUser, newUser);
                BeanUtils.copyProperties(lookUpRawUserpassword, userPassword);
            } else {
                newUser.setAccountActive(Boolean.TRUE);
                newUser.setEntityIsHuman(Boolean.TRUE);
                newUser.setPassword(encodedPassword);
                newUser.setIdentityNumber(patient.getIdentityNumber());
                newUser.setUsername(patient.getIdentityNumber());
                newUser.setAccountTypeId(2); // set account type to premium account
                newUser.setEntityType(EntityTypeEnum.PERSON); //set entity type to person
                newUser.setUserType(UserTypeEnum.PATIENT); // set user type to patient           
                newUser.setPackageId(4); // set patient package
                newUser.setAddress(null);
                newUser.setEntityType(null);
                userPassword.setPassword(patient.getIdentityNumber());

                userPassword.setPassword(patient.getIdentityNumber());
                userPassword.setIdentityNumber(patient.getIdentityNumber());
            }

            patient.setDateModified(now);

            if (patient.getId() == 0) {
                patient.setAccountNumber(accountNo);
            }

            patient.setUserType(UserTypeEnum.PATIENT); // set user type to patient   

            //Patient Address
            Address patientAddress = patientRegistrationBean.getAddress();
            patientAddress.setSuburb(null);
            patient.setAddress(patientAddress);

            //Emergency Contact
            EmergencyContact patientEmergencyContact = patientRegistrationBean.getEmergencyContact();
            patientEmergencyContact.setRelationship(null);
            patientEmergencyContact.setTitle(null);
            patient.setEmergencyContact(patientEmergencyContact);

            patient.setCountry(null);
            patient.setTitle(null);
            patient.setRace(null);
            patient.setGender(null);
            patient.setLanguage(null);
            patient.setMaritalStatus(null);

            EntityPatient entityPatient = patientService.findEntityPatientByIdNo(patient.getIdentityNumber());

            if (entityPatient == null) {
                entityPatient = new EntityPatient();
                entityPatient.setPatientIdNo(patient.getIdentityNumber());
                entityPatient.setEntityId(entityIdAndIDNumberBeanHelper.getEntityId());
            }

            Wallet wallet = null;
            if (patientRegistrationBean.getWallet() != null) {
                wallet = patientRegistrationBean.getWallet();
            } else {
                wallet = new Wallet();
                wallet.setBalance(BigDecimal.ZERO);
                wallet.setPatientIdNo(patient.getIdentityNumber());
            }

            UserImage image = hmsUtilService.findProfilePicByIdNo(patient.getIdentityNumber());
            System.out.println("logo " + logo);
            System.out.println("image " + image);

            if (image != null) {
                image.setUploadDate(now);
                image.setImageName("profilepic.jpg");
            } else {
                image = new UserImage();
                image.setUserIdNo(patient.getIdentityNumber());
                image.setUploadDate(now);
                image.setUploadType(UploadTypeEnum.LOGO);
                image.setImageSize("0");
                image.setImageName("profilepic.jpg");
                image.setServer(serverLocation);
            }

            if (logo != null) {
                String photo = documentUtilAndUploader.uploadImage(logo, patient.getIdentityNumber(), "profilepic");
                patient.setPhoto(photo);
            }

            userService.saveOrUpdate(newUser);
            userService.persistObject(userPassword);
            patientService.save(patient);
            patientService.persistObject(wallet);
            userService.persistObject(entityPatient);

            image.setImageData("");
            image.setImagePath(patient.getPhoto());
            userService.persistObject(image);

            MedicalAid lookUpPatientMedicalAid = patientService.findPatientMedicalAidByIdNo(patient.getIdentityNumber());
            long patientMedicalAidId = lookUpPatientMedicalAid != null ? lookUpPatientMedicalAid.getId() : 0;

            MedicalAid patientMedicalAid = patientRegistrationBean.getMedicalAid();

            Employer lookUpPatientEmployer = patientService.findPatientEmployerByIdNo(patient.getIdentityNumber());
            long patientEmployerId = lookUpPatientEmployer != null ? lookUpPatientEmployer.getId() : 0;

            Employer patientEmployer = patientRegistrationBean.getEmployer();

            if (patientEmployer != null) {
                patientEmployer.setId(patientEmployerId);
                patientEmployer.setUserIdNo(patient.getIdentityNumber());
                patientService.persistObject(patientEmployer);
            }

            if (patientMedicalAid != null) {
                patientMedicalAid.setId(patientMedicalAidId);
                patientMedicalAid.setEffectiveDate(new Date(new java.util.Date().getTime()));
                patientMedicalAid.setBalance(BigDecimal.ZERO);
                patientMedicalAid.setSavingsBalance(BigDecimal.ZERO);
                patientMedicalAid.setIdentityNumber(patient.getIdentityNumber());
                patientMedicalAid.setProvider(null);
                patientService.persistObject(patientMedicalAid);
            }

            response.setFailed(false);
            response.setMessage("Patient saved successfully!.");
            response.setUrl("");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return response;
    }

    @RequestMapping(value = "/savePatientInvoiceAndCreateVisit", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    Response savePatientInvoiceAndCreateVisit(@RequestBody ConsultationBean consultationBean) {
        checkAuthentication();
        Response response = new Response();

        try {

            Visit visit = createVisitObj(consultationBean.getVisit());
            visit.setDiagnosesStatusId(1);
            visit.setEntityId(entityIdAndIDNumberBeanHelper.getEntityId());
            visit.setEmployeeIdNo(entityIdAndIDNumberBeanHelper.getIdNumber());
            visit.setVisitConsentFlag(true);
            visit.setCdCountId(1);
            visit.setVisitDate(now);
            visit.setReferralVisit(false);
            visit.setSickNoteRequired(Boolean.FALSE);
            visitService.save(visit);

            long visitId = visit.getVisitId();
            String invoiceNo = numbersGenerator.generateInvoiceNo(hmsUtilService.getMaxValue("Invoice", "invoiceNo"));
            Invoice invoice = consultationBean.getInvoice();

            Set<VisitTreatment> treatments = invoice.getInvoiceItems();
            invoice.setVisitId(visitId);
            invoice.setInvoiceNo(invoiceNo);
            invoice.setEntityId(entityIdAndIDNumberBeanHelper.getEntityId());
            invoice.setPatientIdNo(visit.getPatientIdNo());
            invoice.setEmployeeIdNo(visit.getEmployeeIdNo());
            invoice.setInvoiceDate(visit.getVisitDate());
            invoice.setDateSent(visit.getVisitDate());
            invoice.setPaymentMethod(PaymentMethodEnum.CASH);
            // invoice.setInvoiceStatus(null);
            invoice.setInvoiceItems(null);
            invoice.setDoctor(null);
            invoice.setPatient(null);
            invoice.setEntity(null);
            invoiceService.save(invoice);

            for (VisitTreatment treatment : treatments) {
                treatment.setInvoiceId(invoice.getId());
                treatment.setVisit(visit);
                treatment.setVisitDate(visit.getVisitDate());
                treatment.setEmployeeIdNo(visit.getEmployeeIdNo());
                treatment.setPatientIdNo(visit.getPatientIdNo());
                visitService.persistRelatedObject(treatment);
            }

            PaymentTransaction paymentTransaction = new PaymentTransaction();
            paymentTransaction.setAmount(invoice.getTotalBalanceDue());
            paymentTransaction.setReference(numbersGenerator.generatePaymentReference(invoice.getId())); //Generate a unique reference number
            paymentTransaction.setTransactionDate(visit.getVisitDate());
            paymentTransaction.setPatientIdNo(visit.getPatientIdNo());
            paymentTransaction.setTransactionType(TransactionTypeEnum.PAYMENT);
            paymentTransaction.setPaymemtMethod(invoice.getPaymentMethod());
            paymentTransaction.setEntityId(visit.getEntityId());
            paymentTransaction.setInvoiceId(invoice.getId());
            paymentTransaction.setEntity(null);
            paymentTransaction.setTransactionType(null);
            visitService.persistRelatedObject(paymentTransaction);

            if (invoice.getPaymentMethod() == PaymentMethodEnum.WALLET) {
                Wallet wallet = consultationBean.getWallet();
                WalletTransactions walletTransaction = new WalletTransactions();
                double balance = wallet.getBalance().doubleValue() - invoice.getTotalBalanceDue().doubleValue();//current wallet balance - invoice balance

                walletTransaction.setCurrentBalance(BigDecimal.valueOf(balance));
                walletTransaction.setAmount(invoice.getTotalBalanceDue());
                walletTransaction.setPatientIdNo(visit.getPatientIdNo());
                walletTransaction.setInvoiceId(invoice.getId());
                walletTransaction.setPreviousBalance(wallet.getBalance());//Wallet previous balance
                walletTransaction.setTransactionType(TransactionTypeEnum.PAYMENT);
                walletTransaction.setWalletId(wallet.getId());
                walletTransaction.setTransactionDate(visit.getVisitDate());

                wallet.setBalance(BigDecimal.valueOf(balance));
                walletTransaction.setInvoice(null);
                walletTransaction.setTransactionType(null);

                visitService.persistRelatedObject(walletTransaction);
                visitService.persistRelatedObject(wallet);
            }

            response.setFailed(false);
            response.setMessage("Payment made successfully and Visit created successfully.");
            response.setObjectResultSet(visit);

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/savePatientVisit", method = RequestMethod.POST)
    public @ResponseBody
    Response savePatientVisit(MultipartHttpServletRequest request) {
        checkAuthentication();
        Response response = new Response();
        try {
            logger.debug("Save Patient Visit");
            String visitBeanString = request.getParameter("visitBean");

            Visit visit = objectMapper.readValue(visitBeanString, Visit.class);
            visit.setVisitDate(new Timestamp(new java.util.Date().getTime()));

            List<MultipartFile> images = new ArrayList();

            for (int i = 0; i < 5; i++) {

                MultipartFile file = request.getFile("file_" + i);
                if (file != null) {
                    images.add(file);
                }
            }

            visit.setEmployeeIdNo(entityIdAndIDNumberBeanHelper.getIdNumber());
            visit.setEntityId(entityIdAndIDNumberBeanHelper.getEntityId());

            Visit visitObj = createVisitObj(visit);

            visitService.save(visitObj);

            long visitId = visitObj.getVisitId();

            saveVisitDetails(visitId, visit, images);

            visit.setDoctor(employeeService.findEmployeeByIdentityNumber(visit.getEmployeeIdNo()));

            Map sickNoteReferalLetterUrl = documentUtilAndUploader.generateSickNoteAndReferralLetterDocuments(visit);

            Notification notification = employeeService.findNotificationByVisitId(visit.getVisitId()).get(0);
            hmsUtilService.delete("Notification", notification.getId());

            response.setFailed(false);
            response.setMessage("Visit saved successfully!");
            response.setUrls(sickNoteReferalLetterUrl);

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return response;
    }

    @RequestMapping(value = "/savePatientReferral", method = RequestMethod.POST)
    public Response savePatientReferral(MultipartHttpServletRequest request) throws Exception {
        Response response = new Response();

        try {

            logger.debug("PatientController.class -> savePatientReferral method: [Saving Patient Referral]");

            String visitBeanString = request.getParameter("visitBean");

            Visit visit = objectMapper.readValue(visitBeanString, Visit.class);

            List<MultipartFile> images = new ArrayList();

            for (int i = 0; i < 5; i++) {

                MultipartFile file = request.getFile("file_" + i);
                if (file != null) {
                    images.add(file);
                }
            }

            saveVisitDetails(visit.getVisitId(), visit, images);

            response.setFailed(false);
            response.setMessage("Visit / Referral successfully updated.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            logger.debug("savePatientReferral Method:", e);
            e.printStackTrace();
        }
        return response;
    }

    @RequestMapping(value = "/updateInvoice", method = RequestMethod.GET)
    public @ResponseBody
    Response updateInvoice(@RequestBody Invoice invoice) {
        checkAuthentication();

        Response response = new Response();

        try {

            logger.debug("PatientController.class -> updateInvoice method: [Updating Patient Invoice]");
            invoice.setInvoiceStatus(InvoiceStatusEnum.PAID);
            patientService.persistObject(invoice);

            response.setFailed(false);
            response.setMessage("Invoice updated successfully.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            logger.debug("PatientController.class -> updateInvoice Method:", e);
            e.printStackTrace();
        }

        return response;
    }

    @RequestMapping(value = "/generateMedicalHistory", method = RequestMethod.GET)
    public @ResponseBody
    Response generateMedicalHistory(@RequestParam String idNumber) {
        checkAuthentication();

        Response response = new Response();

        try {

            logger.debug("PatientController.class -> generateMedicalHistory method: [Generate Medical History]");
            SearchBean searchBean = new SearchBean();
            searchBean.setIdNumber(idNumber);

            List<PatientVisitsGroupedByEntity> visits = getPatientVisitsGroupedByEntity(searchBean);

            HMSEntity entity = entityService.findById(entityIdAndIDNumberBeanHelper.getEntityId());
            Patient patient = patientService.findByIdentityNumber(idNumber);

            String medicalHistoryUrl = documentUtilAndUploader.generateMedicalHistoryDocument(visits, entity, patient);

            response.setFailed(false);
            response.setUrl(medicalHistoryUrl);
            response.setMessage("Medical history generated successfully.");

        } catch (Exception e) {
            response.setFailed(true);
            response.setMessage(e.getMessage());
            logger.debug("PatientController.class -> generateMedicalHistory Method:", e);
            e.printStackTrace();
        }

        return response;
    }

    private ModelAndView checkAuthentication() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();

        if (authentication == null) {
            return new ModelAndView(new RedirectView("logout"));
        }

        return null;
    }

    private Visit createVisitObj(Visit visit) {

        Visit visitObj = new Visit();

        BeanUtils.copyProperties(visit, visitObj);
        visitObj.setDiagnosesStatus(null);
        visitObj.setCd4Count(null);
        visitObj.setAllergies(null);
        visitObj.setDisclosures(null);
        visitObj.setNotes(null);
        visitObj.setVaccines(null);
        visitObj.setVisitTreatmentItems(null);
        visitObj.setInvoices(null);
        visitObj.setDoctor(null);
        visitObj.setSocialHistoryList(null);
        visitObj.setVitals(null);
        visitObj.setMedicalProblems(null);
        visitObj.setMedications(null);
        visitObj.setScans(null);
        visitObj.setSickNoteBean(null);

        return visitObj;
    }

    private void saveVisitDetails(long visitId, Visit visit, List<MultipartFile> images) throws Exception {

        for (SocialHistory socialHis : visit.getSocialHistoryList()) {
            socialHis.setVisitId(visitId);
            socialHis.setEmployeeIdNo(visit.getEmployeeIdNo());
            socialHis.setPatientIdNo(visit.getPatientIdNo());
            socialHis.setVisitDate(visit.getVisitDate());
            visitService.persistRelatedObject(socialHis);
        }

        long referralId = 0;

        if (visit.isReferralVisit()) {
            VisitReferral referralBean = visit.getReferralBean();
            referralBean.setVisitId(visitId);
            referralBean.setReferredByEmpId(entityIdAndIDNumberBeanHelper.getId());
            referralBean.setReferredByEntityId(entityIdAndIDNumberBeanHelper.getEntityId());
            referralBean.setPatientIdNo(visit.getPatientIdNo());
            visitService.persistRelatedObject(referralBean);
            referralId = referralBean.getReferralId();
        }

        if (visit.getSickNoteBean() != null) {
            SickNote sickNote = visit.getSickNoteBean();
            sickNote.setPatientIdNo(visit.getPatientIdNo());
            sickNote.setVisit(visit);
            sickNote.setVisitDate(visit.getVisitDate());
            visitService.persistRelatedObject(sickNote);
        }

        for (Vital vital : visit.getVitals()) {
            vital.setVisitId(visitId);
            vital.setDateRecorded(visit.getVisitDate());
            vital.setPatientIdNo(visit.getPatientIdNo());
            vital.setEmployeeIdNo(visit.getEmployeeIdNo());
            vital.setDiagnosesStatus(null);
            visitService.persistRelatedObject(vital);
        }

        for (PatientAllergy patientAllergy : visit.getAllergies()) {

            if (patientAllergy.isNewEntry()) {
                Allergy allergy = patientAllergy.getAllergy();
                visitService.persistRelatedObject(allergy);
                patientAllergy.setAllergyId(allergy.getAllergyId());
            }

            patientAllergy.setEmployeeIdNo(visit.getEmployeeIdNo());
            patientAllergy.setPatientIdNo(visit.getPatientIdNo());
            patientAllergy.setVisitId(visitId);
            patientAllergy.setPatientIdNo(visit.getPatientIdNo());
            patientAllergy.setEmployeeIdNo(visit.getEmployeeIdNo());
            patientAllergy.setAllergy(null);
            visitService.persistRelatedObject(patientAllergy);
        }

        for (PatientMedicalProblem problem : visit.getMedicalProblems()) {

            if (problem.isNewEntry()) {
                MedicalProblem medProblem = problem.getProblemObj();
                visitService.persistRelatedObject(medProblem);
                problem.setMedicalProblemId(medProblem.getId());
            }

            problem.setEmployeeIdNo(visit.getEmployeeIdNo());
            problem.setPatientIdNo(visit.getPatientIdNo());
            problem.setVisitId(visitId);
            problem.setDiagnoseStatus(null);
            problem.setProblemObj(null);
            visitService.persistRelatedObject(problem);
        }

        for (PatientMedication medication : visit.getMedications()) {

            if (medication.isNewEntry()) {
                Medicine medicine = medication.getMedicine();
                medicine.setStockInhand(0);
                medicine.setCostPrice(BigDecimal.ZERO);
                medicine.setSellingPrice(BigDecimal.ZERO);
                medicine.setTotalAmount(BigDecimal.ZERO);
                medicine.setTaxAmount(BigDecimal.ZERO);
                medicine.setPurchaseDate(visit.getVisitDate());
                medicine.setEntityId(visit.getEntityId());
                medicine.setSupplierId(1);
                medicine.setCategory(medicine.getCategory());
                medicine.setSupplier(null);

                visitService.persistRelatedObject(medicine);
                medication.setMedicineId(medicine.getId());
            }

            medication.setVisitId(visitId);
            medication.setDateIssued(visit.getVisitDate());
            medication.setPatientIdNo(visit.getPatientIdNo());
            medication.setEmployeeIdNo(visit.getEmployeeIdNo());
            medication.setMedicine(null);
            visitService.persistRelatedObject(medication);
        }

        for (PatientVaccine patientVaccine : visit.getVaccines()) {

            if (patientVaccine.isNewEntry()) {
                Vaccine newVaccine = patientVaccine.getVaccine();
                visitService.persistRelatedObject(newVaccine);
                patientVaccine.setVaccineId(newVaccine.getId());
            }

            patientVaccine.setVisitId(visit.getVisitId());
            patientVaccine.setImmunizationDate(visit.getVisitDate());
            patientVaccine.setPatientIdNo(visit.getPatientIdNo());
            patientVaccine.setEmployeeIdNo(visit.getEmployeeIdNo());
            patientVaccine.setVaccine(null);
            patientVaccine.setVaccineDose(null);
            patientVaccine.setVaccineCycle(null);
            visitService.persistRelatedObject(patientVaccine);
        }

        for (Note note : visit.getNotes()) {
            note.setVisitId(visit.getVisitId());
            note.setNoteDate(visit.getVisitDate());
            note.setPatientIdNo(visit.getPatientIdNo());
            note.setEmployeeIdNo(visit.getEmployeeIdNo());
            visitService.persistRelatedObject(note);
        }

        for (PatientDisclosure disclosure : visit.getDisclosures()) {
            disclosure.setVisitId(visitId);
            disclosure.setVisitDate(visit.getVisitDate());
            disclosure.setPatientIdNo(visit.getPatientIdNo());
            disclosure.setEmployeeIdNo(visit.getEmployeeIdNo());
            visitService.persistRelatedObject(disclosure);
        }

        for (UserImage image : documentUtilAndUploader.uploadPatientImages(images, visit.getPatientIdNo(), visitId).values()) {
            image.setUploadType(null);
            image.setImageData(null);
            image.setUploadType(UploadTypeEnum.SCAN);

            UserImage userImageFromDb = patientService.findImageByIdNoAndUploadTypeId(UploadTypeEnum.SCAN, visit.getPatientIdNo());
            boolean imageExists = userImageFromDb != null ? true : false;

            if (imageExists) {
                image.setId(userImageFromDb.getId());
            }

            visitService.persistRelatedObject(image);
            long imageId = image.getId();

            VisitImages visitImage = new VisitImages();
            visitImage.setVisitId(visitId);
            visitImage.setImageId(imageId);
            visitImage.setReferralId(referralId);
            visitService.persistRelatedObject(visitImage);
        }

        long invoiceId = 0;

        for (Invoice invoice : visit.getInvoices()) {
            invoice.setVisitId(visitId);
            invoiceId = invoice.getId();
            visitService.persistRelatedObject(invoice);
        }

        for (VisitTreatment treatment : visit.getRemovedTreatments()) {
            visitService.deleteObject(treatment);
        }

        for (VisitTreatment treatment : visit.getVisitTreatmentItems()) {
            treatment.setVisit(visit);
            treatment.setInvoiceId(invoiceId);
            treatment.setVisitDate(visit.getVisitDate());
            treatment.setEmployeeIdNo(visit.getEmployeeIdNo());
            treatment.setPatientIdNo(visit.getPatientIdNo());
            visitService.persistRelatedObject(treatment);
        }
    }*/
}
