/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import za.co.timbaron.hms.entity.User;

/**
 *
 * @author ABMC684
 */
public class UserPrincipalHelper {

    private User loggedUser;
    private Object userPrincipal;

    public User getLoggedUser() {
        return loggedUser;
    }

    public void setLoggedUser(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    public Object getUserPrincipal() {
        return userPrincipal;
    }

    public void setUserPrincipal(Object userPrincipal) {
        this.userPrincipal = userPrincipal;
    }

}
