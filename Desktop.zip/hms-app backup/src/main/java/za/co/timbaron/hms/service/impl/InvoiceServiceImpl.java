/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.repository.InvoiceRepo;
import za.co.timbaron.hms.service.InvoiceService;

/**
 *
 * @author Matimba
 */
@Service("invoiceService")
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

    @Autowired
    private InvoiceRepo invoiceRepo;

    @Override
    public void save(Invoice invoice) {
        invoiceRepo.save(invoice);
    }

    @Override
    public void manualBindingSave(Invoice invoice) {
        //invoiceDao.manualBindingSave(invoice);
    }

}
