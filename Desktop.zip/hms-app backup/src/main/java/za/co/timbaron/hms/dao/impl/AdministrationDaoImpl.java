/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.dao.impl;

import java.sql.Date;
import java.util.List;
import org.springframework.web.bind.annotation.RequestParam;
import za.co.timbaron.hms.entity.Appointment;

/**
 *
 * @author ABMC684
 */

public class AdministrationDaoImpl {

    public Appointment findById(long id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<Appointment> findAppointmentsByEntityId(long entityId, Date startDate, @RequestParam Date endDate) {
        StringBuilder myQuery = new StringBuilder();
        myQuery.append("From Appointment ") //'%Y-%m-%d'
                .append(" where entityId = :entityId and DATE_FORMAT(STARTDATE, '%Y-%m-%d') >= :startDate "
                        + " OR DATE_FORMAT(ENDDATE, '%Y-%m-%d') <= :endDate");

        /*Query qry = getSession().createQuery(myQuery.toString());
        qry.setParameter("entityId", entityId);
        qry.setParameter("startDate", startDate, DateType.INSTANCE);
        qry.setParameter("endDate", endDate, DateType.INSTANCE);*/
        return null;//qry.list();
    }

    public List<Appointment> findUserAppointmentsById(long userId, Date startDate, @RequestParam Date endDate) {

        StringBuilder myQuery = new StringBuilder();
        myQuery.append("From Appointment ")
                .append(" where userId = :userId and DATE_FORMAT(STARTDATE, '%Y-%m-%d') >= :startDate "
                        + " OR DATE_FORMAT(ENDDATE, '%Y-%m-%d') <= :endDate");

        /*Query qry = getSession().createQuery(myQuery.toString());
        qry.setParameter("userId", userId);
        qry.setParameter("startDate", startDate, DateType.INSTANCE);
        qry.setParameter("endDate", endDate, DateType.INSTANCE);*/
        return null;///qry.list();
    }

    public void delete(Appointment appointment) {
        delete(appointment);
    }

}
