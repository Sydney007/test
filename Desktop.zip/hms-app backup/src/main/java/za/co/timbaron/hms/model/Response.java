package za.co.timbaron.hms.model;

import java.util.Map;
import java.util.Set;

public class Response {

    private long code;
    private String message;
    private Error error;
    private boolean failed;
    private String url;
    private Map urls;
    private Set listResultSet;
    private Object objectResultSet;

    public Response() {
    }

    public Response(long code, String message, Error error) {
        this.code = code;
        this.message = message;
        this.error = error;
    }

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public boolean isFailed() {
        return failed;
    }

    public void setFailed(boolean failed) {
        this.failed = failed;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Set getListResultSet() {
        return listResultSet;
    }

    public void setListResultSet(Set listResultSet) {
        this.listResultSet = listResultSet;
    }

    public Object getObjectResultSet() {
        return objectResultSet;
    }

    public void setObjectResultSet(Object objectResultSet) {
        this.objectResultSet = objectResultSet;
    }

    public Map getUrls() {
        return urls;
    }

    public void setUrls(Map urls) {
        this.urls = urls;
    }
}
