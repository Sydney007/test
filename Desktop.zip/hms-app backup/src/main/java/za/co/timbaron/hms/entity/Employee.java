package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import za.co.timbaron.hms.enums.AvailabilityStatusEnum;

@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_EMPLOYEE")
public class Employee extends UserDetails implements Serializable {

    @Column(name = "EMPLOYEENO", nullable = false)
    private String employeeNo;

    @Enumerated(EnumType.STRING)
    @Column(name = "AVAILABILITYSTATUS", nullable = false)
    private AvailabilityStatusEnum availabilityStatus;

    @Transient
    private boolean newEmployee;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ENTITYID", referencedColumnName = "ID")
    private HMSEntity entity;

    @OneToMany(mappedBy = "doctor", cascade = CascadeType.ALL)
    private Set<Visit> visits = new HashSet();

}
