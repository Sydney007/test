package za.co.timbaron.hms.util;

import java.math.BigDecimal;
import za.co.timbaron.hms.entity.Address;
import za.co.timbaron.hms.entity.HMSEntity;

public class EntityHelperBean {

    private StringBuilder addressString = new StringBuilder();
    private BigDecimal practiceConsultationFee = new BigDecimal(0.00);
    private boolean entityDispenseMedicine;
    private String entityName;
    private String entityTelephone;
    private String entityEmail;

    private Address address;

    public void setAddress(HMSEntity entity, String recipient, String recipientTelephone, String recipientEmail) {
        StringBuilder addressString = new StringBuilder();
        /*String addressLine = entity.getAddressLine1() + ", " + entity.getAddressLine2();
        String city = entity.getSuburb().getCity() + ", " + entity.getSuburb().getName() + " " + entity.getSuburb().getPostalCode();
        String country = entity.getSuburb().getProvince().getProvinceName();

        addressString.append("<strong>").append(recipient).append("</strong>\n" + "  <br>")
                .append(addressLine).append("\n" + "  <br>").append(city)
                .append("\n" + "  <br>").append(country).append("\n" + "  <br>Phone: ")
                .append(recipientTelephone).append("\n" + "  <br>Email: ")
                .append(recipientEmail).append("");

        address = new Address();
        address.setAddressLine1(entity.getAddressLine1());
        address.setAddressLine2(entity.getAddressLine2());
        address.setSuburb(entity.getSuburb());
        entityTelephone = recipientTelephone;
        entityEmail = recipientEmail;*/

        this.addressString = addressString;
    }

    public StringBuilder getAddressString() {
        return addressString;
    }

    public Address getAddress() {
        return address;
    }

    public BigDecimal getPracticeConsultationFee() {
        return practiceConsultationFee;
    }

    public void setPracticeConsultationFee(BigDecimal practiceConsultationFee) {
        this.practiceConsultationFee = practiceConsultationFee;
    }

    public boolean isEntityDispenseMedicine() {
        return entityDispenseMedicine;
    }

    public void setEntityDispenseMedicine(boolean entityDispenseMedicine) {
        this.entityDispenseMedicine = entityDispenseMedicine;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getEntityTelephone() {
        return entityTelephone;
    }

    public String getEntityEmail() {
        return entityEmail;
    }

}
