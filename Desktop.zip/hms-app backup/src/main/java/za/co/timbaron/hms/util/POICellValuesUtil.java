/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import java.text.SimpleDateFormat;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;

/**
 *
 * @author ABMC684
 */
public class POICellValuesUtil {

    public String getCellValueAsString(Cell cell) {

        String strCellValue = null;

        if (cell != null) {

            if (cell.getCellType() == CellType.STRING) {
                strCellValue = cell.toString();
            } else if (cell.getCellType() == CellType.NUMERIC) {
                if (DateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    strCellValue = dateFormat.format(cell.getDateCellValue());
                } else {
                    Double value = cell.getNumericCellValue();
                    Long longValue = value.longValue();
                    strCellValue = new String(longValue.toString());
                }
            } else if (cell.getCellType() == CellType.BOOLEAN) {
                strCellValue = new String(Boolean.toString(cell.getBooleanCellValue()));
            } else if (cell.getCellType() == CellType.BLANK) {
                strCellValue = "";
            }
        }
        return strCellValue;
    }

}
