package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum RaceEnum {
    AFRICAN_AMERICAN,
    INDIAN,
    COLOURED,
    WHITE,
    UNKNOW;
}
