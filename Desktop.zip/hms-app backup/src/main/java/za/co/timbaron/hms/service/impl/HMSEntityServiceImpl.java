package za.co.timbaron.hms.service.impl;

import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Bed;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.InvoicesStats;
import za.co.timbaron.hms.entity.ItemsServices;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.Room;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;
import za.co.timbaron.hms.repository.BedRepo;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.repository.HMSEntityRepo;
import za.co.timbaron.hms.repository.InvoiceRepo;
import za.co.timbaron.hms.repository.InvoicesStatsRepo;
import za.co.timbaron.hms.repository.ItemsServicesRepo;
import za.co.timbaron.hms.repository.MedicineRepo;
import za.co.timbaron.hms.repository.RoomRepo;
import za.co.timbaron.hms.service.HMSEntityService;

@Service("entityService")
@Transactional
public class HMSEntityServiceImpl implements HMSEntityService {

    @Autowired
    private HMSEntityRepo hmsEntityRepo;

    @Autowired
    private RoomRepo roomRepo;

    @Autowired
    private BedRepo bedRepo;

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private InvoiceRepo invoiceRepo;

    @Autowired
    private InvoicesStatsRepo invoicesStatsRepo;

    @Autowired
    private MedicineRepo medicineRepo;

    @Autowired
    private ItemsServicesRepo itemsServicesRepo;

    @Override
    public HMSEntity findById(long id) {
        return hmsEntityRepo.findById(id).get();
    }

    @Override
    public HMSEntity findByRegistrationNumber(String identityNumber) {
        return hmsEntityRepo.findByRegistrationNumber(identityNumber);
    }

    @Override
    public List<HMSEntity> findAllEntities() {
        return hmsEntityRepo.findAll();
    }

    @Override
    public void save(HMSEntity entity) {
        hmsEntityRepo.saveAndFlush(entity);
    }

    @Override
    public void remove(HMSEntity entity) {
        hmsEntityRepo.delete(entity);
    }

    @Override
    public List<Room> findEntityRooms(long entityId) {
        return roomRepo.findAllByEntityId(entityId);
    }

    @Override
    public List<Bed> findRoomBedsByRoomId(long roomId) {
        return bedRepo.findAllByRoomId(roomId);
    }

    @Override
    public List<Invoice> findInvoicesByEntityID(long entityId, InvoiceStatusEnum status) {
        return invoiceRepo.findAllByEntityIdAndInvoiceStatus(entityId, status);
    }

    @Override
    public List<Invoice> findPatientInvoicesByIDNumber(String identityNumber, InvoiceStatusEnum status) {
        return invoiceRepo.findAllByPatientIdNoAndInvoiceStatus(identityNumber, status);
    }

    @Override
    public List<InvoicesStats> findInvoiceStatsByEntityId(long entityId) {
        return invoicesStatsRepo.findAllByEntityId(entityId);
    }

    @Override
    public List<Medicine> findAllMedicinesByEntityId(long entityId) {
        return medicineRepo.findAllByEntityId(entityId);
    }

    @Override
    public List<Invoice> findInvoicesByEntityIdAndDateRange(long entityId, Date fromDate, Date toDate) {
        return invoiceRepo.findInvoicesByEntityIdAndDateRange(entityId, fromDate, toDate);
    }

    @Override
    public List<ItemsServices> findAllItemsServicesByEntityId(long entityId) {
        return itemsServicesRepo.findAllByEntityId(entityId);
    }

    @Override
    public List<Employee> findAllUsersByEntityId(long entityId) {
        return employeeRepo.findAllByEntityId(entityId);
    }

    @Override
    public void persistObject(Object entity) {
    }

}
