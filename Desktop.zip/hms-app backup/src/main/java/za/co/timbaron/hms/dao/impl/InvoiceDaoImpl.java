package za.co.timbaron.hms.dao.impl;

import za.co.timbaron.hms.entity.Invoice;

public class InvoiceDaoImpl {

    
   
    public void manualBindingSave(Invoice invoice) {
      //   Query qry = getSession().createQuery("From Employee where fullName like :searchField");
       // qry.setString("searchField", "%" + val + "%");
    }
    
}
