package za.co.timbaron.hms.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.PackageTypeItems;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserRawPassword;
import za.co.timbaron.hms.repository.EmployeeRepo;
import za.co.timbaron.hms.repository.HMSEntityRepo;
import za.co.timbaron.hms.repository.PackageTypeItemsRepo;
import za.co.timbaron.hms.repository.UserRawPasswordRepo;
import za.co.timbaron.hms.repository.UserRepo;
import za.co.timbaron.hms.service.UserService;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private HMSEntityRepo hmsEntityRepo;

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private PackageTypeItemsRepo packageTypeItemsRepo;

    @Autowired
    private UserRawPasswordRepo userRawPasswordRepo;

    @Override
    public User findById(long id) {
        return userRepo.findById(id);
    }

    @Override
    public User findByUsername(String username) {
        return userRepo.findByUsername(username);
    }

    @Override
    public HMSEntity getEntityDetails(String registrationNumber) {
        return hmsEntityRepo.findByRegistrationNumber(registrationNumber);
    }

    @Override
    public Employee getEmployeeDetails(String idNumber) {
        return employeeRepo.findByIdentityNumber(idNumber);
    }

    @Override
    public List<PackageTypeItems> getPackageTypeUsermenu(long packageTypeId) {
        return packageTypeItemsRepo.findByPackageTypeId(packageTypeId);
    }

    @Override
    public List<User> findAllUsers() {
        return userRepo.findAll();
    }

    @Override
    public void saveOrUpdate(User user) {
        userRepo.saveAndFlush(user);
    }

    @Override
    public void persistObject(Object entity) {

    }

    @Override
    public User findByIdNumber(String identityNumber) {
        return userRepo.findByIdentityNumber(identityNumber);
    }

    @Override
    public UserRawPassword findPasswordByUser(User user) {
        return userRawPasswordRepo.findByUser(user);
    }
}
