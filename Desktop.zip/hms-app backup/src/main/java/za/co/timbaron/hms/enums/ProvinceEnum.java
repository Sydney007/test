package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum ProvinceEnum {
    GAUTENG,
    LIMPOPO,
    EASTERN_CAPE,
    FREE_STATE,
    KWAZULU_NATAL,
    MPUMALANGA,
    NORTHERN_CAPE,
    NORTH_WEST,
    WESTERN_CAPE;
}
