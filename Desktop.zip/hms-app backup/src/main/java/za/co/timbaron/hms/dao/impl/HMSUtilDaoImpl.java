package za.co.timbaron.hms.dao.impl;

import com.google.gson.Gson;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import za.co.timbaron.hms.entity.AccountType;
import za.co.timbaron.hms.entity.DropDownValuesUtil;
import za.co.timbaron.hms.entity.MedicalTreatment;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.PackageType;
import za.co.timbaron.hms.entity.PackageTypeItems;
import za.co.timbaron.hms.entity.RoomType;
import za.co.timbaron.hms.entity.SocialHistoryValues;
import za.co.timbaron.hms.entity.User;
import za.co.timbaron.hms.entity.UserImage;
import za.co.timbaron.hms.entity.VisitType;
import za.co.timbaron.hms.enums.UploadTypeEnum;
import za.co.timbaron.hms.service.HMSEntityService;

/**
 *
 * @author Matimba
 */

public class HMSUtilDaoImpl  {

    /*@Autowired
    private DropDownValuesUtil dropDownValuesUtil;

    @Autowired
    private HMSEntityService entityService;

    @Autowired
    private Gson gson;

    @Override
    public List<MedicalProblem> getMedicalProblems() {
        List<MedicalProblem> medicalProblem = createSelectQuery(MedicalProblem.class).list();
        return medicalProblem;
    }

    @Override
    public List<Allergy> getAllergies() {
        List<Allergy> allergies = createSelectQuery(Allergy.class).list();
        return allergies;
    }

    @Override
    public List<Medicine> getAllMedicines() {
        List<Medicine> medicines = createSelectQuery(Medicine.class).list();
        return medicines;
    }

    @Override
    public List<Vaccine> getAllVaccines() {
        List<Vaccine> vaccines = createSelectQuery(Vaccine.class).list();
        return vaccines;
    }

    @Override
    public DropDownValuesUtil getDropDownValuesUtil(long entityId) throws Exception {

        dropDownValuesUtil.setProvinces(createSelectQuery(Province.class).list());
        dropDownValuesUtil.setCd4CountList(createSelectQuery(CDCount.class).list());
        dropDownValuesUtil.setSocialHistory(createSelectQuery(SocialHistoryValues.class).list());
        dropDownValuesUtil.setDiagnosisStatus(createSelectQuery(DiagnosisStatus.class).list());
        dropDownValuesUtil.setVisitTypes(createSelectQuery(VisitType.class).list());

        dropDownValuesUtil.setAccountTypes(createSelectQuery(AccountType.class).list());

        dropDownValuesUtil.setRoomTypes(createSelectQuery(RoomType.class).list());
        dropDownValuesUtil.setDepartments(createSelectQuery(Department.class).list());

        dropDownValuesUtil.setSuppliers(entityService.findAllSuppliersByEntityId(entityId));

        List<PackageType> packageTypes = getPackages();

        for (PackageType type : packageTypes) {
            List<PackageTypeItems> packageItems = findAllById(type.getId(), "PackageTypeItems");
            type.setPackageItems(packageItems);
        }

        dropDownValuesUtil.setPackageTypes(packageTypes);

        return dropDownValuesUtil;
    }

    @Override
    public MedicalTreatment findMedicalTreatmentById(long id) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<MedicalTreatment> cr = cb.createQuery(MedicalTreatment.class);
        Root<MedicalTreatment> root = cr.from(MedicalTreatment.class);

        cr.select(root).where(cb.equal(root.get("id"), id));

        Query<MedicalTreatment> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    @Override
    public List lookUp(String searchString, String className, String searchField) throws Exception {

        Class<?> cls = Class.forName(className);

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery cr = cb.createQuery(cls);
        Root root = cr.from(cls);

        cr.select(root).where(cb.like(root.get(searchField), "%" + searchString + "%"));

        Query query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List findAllById(long id, String className) throws Exception {

        Class<?> cls = Class.forName("za.co.timbaron.hms.entity." + className);

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery criteriaQuery = builder.createQuery(cls);
        Root root = criteriaQuery.from(cls);

        criteriaQuery.select(root).where(builder.equal(root.get("packageTypeId"), id));

        Query query = getSession().createQuery(criteriaQuery);

        return query.list();
    }

    @Override
    public User checkUserAvailability(String username) {

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery<User> criteriaQuery = builder.createQuery(User.class);
        Root<User> root = criteriaQuery.from(User.class);

        criteriaQuery.select(root).where(builder.equal(root.get("username"), username));

        Query<User> query = getSession().createQuery(criteriaQuery);

        return query.uniqueResult();
    }

    public List<PackageType> getPackages() {

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery<PackageType> criteriaQuery = builder.createQuery(PackageType.class);
        Root<PackageType> root = criteriaQuery.from(PackageType.class);

        criteriaQuery.select(root).where(builder.not(root.get("id").in(4)));

        Query<PackageType> query = getSession().createQuery(criteriaQuery);

        return query.list();
    }

    @Override
    public String getMaxValue(String className, String field) throws Exception {

        Class<?> cls = Class.forName("za.co.timbaron.hms.entity." + className);

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery criteriaQuery = builder.createQuery(cls);
        Root root = criteriaQuery.from(cls);

        criteriaQuery.select(root).where(builder.max(root.get(field)));

        Query query = getSession().createQuery(criteriaQuery);

        return query.uniqueResult() + "";
    }

    @Override
    public void delete(String className, long id) throws Exception {

        Class<?> cls = Class.forName("za.co.timbaron.hms.entity." + className);

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaDelete delete = builder.createCriteriaDelete(cls);
        Root root = delete.from(cls);

        delete.where(builder.equal(root.get("id"), id));

        Query query = getSession().createQuery(delete);

        query.executeUpdate();
        getSession().flush();
    }

    @Override
    public UserImage findProfilePicByIdNo(String identityNumber) {

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery<UserImage> criteriaQuery = builder.createQuery(UserImage.class);
        Root<UserImage> root = criteriaQuery.from(UserImage.class);

        Predicate[] predicates = new Predicate[2];
        predicates[0] = builder.equal(builder.upper(root.get("identityNumber")), identityNumber);
        predicates[1] = builder.equal(builder.upper(root.get("uploadType")), UploadTypeEnum.LOGO);

        criteriaQuery.select(root).where(predicates);

        Query<UserImage> query = getSession().createQuery(criteriaQuery);

        return (UserImage) query.uniqueResult();
    }*/
}
