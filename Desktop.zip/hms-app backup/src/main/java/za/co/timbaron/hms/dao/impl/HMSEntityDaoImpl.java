/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.dao.impl;

import java.sql.Date;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import za.co.timbaron.hms.entity.Bed;
import za.co.timbaron.hms.entity.Employee;
import za.co.timbaron.hms.entity.HMSEntity;
import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.InvoicesStats;
import za.co.timbaron.hms.entity.ItemsServices;
import za.co.timbaron.hms.entity.Medicine;
import za.co.timbaron.hms.entity.Room;
import za.co.timbaron.hms.enums.InvoiceStatusEnum;


public class HMSEntityDaoImpl  {

    /*@Override
    public HMSEntity findById(long id) {
        CriteriaBuilder cb = createEntityCriteriaBuilder();

        CriteriaQuery<HMSEntity> cr = createEntityCriteria();
        Root<HMSEntity> root = createEntityRootCriteria();
        cr.select(root).where(cb.equal(root.get("id"), id));
        Query<HMSEntity> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    @Override
    public HMSEntity findByRegistrationNumber(String identityNumber) {

        CriteriaBuilder cb = createEntityCriteriaBuilder();
        CriteriaQuery<HMSEntity> cr = createEntityCriteria();
        Root<HMSEntity> root = createEntityRootCriteria();
        cr.select(root).where(cb.equal(root.get("registrationNumber"), identityNumber));

        Query<HMSEntity> query = getSession().createQuery(cr);

        return query.uniqueResult();
    }

    @Override
    public List<HMSEntity> findAllEntities() {

        CriteriaQuery<HMSEntity> cr = createEntityCriteria();
        Root<HMSEntity> root = createEntityRootCriteria();
        cr.select(root);

        Query<HMSEntity> query = getSession().createQuery(cr);
        return query.list();
    }

    @Override
    public List<Room> findEntityRooms(long entityId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Room> cr = cb.createQuery(Room.class);
        Root<Room> root = cr.from(Room.class);
        cr.select(root).where(cb.equal(root.get("entityId"), entityId)).distinct(true);

        Query<Room> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List<Bed> findRoomBedsByRoomId(long roomId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Bed> cr = cb.createQuery(Bed.class);
        Root<Bed> root = cr.from(Bed.class);
        cr.select(root).where(cb.equal(root.get("roomId"), roomId)).distinct(true);

        Query<Bed> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List<Invoice> findInvoicesByEntityID(long entityId, InvoiceStatusEnum status) {

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery<Invoice> criteriaQuery = builder.createQuery(Invoice.class);
        Root<Invoice> root = criteriaQuery.from(Invoice.class);

        Predicate[] predicates = new Predicate[2];
        predicates[0] = builder.equal(builder.upper(root.get("status")), status.getStatus());
        predicates[1] = builder.equal(builder.upper(root.get("entityId")), entityId);

        criteriaQuery.select(root).where(predicates).distinct(true);

        Query<Invoice> query = getSession().createQuery(criteriaQuery);

        return query.list();
    }

    @Override
    public List<Invoice> findPatientInvoicesByIDNumber(String identityNumber, InvoiceStatusEnum status) {

        final CriteriaBuilder builder = getSession().getCriteriaBuilder();
        CriteriaQuery<Invoice> criteriaQuery = builder.createQuery(Invoice.class);
        Root<Invoice> root = criteriaQuery.from(Invoice.class);

        Predicate[] predicates = new Predicate[2];
        predicates[0] = builder.equal(builder.upper(root.get("status")), status);
        predicates[1] = builder.equal(builder.upper(root.get("patientIdNo")), identityNumber);

        criteriaQuery.select(root).where(predicates).distinct(true);

        Query<Invoice> query = getSession().createQuery(criteriaQuery);

        return query.list();
    }

    @Override
    public List<InvoicesStats> findInvoiceStatsByEntityId(long entityId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<InvoicesStats> cr = cb.createQuery(InvoicesStats.class);
        Root<InvoicesStats> root = cr.from(InvoicesStats.class);
        cr.select(root).where(cb.equal(root.get("entityId"), entityId)).distinct(true);

        Query<InvoicesStats> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List<Medicine> findAllMedicinesByEntityId(long entityId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Medicine> cr = cb.createQuery(Medicine.class);
        Root<Medicine> root = cr.from(Medicine.class);
        cr.select(root).where(cb.equal(root.get("entityId"), entityId)).distinct(true);

        Query<Medicine> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List<Supplier> findAllSuppliersByEntityId(long entityId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Supplier> cr = cb.createQuery(Supplier.class);
        Root<Supplier> root = cr.from(Supplier.class);
        cr.select(root).where(cb.equal(root.get("entityId"), entityId)).distinct(true);

        Query<Supplier> query = getSession().createQuery(cr);

        return query.list();
    }

    @Override
    public List<Invoice> findInvoicesByEntityIdAndDateRange(long entityId, Date fromDate, Date toDate) {
        /*StringBuilder myQuery = new StringBuilder();
        myQuery.append("From Invoice where entityId = :entityId and invoiceDate between :fromDate and :toDate order by invoiceDate desc");

        Query qry = getSession().createQuery(myQuery.toString());
        qry.setParameter("fromDate",fromDate, Date.class);
        qry.setDate("toDate", toDate);
        qry.setLong("entityId", entityId);
        qry.setMaxResults(100);*/

        /* cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Invoice> cr = cb.createQuery(Invoice.class);
        Root<Invoice> root = cr.from(Invoice.class);

        Predicate[] predicates = new Predicate[2];
        predicates[0] = cb.equal(cb.upper(root.get("entityId")), entityId);
        predicates[1] = cb.between(root.get("invoiceDate"), fromDate, toDate);

        cr.select(root).where(predicates).distinct(true).orderBy(cb.desc(root.get("invoiceDate")));

        Query<Invoice> query = getSession().createQuery(cr).setMaxResults(100);

        return query.list();

    }

    @Override
    public List<ItemsServices> findAllItemsServicesByEntityId(long entityId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<ItemsServices> cr = cb.createQuery(ItemsServices.class);
        Root<ItemsServices> root = cr.from(ItemsServices.class);
        cr.select(root).where(cb.equal(root.get("entityId"), entityId)).distinct(true);

        Query<ItemsServices> query = getSession().createQuery(cr);

        return query.list();

    }

    @Override
    public List<Employee> findAllUsersByEntityId(long entityId) {

        CriteriaBuilder cb = getSession().getCriteriaBuilder();
        CriteriaQuery<Employee> cr = cb.createQuery(Employee.class);
        Root<Employee> root = cr.from(Employee.class);
        cr.select(root).where(cb.equal(root.get("entityId"), entityId)).distinct(true);

        Query<Employee> query = getSession().createQuery(cr);

        return query.list();
    }*/
}
