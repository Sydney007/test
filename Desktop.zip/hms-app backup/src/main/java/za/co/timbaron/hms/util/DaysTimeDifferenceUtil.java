/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author ABMC684
 */
public class DaysTimeDifferenceUtil {

    public Map<TimeUnit, Long> computeDiff(Date date1, Date date2) {

        Map<TimeUnit, Long> result = new LinkedHashMap<TimeUnit, Long>();

        long diff = date2.getTime() - date1.getTime();

        long diffSeconds = diff / 1000;
        long diffMinutes = diff / (60 * 1000);
        long diffHours = diff / (60 * 60 * 1000);
        long diffDays = diff / (24 * 60 * 60 * 1000);

        result.put(TimeUnit.DAYS, diffDays);
        result.put(TimeUnit.HOURS, diffHours);
        result.put(TimeUnit.MINUTES, diffMinutes);
        result.put(TimeUnit.SECONDS, diffSeconds);

        return result;
    }
}
