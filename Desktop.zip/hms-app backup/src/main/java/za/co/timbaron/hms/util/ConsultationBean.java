/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import za.co.timbaron.hms.entity.Invoice;
import za.co.timbaron.hms.entity.Visit;
import za.co.timbaron.hms.entity.Wallet;

/**
 *
 * @author ABMC684
 */
public class ConsultationBean {

    private Visit visit;
    private Invoice invoice;
    private Wallet wallet;

    public Visit getVisit() {
        return visit;
    }

    public void setVisit(Visit visit) {
        this.visit = visit;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public Wallet getWallet() {
        return wallet;
    }

    public void setWallet(Wallet wallet) {
        this.wallet = wallet;
    }
}
