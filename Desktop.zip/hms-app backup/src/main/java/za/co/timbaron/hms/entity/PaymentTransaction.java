/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import za.co.timbaron.hms.enums.PaymentMethodEnum;
import za.co.timbaron.hms.enums.TransactionTypeEnum;

@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_PAYMENT_TRANSACTION")
public class PaymentTransaction implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "AMOUNT", nullable = false)
    private BigDecimal amount;

    @Column(name = "REFERENCE", nullable = false)
    private String reference;

    @Column(name = "TRANSACTIONDATE", nullable = false)
    private Timestamp transactionDate;

    @Column(name = "PATIENTIDNO", nullable = false)
    private String patientIdNo;

    @Column(name = "PAYMENTMETHOD", nullable = false)
    private PaymentMethodEnum paymemtMethod;

    @Column(name = "ENTITYID", nullable = false)
    private long entityId;

    @Column(name = "INVOICEID", nullable = false)
    private long invoiceId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ENTITYID", referencedColumnName = "ID", insertable = false, updatable = false)
    private HMSEntity entity = new HMSEntity();

    @Enumerated(EnumType.STRING)
    @Column(name = "TRANSACTIONTYPE", nullable = false)
    private TransactionTypeEnum transactionType;

}
