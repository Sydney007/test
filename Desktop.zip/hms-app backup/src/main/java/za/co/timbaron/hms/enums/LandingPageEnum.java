package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum LandingPageEnum {

    ADMINISTRATION("Administration", 1),
    CONSULTATION("Consultation", 2),
    REFERRALS("Referrals", 3),
    DASHBOARD("Home", 4),
    ENTITYMANAGEMENT("EntityManagement", 5);

    private final String description;
    private final long id;

    LandingPageEnum(String description, int id) {
        this.description = description;
        this.id = id;
    }

    public static LandingPageEnum getById(long id) {
        for (LandingPageEnum e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        return null;
    }
}
