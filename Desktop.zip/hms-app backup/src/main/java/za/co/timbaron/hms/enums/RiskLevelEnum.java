package za.co.timbaron.hms.enums;

import lombok.Getter;

@Getter
public enum RiskLevelEnum {
    NO_RISK,
    HIGH,
    LOW,
    MEDIUM;
}
