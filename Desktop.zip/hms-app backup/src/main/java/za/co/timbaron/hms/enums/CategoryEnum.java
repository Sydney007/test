package za.co.timbaron.hms.enums;

public enum CategoryEnum {
    MEDICINE,
    TABLETS;
}
