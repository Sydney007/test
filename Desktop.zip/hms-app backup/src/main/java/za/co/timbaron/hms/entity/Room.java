/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Entity
@EqualsAndHashCode
@ToString
@Table(name = "HMS_ROOM")
public class Room implements Serializable {

    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "ROOMNO", nullable = false)
    private long roomNo;

    @Column(name = "SPECIALTY", nullable = false)
    private String speciality;

    @Column(name = "OCCUPIED", nullable = false)
    private boolean occupied;

    @Column(name = "ALLOWEDPATIENTS", nullable = false)
    private long allowedPatients;

    @Column(name = "DEPARTMENTID", nullable = false)
    private long departmentId;

    @Column(name = "ROOMTYPEID", nullable = false)
    private long roomTypeId;

    @Column(name = "CURRENTPATIENTS", nullable = false)
    private long currentPatients;

    @Column(name = "ENTITYID", nullable = false)
    private long entityId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ROOMTYPEID", referencedColumnName = "ID", insertable = false, updatable = false)
    private RoomType roomType = new RoomType();

    @Column(name = "DEPARTMENT", nullable = false)
    private String department;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "ROOMID", referencedColumnName = "ID", insertable = false, updatable = false)
    private List<Bed> beds = new ArrayList();
}
