package za.co.timbaron.hms.enums;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public enum UserTypeEnum {

    ADMINISTRATOR("Administrator", 1),
    DOCTOR("Doctor", 2),
    PATIENT("Patient", 3),
    NURSE("Nurse", 4),
    RECEPTIONIST("Receptionist", 5),
    LABORATORIST("Laboratorist", 6),
    PHARMACIST("Pharmacist", 7),
    ENTITY("Entity", 8),
    UNKNOW("Unknown", 0);

    private final String value;
    private final long id;

    UserTypeEnum(String value, int id) {
        this.value = value;
        this.id = id;
    }

    public static UserTypeEnum getByValue(String value) {
        for (UserTypeEnum e : values()) {
            if (e.value.equals(value)) {
                return e;
            }
        }
        return UNKNOW;
    }

    public static UserTypeEnum getById(long id) {
        for (UserTypeEnum e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        return UNKNOW;
    }
}
