/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.web.config;

import org.apache.catalina.Context;
import org.apache.catalina.Wrapper;
import org.springframework.boot.web.embedded.tomcat.TomcatContextCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 *
 * @author Matimba
 */
@Configuration
public class ExternalImagesHandler implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/Images/**").addResourceLocations("/resources/images/");
        registry.addResourceHandler("/downloads/**").addResourceLocations("/resources/downloads/");
    }

    @Bean
    public CreateImagesDirectory imagesDirectory() {
        return new CreateImagesDirectory();
    }

    @Bean
    public WebServerFactoryCustomizer customizer() {
        return new WebServerFactoryCustomizer<ConfigurableServletWebServerFactory>() {
            @Override
            public void customize(ConfigurableServletWebServerFactory container) {
                if (container instanceof TomcatServletWebServerFactory) {
                    customizeTomcat((TomcatServletWebServerFactory) container);
                }
            }

            private void customizeTomcat(TomcatServletWebServerFactory tomcat) {
                tomcat.addContextCustomizers(new TomcatContextCustomizer() {

                    @Override
                    public void customize(Context context) {
                        Wrapper defServlet = (Wrapper) context.findChild("default");
                        defServlet.addInitParameter("listings", "true");
                    }
                });
            }
        };
    }

    /*@Bean
    public EmbeddedServletContainerCustomizer customizer() {
        return new EmbeddedServletContainerCustomizer() {

            @Override
            public void customize(ConfigurableEmbeddedServletContainer container) {
                if (container instanceof TomcatEmbeddedServletContainerFactory) {
                    customizeTomcat((TomcatEmbeddedServletContainerFactory) container);
                }
            }

            private void customizeTomcat(TomcatEmbeddedServletContainerFactory tomcat) {
                tomcat.addContextCustomizers(new TomcatContextCustomizer() {

                    @Override
                    public void customize(Context context) {
                        Wrapper defServlet = (Wrapper) context.findChild("default");
                        defServlet.addInitParameter("listings", "true");
                    }
                });
            }
        };
    }*/
}
