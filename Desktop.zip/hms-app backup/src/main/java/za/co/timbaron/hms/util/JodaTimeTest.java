/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import static org.springframework.http.converter.json.Jackson2ObjectMapperBuilder.json;

/**
 *
 * @author ABMC684
 */
public class JodaTimeTest {

    /* public static void main(String[] args) {
        /* LocalDate date1 = new LocalDate("2018-09-03");
        LocalDate date2 = new LocalDate("2018-12-18");

     
        while (date1.isBefore(date2)) {
            System.out.println(date1.toString("yyyy-MM-dd"));
            
            LocalDate startDate = date1.dayOfMonth().withMinimumValue();
            LocalDate endDate = date1.dayOfMonth().withMaximumValue().plusDays(1);
            date1 = date1.plus(Period.months(1));

            System.out.println("startDate = " + startDate);
            System.out.println("endDate = " + endDate);
            System.out.println(endDate.isAfter(date2));

        }*/

 /*String jsonStr = "{\"page\":1,\"per_page\":10,\"total\":13,\"total_pages\":2,\"data\":[{\"Poster\":\"https://images-na.ssl-images-amazon.com/images/M/MV5BYjFhN2RjZTctMzA2Ni00NzE2LWJmYjMtNDAyYTllOTkyMmY3XkEyXkFqcGdeQXVyNTA0OTU0OTQ@._V1_SX300.jpg\",\"Title\":\"Italian Spiderman\",\"Type\":\"movie\",\"Year\":2007,\"imdbID\":\"tt2705436\"},{\"Poster\":\"https://images-na.ssl-images-amazon.com/images/M/MV5BMjQ4MzcxNDU3N15BMl5BanBnXkFtZTgwOTE1MzMxNzE@._V1_SX300.jpg\",\"Title\":\"Superman, Spiderman or Batman\",\"Type\":\"movie\",\"Year\":2011,\"imdbID\":\"tt2084949\"},{\"Poster\":\"N/A\",\"Title\":\"Spiderman\",\"Type\":\"movie\",\"Year\":1990,\"imdbID\":\"tt0100669\"},{\"Poster\":\"N/A\",\"Title\":\"Spiderman\",\"Type\":\"movie\",\"Year\":2010,\"imdbID\":\"tt1785572\"},{\"Poster\":\"N/A\",\"Title\":\"Fighting, Flying and Driving: The Stunts of Spiderman 3\",\"Type\":\"movie\",\"Year\":2007,\"imdbID\":\"tt1132238\"},{\"Poster\":\"http://ia.media-imdb.com/images/M/MV5BMjE3Mzg0MjAxMl5BMl5BanBnXkFtZTcwNjIyODg5Mg@@._V1_SX300.jpg\",\"Title\":\"Spiderman and Grandma\",\"Type\":\"movie\",\"Year\":2009,\"imdbID\":\"tt1433184\"},{\"Poster\":\"N/A\",\"Title\":\"The Amazing Spiderman T4 Premiere Special\",\"Type\":\"movie\",\"Year\":2012,\"imdbID\":\"tt2233044\"},{\"Poster\":\"N/A\",\"Title\":\"Amazing Spiderman Syndrome\",\"Type\":\"movie\",\"Year\":2012,\"imdbID\":\"tt2586634\"},{\"Poster\":\"N/A\",\"Title\":\"Hollywood's Master Storytellers: Spiderman Live\",\"Type\":\"movie\",\"Year\":2006,\"imdbID\":\"tt2158533\"},{\"Poster\":\"N/A\",\"Title\":\"Spiderman 5\",\"Type\":\"movie\",\"Year\":2008,\"imdbID\":\"tt3696826\"}]}";

        Gson gson = new Gson();
        JsonElement element = gson.fromJson(jsonStr, JsonElement.class);
        JsonObject jsonObj = element.getAsJsonObject();
        JsonArray array = jsonObj.get("data").getAsJsonArray();

        String[] titles = new String[array.size()];
        int i = 0;

        for (JsonElement arrayElement : array) {
            String a = arrayElement.getAsJsonObject().get("Title").toString().replace("\"", "");
            System.out.println(a);
            titles[i] = a;
            i++;
        }

        sortNames(titles);
    }*/
    public static void sortNames(String[] names) {

        String temp;

        int n = names.length;

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (names[i].compareTo(names[j]) > 0) {
                    temp = names[i];
                    names[i] = names[j];
                    names[j] = temp;
                }
            }
        }
        System.out.println("");
        System.out.print("Names in Sorted Order:");
        for (int i = 0; i < n; i++) {
            System.out.println(names[i] + ",");
        }
        // System.out.print(names[n - 1]);
    }

}
