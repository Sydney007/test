/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.util;

import java.io.Serializable;
import za.co.timbaron.hms.entity.Address;
import za.co.timbaron.hms.entity.EmergencyContact;
import za.co.timbaron.hms.entity.Employer;
import za.co.timbaron.hms.entity.MedicalAid;
import za.co.timbaron.hms.entity.Patient;
import za.co.timbaron.hms.entity.Wallet;

/**
 *
 * @author sydney
 */
public class PatientRegistrationBean implements Serializable {

    private Patient patient;
    private Employer employer;
    private MedicalAid medicalAid;
    private String imageType;
    private String imageName;
    private String imageSize;
    private String imageData;

    private Address address;
    private EmergencyContact emergencyContact;
    private Wallet wallet;

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getImageType() {
        return imageType;
    }

    public void setImageType(String imageType) {
        this.imageType = imageType;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getImageSize() {
        return imageSize;
    }

    public void setImageSize(String imageSize) {
        this.imageSize = imageSize;
    }

    public String getImageData() {
        return imageData;
    }

    public void setImageData(String imageData) {
        this.imageData = imageData;
    }

    public Employer getEmployer() {
        return employer;
    }

    public void setEmployer(Employer employer) {
        this.employer = employer;
    }

    public MedicalAid getMedicalAid() {
        return medicalAid;
    }

    public void setMedicalAid(MedicalAid medicalAid) {
        this.medicalAid = medicalAid;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public EmergencyContact getEmergencyContact() {
        return emergencyContact;
    }

    public void setEmergencyContact(EmergencyContact emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public Wallet getWallet() {
        return wallet;
    }

    public void setWallet(Wallet wallet) {
        this.wallet = wallet;
    }
}
