package za.co.timbaron.hms.util;

import java.sql.Date;
import lombok.Data;

@Data
public class SearchBean {

    private String idNumber;
    private String medicalAid;
    private Date startDate;
    private Date endDate;
    private long searchOptionId;
    private String searchOptionText;
    private boolean dateRange;
    private long id;
    private long patientId;
    private long visitId;
}
