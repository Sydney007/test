/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Where;
import za.co.timbaron.hms.enums.UploadTypeEnum;

@Getter
@Setter
@Entity
@EqualsAndHashCode
@Table(name = "HMS_USER_IMAGES")
public class UserImage implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
    private long id;

    @Column(name = "IMAGEPATH", unique = true, nullable = false)
    private String imagePath;

    @Column(name = "IMAGESIZE", unique = true, nullable = false)
    private String imageSize;

    @Column(name = "IMAGENAME", unique = true, nullable = false)
    private String imageName;

    @Column(name = "UPLOADDATE", unique = true, nullable = false)
    private Timestamp uploadDate;

    @Column(name = "IMAGEDATA", unique = false, nullable = true)
    private String imageData;

    @Column(name = "SERVER", unique = false, nullable = true)
    private String server;

    @Column(name = "USERIDNO", unique = false, nullable = true)
    private String userIdNo;

    @Enumerated(EnumType.STRING)
    @Column(name = "UPLOADTYPE", unique = false, nullable = true)
    private UploadTypeEnum uploadType;

    @OneToOne
    @JoinColumn(name = "USERID", referencedColumnName = "ID")
    @Where(clause = "UPLOADTYPE = LOGO")
    private User user;
}
