/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.timbaron.hms.enums;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;


@Getter
@Slf4j
public enum EntityTypeEnum {

    CLINIC("Clinic", 1),
    HOSPITAL("Hospital", 2),
    PRATICE("Pratice", 3),
    PERSON("Person", 4),
    MEDICAL_CENTER("Medical Center", 5),
    UNKNOW("Unknown", 0);

    private final String name;
    private final long id;

    private EntityTypeEnum(String name, long id) {
        this.name = name;
        this.id = id;
    }

    public static EntityTypeEnum getByName(String name) {
        for (EntityTypeEnum e : values()) {
            if (e.name.equals(name)) {
                return e;
            }
        }
        return UNKNOW;
    }

    public static EntityTypeEnum getById(long id) {
        for (EntityTypeEnum e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        return UNKNOW;
    }

}
